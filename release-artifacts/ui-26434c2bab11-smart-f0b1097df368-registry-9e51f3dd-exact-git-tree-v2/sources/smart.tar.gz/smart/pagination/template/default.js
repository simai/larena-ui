import { html, nothing } from "lit";

function joinClasses(...tokens) {
  return tokens.flat().filter(Boolean).join(" ");
}

function renderPageItem(item, context) {
  const { component } = context;

  return html`
    <li
      class=${joinClasses(
        "sf-pagination-item",
        item.edge ? "sf-pagination-item--edge" : "",
        item.selected ? "sf-pagination-item--current" : "",
      )}
    >
      <button
        type="button"
        class=${joinClasses(
          "sf-page-number",
          "sf-page-number--square",
          item.selected ? "selected" : "",
        )}
        data-page=${String(item.value)}
        aria-current=${item.selected ? "page" : nothing}
        aria-label=${`${context.pageLabel} ${item.value}`}
        @click=${() => component.goToPage(item.value)}
      >
        ${item.value}
      </button>
    </li>
  `;
}

function renderDirection(context, {kind, icon, label, page}) {
  return html`
    <li class="sf-pagination-item">
      <sf-icon-button
        class=${`sf-pagination-direction sf-pagination-direction--${kind}`}
        size="1"
        type="link"
        scheme="on-surface"
        icon=${icon}
        title=${label}
        aria-label=${label}
        @click=${page}
      ></sf-icon-button>
    </li>
  `;
}

export function renderPaginationTemplate(context) {
  const { component } = context;
  const rootClasses = joinClasses(
    "sf-pagination",
    "flex",
    "flex-col",
    context.rootClass,
  );
  const topClasses = joinClasses(
    "sf-pagination-top",
    "flex",
    "content-main-center",
    context.topClass,
  );
  const mainClasses = joinClasses(
    "sf-pagination-main",
    "flex",
    "items-cross-center",
    "content-main-between",
    context.mainClass,
  );
  // The row of bulk controls is a panel over the page while rows are marked,
  // not a row inside the pagination: the controls act on the selection, which
  // outlives the part of the page a person is looking at.
  // Only the band's own class: `sf-pagination-bottom` is the generic last row,
  // and it paints transparent at a higher specificity, so the band came out
  // see-through with the rows reading through it.
  const bottomClasses = joinClasses(
    "sf-pagination-actions",
    "flex",
    "items-cross-center",
    context.bottomClass,
  );

  return html`
    <nav
      class=${rootClasses}
      style=${context.rootStyle || nothing}
      aria-label=${context.ariaLabel}
    >
      ${context.top && context.hasNext
        ? html`
            <div class=${topClasses}>
              <sf-button
                size="1"
                type="outline"
                scheme="primary"
                ?loading=${context.showMoreBusy}
                ?disabled=${context.showMoreBusy}
                @click=${(e) => component.showMore(e.target)}
                text="${context.showMoreText}"
              ></sf-button>
            </div>
          `
        : ""}
      ${context.middle
        ? html`
            <div class=${mainClasses}>
              <div class="sf-pagination-left flex items-cross-center">
                <div class="sf-pagination-marked flex">
                  <div class="sf-pagination-marked-text">
                    ${context.selectedLabel}
                  </div>
                  <div class="sf-pagination-marked-text">
                    ${context.countKnown
                      ? `${context.selectedCount}/${context.total}`
                      : String(context.selectedCount)}
                  </div>
                </div>
                <!-- Three answers to "how many": the number, a short wait, or
                     an offer to find out. A host that cannot count is not
                     offered at all — a link that answers "unavailable" is worse
                     than no link. -->
                <div class="sf-pagination-total flex items-cross-center">
                  ${context.countKnown
                    ? html`
                        <div class="sf-pagination-total-text">
                          ${context.totalLabel} ${context.total}
                        </div>
                      `
                    : context.counting
                      ? html`
                          <div class="sf-pagination-total-text flex items-cross-center">
                            ${context.totalLabel}
                            <sf-spinner size="1" aria-label=${context.countingLabel}></sf-spinner>
                          </div>
                        `
                      : context.canCount
                        ? html`
                            <div class="sf-pagination-total-text flex items-cross-center">
                              ${context.totalLabel}
                              <sf-button
                                class="sf-pagination-count-request"
                                size="1"
                                type="link"
                                scheme="primary"
                                text=${context.showCountLabel}
                                @click=${() => component.requestCount("total")}
                              ></sf-button>
                            </div>
                          `
                        : ""}
                </div>
              </div>

              ${!context.countKnown || context.total > 0
                ? html`
                    <div class="sf-pagination-container flex items-cross-center">
                      <span class="sf-pagination-pages-label">${context.pagesLabel}</span>
                      <ol class="sf-pagination-list flex items-cross-center">
                        ${context.hasPrev
                          ? html`
                              ${renderDirection(context, {
                                kind: "first",
                                icon: "first_page",
                                label: context.firstLabel,
                                page: () => component.firstPage(),
                              })}
                              ${renderDirection(context, {
                                kind: "prev",
                                icon: "keyboard_arrow_left",
                                label: context.previousLabel,
                                page: () => component.goToPage(context.current - 1),
                              })}
                            `
                          : ""}
                        ${context.pageItems.map((item) =>
                          renderPageItem(item, context),
                        )}
                        ${context.hasNext
                          ? html`
                              ${renderDirection(context, {
                                kind: "next",
                                icon: "keyboard_arrow_right",
                                label: context.nextLabel,
                                page: () => component.goToPage(context.current + 1),
                              })}
                              ${renderDirection(context, {
                                kind: "last",
                                icon: "last_page",
                                label: context.lastLabel,
                                page: () => component.lastPage(),
                              })}
                            `
                          : ""}
                      </ol>
                      <!-- Any page, by name. The window shows where the person
                           is; the field is how they go somewhere far without
                           pressing through it. -->
                      <label
                        class="sf-pagination-page-field flex items-cross-center"
                        style=${`--sf-pagination-page-input--digits: ${String(context.current).length}`}
                      >
                        <span>${context.pageFieldLabel}</span>
                        <sf-input
                          size="1"
                          type="bordered"
                          root-class="sf-pagination-page-input"
                          value=${String(context.current)}
                          inputmode="numeric"
                          aria-label=${context.pageFieldLabel}
                          @input=${(event) => component.fitPageField(event.target)}
                          @keydown=${(event) => {
                            if (event.key !== "Enter") return;
                            event.preventDefault();
                            component.goToTypedPage(event.target?.value);
                          }}
                        ></sf-input>
                      </label>
                    </div>
                  `
                : ""}

              ${context.showPageSize && (!context.countKnown || context.total > 0)
                ? html`
                    <div class="sf-pagination-count flex items-cross-center">
                      <span>${context.pageSizeLabel}</span>
                      <sf-dropdown
                        size="1"
                        type="outlined"
                        search="false"
                        mode="select"
                        portal="true"
                        value=${String(context.pageSize)}
                        aria-label=${context.pageSizeLabel}
                        .options=${(context.pageSizes || []).map((size) => ({
                          type: "text",
                          size: "1",
                          text: String(size),
                          value: String(size),
                          selected: Number(size) === Number(context.pageSize),
                        }))}
                        @change=${(event) =>
                          component.setPageSize(Number(event.detail.value))}
                      ></sf-dropdown>
                    </div>
                  `
                : ""}
            </div>
          `
        : ""}
      <!-- A page row on its own still carries the band. Inside a data view the
           card carries it instead, and the view turns this block off: a band
           sticky inside the page row could travel no further than the row. -->
      ${context.bottom && context.showActions && context.actions?.length && context.selectedCount > 0
        ? html`
            <div
              class=${bottomClasses}
              role="region"
              aria-label=${context.actionsRegionLabel}
            >
              <span class="sf-pagination-actions-count">
                ${context.selectedLabel} ${context.selectedCount}
              </span>
              <span class="sf-pagination-actions-separator" aria-hidden="true"></span>
              <sf-dropdown
                size="1"
                type="outlined"
                search="false"
                mode="select"
                value=${context.action}
                placeholder=${context.actionChooseLabel}
                aria-label=${context.actionsLabel}
                .options=${[
                  // The list opens on a choice that is not an action. A select
                  // that starts on the first real action makes Apply pressable
                  // before anyone has chosen anything, and the first action in
                  // the list is as likely to be "delete for ever" as anything
                  // else.
                  {
                    type: "text",
                    size: "1",
                    text: context.actionChooseLabel,
                    value: "",
                    selected: !context.action,
                  },
                  ...context.actions.map((action) => ({
                    type: "text",
                    size: "1",
                    text: action.text,
                    value: action.value,
                    selected: action.value === context.action,
                    disabled: Boolean(action.disabled),
                  })),
                ]}
                @change=${(event) => component.setAction(event.detail.value)}
              ></sf-dropdown>
              <sf-button
                size="1"
                type="default"
                scheme="primary"
                text=${context.actionApplyText}
                ?disabled=${!context.action}
                @click=${() => component.applyAction()}
              ></sf-button>
              ${context.showActionForAll
                ? html`
                    <span class="sf-pagination-actions-separator" aria-hidden="true"></span>
                    <sf-checkbox
                      label=${context.countKnown
                        ? `${context.actionForAllLabel} (${context.total})`
                        : context.actionForAllLabel}
                      ?checked=${Boolean(context.actionForAll)}
                      @change=${(event) =>
                        component.setActionForAll(Boolean(event.target?.checked))}
                    ></sf-checkbox>
                  `
                : ""}
              <sf-icon-button
                class="sf-pagination-actions-clear"
                size="1"
                type="link"
                scheme="on-surface"
                icon="close"
                title=${context.clearSelectionLabel}
                aria-label=${context.clearSelectionLabel}
                @click=${() => component.clearSelection()}
              ></sf-icon-button>
            </div>
          `
        : ""}
    </nav>
  `;
}
