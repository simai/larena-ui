(()=>{"use strict";const e="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},t="undefined"!=typeof window?window:{},i=e.SfBaseElement||t.SfBaseElement;if(!i)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const s=e.html||t.html,n=e.nothing||t.nothing,r=(e.render||t.render,e.litProps||t.litProps,e.toBoolean,e.toAttributeName,e.toNumber,e.normalizeEnum,e.parseJsonAttribute,i);function o(...e){return e.flat().filter(Boolean).join(" ")}function a(e,t=""){return e?s`
        <sf-icon filled icon=${e} class=${t||n}></sf-icon>`:n}function l(e){return e.label?s`<span>${e.label}</span>`:e.content!==n?e.content:n}function c(e){const t=o("sf-tree-item flex flex-col",e.type?`sf-tree-item--${e.type}`:"",e.open?"open":"",e.hasChildren?"has-children":"",e.selected||e.active?"active":"",e.disabled?"disabled":"",e.rootClass,e.itemClass),i=o("sf-tree-item-container flex items-cross-center relative",e.containerClass),r=o("sf-tree-item-name",e.nameClass),c=e.open?e.openIcon:e.closedIcon,d=e.open?e.chevronOpenIcon:e.chevronClosedIcon,h=!e.isFile&&e.hasChildren;return s`
        <div
                class=${t}
                role=${e.isTreeSemantic?"treeitem":n}
                aria-expanded=${e.isTreeSemantic&&h?String(e.open):n}
                aria-selected=${e.isTreeSemantic&&e.selected?"true":n}
                aria-disabled=${e.isTreeSemantic&&e.disabled?"true":n}
                data-open-icon=${e.openIcon||n}
                data-closed-icon=${e.closedIcon||n}
                data-value=${e.value||n}
        >
            <div class=${i}>
                ${e.icon?e.isFile?s`<sf-icon filled icon="draft"></sf-icon>`:s`
                            <button
                                    type="button"
                                    class="sf-icon-button sf-tree-toggle"
                                    ?disabled=${!h||e.disabled}
                                    aria-expanded=${h?String(e.open):"false"}
                                    aria-label=${e.open?e.closeLabel:e.openLabel}
                                    @click=${e.onToggle}
                            >
                                ${a(c)}
                            </button>
                        `:n}
                ${h?s`<span class="sf-tree-chevron absolute" aria-hidden="true">
          ${a(d)}
        </span>`:n}

                ${e.href&&!e.disabled?s`
                            <a
                                    class=${r}
                                    href=${e.href}
                                    target=${e.target||n}
                                    rel=${e.rel||n}
                                    @click=${e.onItemClick}
                            >
                                ${l(e)}
                            </a>
                        `:s`
                            <span class=${r} @click=${e.onItemClick}>
                ${l(e)}
              </span>
                        `}
            </div>

            ${e.open&&h?s`
                        ${(e.children||[]).map(e=>function(e={}){return s`
        <sf-tree-item
                label=${e.label||n}
                href=${e.href||n}
                target=${e.target||n}
                rel=${e.rel||n}
                type=${e.type||n}
                value=${e.value||n}
                open-icon=${e.openIcon||n}
                closed-icon=${e.closedIcon||n}
                ?open=${Boolean(e.open)}
                ?selected=${Boolean(e.selected)}
                ?active=${Boolean(e.active)}
                ?disabled=${Boolean(e.disabled)}
                semantic
                .itemsData=${e.children||[]}
        ></sf-tree-item>
    `}(e))}
                    `:n}
        </div>
    `}function d(e){return e?.nodeType===Node.ELEMENT_NODE&&"sf-tree-item"===e?.tagName?.toLowerCase?.()}function h(e){return Array.from(e?.childNodes||[]).filter(e=>!d(e)).map(e=>e.textContent||"").join(" ").replace(/\s+/g," ").trim()}function u(e){if("function"==typeof e?.toTreeItemData)return e.toTreeItemData();const t=Array.from(e?.children||[]).filter(d).map(u);return{label:e.getAttribute("label")||e.getAttribute("text")||e.getAttribute("title")||h(e),href:e.getAttribute("href")||"",target:e.getAttribute("target")||"",rel:e.getAttribute("rel")||"",type:e.getAttribute("type")||"",value:e.getAttribute("value")||"",open:e.hasAttribute("open"),selected:e.hasAttribute("selected"),active:e.hasAttribute("active"),disabled:e.hasAttribute("disabled"),openIcon:e.getAttribute("open-icon")||"",closedIcon:e.getAttribute("closed-icon")||"",children:t}}(class extends r{static contentTemplateSlot="__content";static get props(){return{templateName:{attribute:"template",default:"default"},label:{default:""},text:{default:""},href:{default:""},target:{default:""},rel:{default:""},type:{default:"folder",values:["folder","file"]},value:{default:""},open:{type:Boolean,default:!1},selected:{type:Boolean,default:!1},active:{type:Boolean,default:!1},disabled:{type:Boolean,default:!1},itemsData:{type:Array,default:[]},openIcon:{attribute:"open-icon",default:"folder_open"},closedIcon:{attribute:"closed-icon",default:"folder"},icon:{type:Boolean,default:!0},chevronOpenIcon:{attribute:"chevron-open-icon",default:"keyboard_arrow_down"},chevronClosedIcon:{attribute:"chevron-closed-icon",default:"chevron_right"},openLabel:{attribute:"open-label",default:"Open item"},closeLabel:{attribute:"close-label",default:"Close item"},rootClass:{default:""},itemClass:{attribute:"item-class",default:""},containerClass:{attribute:"container-class",default:""},nameClass:{attribute:"name-class",default:""},semantic:{type:Boolean,default:!1}}}constructor(){super(),this._itemObserver=null,this._itemsData=[],this._sourceData=null}connectedCallback(){this.__treeItemSourceCaptured||(this.captureSourceData(),this.captureInitialContent(),this.captureInitialItems(),this.__treeItemSourceCaptured=!0),this.observeChildItems(),super.connectedCallback()}disconnectedCallback(){this.disconnectItemObserver(),super.disconnectedCallback()}observeChildItems(){this._itemObserver||(this._itemObserver=new MutationObserver(e=>{e.some(e=>Array.from(e.addedNodes||[]).some(d))&&this.captureInitialItems()&&this.requestComponentUpdate("children")}),this._itemObserver.observe(this,{childList:!0}))}disconnectItemObserver(){this._itemObserver?.disconnect?.(),this._itemObserver=null}isContentNode(e){return!(!e||d(e))&&(e.nodeType===Node.TEXT_NODE?""!==String(e.textContent||"").trim():e.nodeType===Node.ELEMENT_NODE)}captureSourceData(){if(this._sourceData)return this._sourceData;const e=Array.from(this.children||[]).filter(d).map(u);return this._sourceData={label:this.getAttribute("label")||this.getAttribute("text")||this.getAttribute("title")||h(this),href:this.getAttribute("href")||"",target:this.getAttribute("target")||"",rel:this.getAttribute("rel")||"",type:this.getAttribute("type")||"",value:this.getAttribute("value")||"",open:this.hasAttribute("open"),selected:this.hasAttribute("selected"),active:this.hasAttribute("active"),disabled:this.hasAttribute("disabled"),openIcon:this.getAttribute("open-icon")||"",closedIcon:this.getAttribute("closed-icon")||"",children:e},this._sourceData}captureInitialContent(){return!this._slotTemplates.has(this.constructor.contentTemplateSlot)&&this.captureChildTemplates(this.constructor.contentTemplateSlot,e=>this.isContentNode(e)).length>0}captureInitialItems(){const e=Array.from(this.childNodes||[]).filter(d);return!!e.length&&(this._itemsData=e.map(u),e.forEach(e=>e.remove()),!0)}get hasChildren(){return!this.isFile&&this.childItems.length>0}get content(){return this.getSlotContent(this.constructor.contentTemplateSlot)}get childItems(){if(this.isFile)return[];const e=this.getProp("itemsData");return Array.isArray(e)&&e.length?e:this._itemsData}get label(){return this.getProp("label")||this.getProp("text")||this._sourceData?.label||""}get type(){return this.getProp("type")||this._sourceData?.type||"folder"}get isFile(){return"file"===this.type}get isTreeSemantic(){return this.getProp("semantic")||Boolean(this.closest("sf-tree"))}toTreeItemData(){const e=this.captureSourceData();return{...e,label:this.label,href:this.getProp("href")||e.href||"",target:this.getProp("target")||e.target||"",rel:this.getProp("rel")||e.rel||"",type:this.type,value:this.getProp("value")||e.value||"",open:this.getProp("open")||e.open||!1,selected:this.getProp("selected")||e.selected||!1,active:this.getProp("active")||e.active||!1,disabled:this.getProp("disabled")||e.disabled||!1,openIcon:this.getProp("openIcon")||e.openIcon||"",closedIcon:this.getProp("closedIcon")||e.closedIcon||"",children:this.isFile?[]:this.childItems.length?this.childItems:e.children||[]}}templateContext(){const e=this.getPropsContext();return this.createTemplateContext({...e,component:this,label:this.label,content:this.content,type:this.type,isTreeSemantic:this.isTreeSemantic,isFile:this.isFile,children:this.childItems,hasChildren:this.hasChildren,rootClass:this.getRootClass(),rootStyle:this.getRootStyle(),onToggle:this.handleToggle,onItemClick:this.handleItemClick})}template(){return c(this.templateContext())}setOpen(e=!0){const t=Boolean(e);return this.isFile||!this.hasChildren||this.getProp("disabled")||this.getProp("open")===t||(this.toggleAttribute("open",t),this.emitComponentEvent("tree-item-toggle",{item:this,open:t,value:this.getProp("value")})),this}open(){return this.setOpen(!0)}close(){return this.setOpen(!1)}toggle(){return this.setOpen(!this.getProp("open"))}onToggle(e,t){return"function"==typeof e&&this.addEventListener("sf-tree-item-toggle",t=>{e(t.detail?.open,t.detail,t)},t),this}handleToggle=e=>{e.preventDefault(),e.stopPropagation(),this.toggle()};handleItemClick=e=>{this.getProp("disabled")?e.preventDefault():this.emitComponentEvent("tree-item-click",{item:this,value:this.getProp("value"),originalEvent:e})}}).define("sf-tree-item")})();