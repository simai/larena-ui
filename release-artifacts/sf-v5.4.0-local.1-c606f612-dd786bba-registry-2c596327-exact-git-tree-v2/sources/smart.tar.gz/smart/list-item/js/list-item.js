(()=>{"use strict";const e="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},t="undefined"!=typeof window?window:{},a=e.SfBaseElement||t.SfBaseElement;if(!a)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const s=e.html||t.html,i=e.nothing||t.nothing,o=(e.render||t.render,e.litProps||t.litProps,e.toBoolean,e.toAttributeName,e.toNumber,e.normalizeEnum,e.parseJsonAttribute,a);(class extends o{static get props(){return{templateName:{attribute:"template",default:"default"},itemTemplate:{type:String,default:""},type:{default:"text",values:["text","icon","checkbox","avatar","color"]},size:{default:"1",values:["1/3","1/2","1","2","3"]},text:{default:""},icon:{default:"person"},checked:{type:Boolean,default:!1},selected:{type:Boolean,default:!1},disabled:{type:Boolean,default:!1},colorClass:{default:"bg-tertiary"},avatarImageUrl:{default:""},avatarTitle:{default:""},value:{default:""},ariaLabel:{default:""}}}get componentName(){return"list-item"}get templateName(){return this.getAttribute("template")||"default"}get type(){return this.getEnumAttr("type",["text","icon","checkbox","avatar","color"],"text")}get size(){return this.getEnumAttr("size",["1/3","1/2","1","2","3"],"1")}get sizeGroup(){return"1/3"===(e=this.size)||"1/2"===e?{item:e,checkbox:"1/3",avatarGroup:"1/2",colorTag:"1/2"}:{item:e,checkbox:"1",avatarGroup:e,colorTag:"1"};var e}get text(){return this.getAttribute("text")||""}get icon(){return this.getAttribute("icon")||"person"}get checked(){return this.getBooleanAttr("checked",!1)}set checked(e){e?this.setAttribute("checked",""):this.removeAttribute("checked")}get selected(){return this.getBooleanAttr("selected",!1)}get disabled(){return this.getBooleanAttr("disabled",!1)}get colorClass(){return this.getAttribute("color-class")||"bg-tertiary"}get avatarImageUrl(){return this.getAttribute("avatar-image-url")||""}get avatarTitle(){return this.getAttribute("avatar-title")||this.text}get value(){return this.getAttribute("value")||""}get ariaLabel(){return this.getAttribute("aria-label")||""}templateContext(){const e=this.getPropsContext();return this.createTemplateContext({...e,component:this,sizeGroup:this.sizeGroup,avatarTitle:this.avatarTitle})}template(){return function(e){const t=e.component?.hasSlotContent?.("text")?e.component.getSlotContent("text"):e.text,a=e.component?.hasSlotContent?.("leading")?e.component.getSlotContent("leading"):i,o=e.component?.hasSlotContent?.("trailing")?e.component.getSlotContent("trailing"):i,r=["sf-list-item","cursor-pointer","flex","items-cross-center",`sf-list-item--${e.type}`,`sf-list-item--size-${e.size}`,"transition",e.selected?"selected":"",e.disabled?"disabled":""].filter(Boolean),l=["sf-list-item-wrap","flex","flex-1"];return["icon","checkbox","avatar","color"].includes(e.type)&&l.push("flex","flex-row","flex-nowrap","items-center","gap-2"),"avatar"!==e.type&&"color"!==e.type||(l.splice(l.indexOf("gap-2"),1),l.push("justify-between","gap-2")),s`
        <div
                class=${r.join(" ")}
                role="button"
                tabindex=${e.disabled?"-1":"0"}
                data-value=${null===e.value||void 0===e.value?i:String(e.value)}
                aria-label=${e.ariaLabel||i}
                aria-disabled=${e.disabled?"true":i}
                aria-selected=${e.selected?"true":i}
        >
            <div class=${l.join(" ")}>
                ${(()=>{if(a!==i)return a;if("icon"===e.type)return s`<i class="sf-icon">${e.icon}</i>`;if("checkbox"===e.type)return s`
                <label
                        class="sf-checkbox sf-checkbox--size-${e.sizeGroup.checkbox} flex"
                        @click=${e=>e.stopPropagation()}
                >
          <span class="sf-checkbox-box transition flex">
            <input
                    .checked=${e.checked}
                    ?disabled=${e.disabled}
                    type="checkbox"
                    @change=${t=>e.component?.handleCheckedChange?.(t)}
            />
            <span class="sf-icon" aria-hidden="true"></span>
          </span>
                </label>
            `;if("avatar"===e.type)return s`
                <sf-avatar
                        image-url="${e.avatarImageUrl}"
                        template="${e.itemTemplate}"
                        size="${"1/3"===e.sizeGroup.item||"1/2"===e.sizeGroup.item?"1/3":"1"===e.sizeGroup.item?"1/2":"2"===e.sizeGroup.item?"1":"2"}"
                        title="${e.avatarTitle}"
                ></sf-avatar>
            `;if("color"===e.type){const a=["sf-tag","sf-tag--color",`sf-tag--size-${e.sizeGroup.colorTag}`,"flex","flex-row","flex-nowrap","items-center","flex-1",e.disabled?"disabled":""].filter(Boolean);return s`
                <div class=${a.join(" ")}>
                    <span class="sf-tag-color-icon ${e.colorClass}"></span>
                    <span class="sf-tag-container">${t}</span>
                </div>
            `}return i})()} ${"color"===e.type||"avatar"===e.type?i:s`
            <div class="sf-list-item-container">${t}</div>`} ${o!==i?o:"avatar"===e.type||"color"===e.type?s`
                <sf-checkbox
                        size="${e.sizeGroup.checkbox}"
                        .checked=${e.checked}
                        ?disabled=${e.disabled}
                        @click=${e=>e.stopPropagation()}
                        @change=${t=>e.component?.handleCheckedChange?.(t)}>
                </sf-checkbox>
            `:i}
            </div>
        </div>
    `}(this.templateContext())}async afterRender(){await this.whenChildrenDefined(),this.syncCheckedControls()}syncCheckedControls(){const e=this.checked;this.querySelectorAll("sf-checkbox").forEach(t=>{"function"==typeof t.setChecked?t.setChecked(e):e?t.setAttribute("checked",""):t.removeAttribute("checked");const a=t.querySelector?.('input[type="checkbox"]');a&&(a.checked=e)}),this.querySelectorAll('.sf-list-item > .sf-list-item-wrap input[type="checkbox"]').forEach(t=>{t.checked=e})}setChecked(e=!1){const t=Boolean(e);return this.checked===t||(this.checked=t),this}handleCheckedChange(e){const t=e?.target?.closest?.('input[type="checkbox"]'),a=e?.target?.closest?.("sf-checkbox"),s="boolean"==typeof t?.checked?t.checked:Boolean(a?.checked);this.setChecked(s),console.log(this.value),this.dispatchEvent(new CustomEvent("sf-list-item:change",{bubbles:!0,composed:!0,detail:{checked:s,selected:this.selected,value:this.value,item:this}}))}get data(){return{template:this.templateName,type:this.type,size:this.size,text:this.text,icon:this.icon,checked:this.checked,selected:this.selected,disabled:this.disabled,colorClass:this.colorClass,avatarImageUrl:this.avatarImageUrl,avatarTitle:this.avatarTitle,value:this.value,ariaLabel:this.ariaLabel}}set value(e){e&&"object"==typeof e?this.setValueAttributes(e):null!=e&&""!==e?this.setAttribute("value",String(e)):this.removeAttribute("value")}}).define("sf-list-item")})();