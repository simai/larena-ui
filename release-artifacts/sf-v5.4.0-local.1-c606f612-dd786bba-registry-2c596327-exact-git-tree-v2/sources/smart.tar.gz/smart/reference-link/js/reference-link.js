(()=>{"use strict";const t="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},e="undefined"!=typeof window?window:{},r=t.SfBaseElement||e.SfBaseElement;if(!r)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const a=t.html||e.html,n=t.nothing||e.nothing,i=(t.render||e.render,t.litProps||e.litProps,t.toBoolean,t.toAttributeName,t.toNumber,t.normalizeEnum,t.parseJsonAttribute,r);(class extends i{static get props(){return{templateName:{attribute:"template",default:"default"},icon:{default:"arrow_forward"},label:{default:""},text:{default:""},href:{default:""},target:{default:"_self"},disabled:{type:Boolean,default:!1},ariaLabel:{default:""}}}get templateName(){return this.getAttribute("template")||"default"}get icon(){return this.getAttribute("icon")||"arrow_forward"}get label(){return this.getAttribute("label")||""}get text(){return this.getAttribute("text")||""}get href(){return this.getAttribute("href")||""}get target(){return this.getAttribute("target")||"_self"}get disabled(){return this.getBooleanAttr("disabled",!1)}get ariaLabel(){return this.getAttribute("aria-label")||""}templateContext(){const t=this.getPropsContext();return this.createTemplateContext({...t,component:this,rootClass:this.getRootClass()})}template(){return function(t){const{component:e,icon:r,label:i,text:o,href:l,target:s,disabled:d,ariaLabel:f,rootClass:u}=t,c=["sf-reference-link","flex","items-cross-center",d?"disabled":"",u].filter(Boolean).join(" "),m=e?.hasSlotContent?.("label")?e.getSlotContent("label"):i,p=e?.hasSlotContent?.("text")?e.getSlotContent("text"):o,b=l&&!d?a`
          <a
            href=${l}
            target=${s||n}
            rel=${s&&"_self"!==s?"noopener noreferrer":n}
            aria-label=${f||n}
          >
            ${m}
          </a>
        `:a`<span>${m}</span>`;return a`
    <div
      class=${c}
      @click=${e?.handleRootClick}
      aria-disabled=${d?"true":n}
    >
      <div class="sf-reference-link-left flex items-cross-center">
        <i class="sf-icon" aria-hidden="true">${r}</i>
        ${b}
      </div>
      <div class="sf-reference-link-text">${p}</div>
    </div>
  `}(this.templateContext())}handleRootClick=t=>{this.disabled&&(t.preventDefault(),t.stopPropagation(),"function"==typeof t.stopImmediatePropagation&&t.stopImmediatePropagation())};onClick(t,e){return"function"==typeof t&&this.addEventListener("click",t,e),this}}).define("sf-reference-link")})();