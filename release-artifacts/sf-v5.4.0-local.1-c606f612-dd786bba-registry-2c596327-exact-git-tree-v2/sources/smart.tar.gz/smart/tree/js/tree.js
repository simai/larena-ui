(()=>{"use strict";const e="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},t="undefined"!=typeof window?window:{},r=e.SfBaseElement||t.SfBaseElement;if(!r)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const i=e.html||t.html,o=e.nothing||t.nothing,n=(e.render||t.render,e.litProps||t.litProps,e.toBoolean,e.toAttributeName,e.toNumber,e.normalizeEnum,e.parseJsonAttribute,r);function s(e){const t=function(...e){return e.flat().filter(Boolean).join(" ")}("sf-tree flex flex-col",e.rootClass);return i`
    <div
      class=${t}
      style=${e.rootStyle||o}
      role=${e.role||"tree"}
      aria-label=${e.ariaLabel||o}
    >
      ${(e.items||[]).map(e=>function(e={}){return i`
    <sf-tree-item
      label=${e.label||o}
      href=${e.href||o}
      target=${e.target||o}
      rel=${e.rel||o}
      type=${e.type||o}
      value=${e.value||o}
      open-icon=${e.openIcon||o}
      closed-icon=${e.closedIcon||o}
      ?open=${Boolean(e.open)}
      ?selected=${Boolean(e.selected)}
      ?active=${Boolean(e.active)}
      ?disabled=${Boolean(e.disabled)}
      semantic
      .itemsData=${e.children||[]}
    ></sf-tree-item>
  `}(e))}
    </div>
  `}function a(e){return e?.nodeType===Node.ELEMENT_NODE&&"sf-tree-item"===e?.tagName?.toLowerCase?.()}function l(e){return Array.from(e?.childNodes||[]).filter(e=>!a(e)).map(e=>e.textContent||"").join(" ").replace(/\s+/g," ").trim()}function c(e){if("function"==typeof e?.toTreeItemData)return e.toTreeItemData();const t=Array.from(e?.children||[]).filter(a).map(c);return{label:e.getAttribute("label")||e.getAttribute("text")||e.getAttribute("title")||l(e),href:e.getAttribute("href")||"",target:e.getAttribute("target")||"",rel:e.getAttribute("rel")||"",type:e.getAttribute("type")||"",value:e.getAttribute("value")||"",open:e.hasAttribute("open"),selected:e.hasAttribute("selected"),active:e.hasAttribute("active"),disabled:e.hasAttribute("disabled"),openIcon:e.getAttribute("open-icon")||"",closedIcon:e.getAttribute("closed-icon")||"",children:t}}(class extends n{static get props(){return{templateName:{attribute:"template",default:"default"},rootClass:{default:""},ariaLabel:{attribute:"aria-label",default:""},role:{default:"tree"}}}constructor(){super(),this._itemObserver=null,this._itemsData=[]}connectedCallback(){this.observeItemChildren(),this.captureInitialItems(),super.connectedCallback()}disconnectedCallback(){this.disconnectItemObserver(),super.disconnectedCallback()}observeItemChildren(){this._itemObserver||(this._itemObserver=new MutationObserver(e=>{e.some(e=>Array.from(e.addedNodes||[]).some(a))&&this.captureInitialItems()&&this.requestComponentUpdate("items")}),this._itemObserver.observe(this,{childList:!0}))}disconnectItemObserver(){this._itemObserver?.disconnect?.(),this._itemObserver=null}captureInitialItems(){const e=Array.from(this.childNodes||[]).filter(a);return!!e.length&&(this._itemsData=e.map(c),e.forEach(e=>e.remove()),!0)}get items(){return this._itemsData}templateContext(){const e=this.getPropsContext();return this.createTemplateContext({...e,component:this,items:this.items,rootClass:this.getRootClass(),rootStyle:this.getRootStyle()})}template(){return s(this.templateContext())}onToggle(e,t){return"function"==typeof e&&this.addEventListener("sf-tree-item-toggle",t=>{e(t.detail?.item,t.detail,t)},t),this}}).define("sf-tree")})();