(()=>{"use strict";const e="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},t="undefined"!=typeof window?window:{},s=e.SfBaseElement||t.SfBaseElement;if(!s)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const i=e.html||t.html,r=e.nothing||t.nothing,a=(e.render||t.render,e.litProps||t.litProps,e.toBoolean,e.toAttributeName),n=(e.toNumber,e.normalizeEnum,e.parseJsonAttribute,s);function l(...e){return e.flat().filter(Boolean).join(" ")}function o(e,t=""){return e?i`
    <sf-icon icon="${e}" aria-hidden=${t?"false":"true"}></sf-icon>
  `:r}function d(e,t){const s=!e.current&&!e.disabled,a=!e.href||e.disabled||e.current?s?"button":"div":"a",n=l("sf-breadcrumbs-item",e.current?"":"sf-breadcrumbs-item--link",e.current||e.ellipsis?"sf-breadcrumbs-item--default":"",e.active?"active":"",e.disabled?"disabled":"",t.itemClass,e.current?t.currentClass:t.linkClass,e.itemClass),d=l("sf-breadcrumbs-item-container flex items-cross-center",t.containerClass,e.containerClass),c=i`
    <span class=${d}>
      ${function(e,t){const s=`item-${e.index}`,a=t.component?.hasSlotContent?.(s)?t.component.getSlotContent(s):r;return a!==r?a:i`
    ${o(e.icon)}
    ${e.label?i`<span>${e.label}</span>`:r}
  `}(e,t)}
    </span>
  `,u=n,m=e.current?"page":r,h=e.ariaLabel||r,p=String(e.index);return"a"===a?i`
      <a
        href=${e.href}
        class=${u}
        target=${e.target||r}
        rel=${e.rel||r}
        aria-current=${m}
        aria-label=${h}
        data-sf-breadcrumb-index=${p}
        @click=${s=>t.component?.handleItemClick?.(s,e)}
      >
        ${c}
      </a>
    `:"button"===a?i`
      <button
        type="button"
        class=${u}
        ?disabled=${e.disabled}
        aria-current=${m}
        aria-label=${h}
        data-sf-breadcrumb-index=${p}
        @click=${s=>t.component?.handleItemClick?.(s,e)}
      >
        ${c}
      </button>
    `:i`
    <div
      class=${u}
      aria-current=${m}
      aria-label=${h}
      data-sf-breadcrumb-index=${p}
      @click=${s=>t.component?.handleItemClick?.(s,e)}
    >
      ${c}
    </div>
  `}function c(e){const t=l("sf-breadcrumbs flex items-cross-center",e.rootClass);return i`
    <nav class=${t} aria-label=${e.ariaLabel||"Breadcrumb"}>
      ${e.items.map((t,s)=>i`
        ${s>0?function(e,t){const s=`separator-${t}`,a=e.component?.hasSlotContent?.(s)?e.component.getSlotContent(s):r;return i`
    <div
      class=${l("sf-breadcrumbs-item sf-breadcrumbs-item--default",e.separatorClass)}
      aria-hidden="true"
      data-sf-breadcrumb-separator=${String(t)}
    >
      <span class="sf-breadcrumbs-item-container flex items-cross-center">
        ${a!==r?a:o(e.separatorIcon)}
      </span>
    </div>
  `}(e,s-1):r}
        ${d(t,e)}
      `)}
    </nav>
  `}function u(e={},t=0,s=0,i={}){if("string"==typeof e)return u({label:e},t,s,i);const{defaultCurrent:r=!0}=i,a=e.label||e.text||e.title||"",n=Boolean(e.current||e.active||r&&t===s-1),l=Boolean(e.ellipsis||"..."===a),o=e.hiddenItems||e.hiddenitems||e["hidden-items"]||e.items,d=o?m(o,{defaultCurrent:!1}):[];return{label:l?"...":a,href:e.href||e.url||"",icon:e.icon||"",current:n,active:Boolean(e.active||n),disabled:Boolean(e.disabled),ellipsis:l,target:e.target||"",rel:e.rel||"",itemClass:e.itemClass||e["item-class"]||"",containerClass:e.containerClass||e["container-class"]||"",ariaLabel:e.ariaLabel||e["aria-label"]||"",value:e.value||"",hiddenItems:d,index:t}}function m(e="",t={}){if(Array.isArray(e))return e.map((s,i)=>u(s,i,e.length,t));const s=String(e||"").trim();if(!s)return[];try{const e=JSON.parse(s);if(Array.isArray(e))return e.map((s,i)=>u(s,i,e.length,t))}catch{}const i=s.split("|").map(e=>e.trim()).filter(Boolean);return i.map((e,s)=>{const[r,...a]=e.split("::"),n=function(e=""){const t=String(e||"").split(",").map(e=>e.trim()).filter(Boolean),s={};return t.forEach(e=>{const[t,...i]=e.split("="),r=String(t||"").trim().toLowerCase(),a=i.join("=").trim();r&&(["current","active","disabled","ellipsis"].includes(r)?s[r]=!a||!["0","false","no"].includes(a.toLowerCase()):s[r]=a)}),s}(a.join(","));return u({label:r.trim(),...n},s,i.length,t)})}(class extends n{static itemTemplateSlot="__items";static get props(){return{templateName:{attribute:"template",default:"default"},items:{default:[],parser:e=>m(e)},separatorIcon:{default:"chevron_right"},homeIcon:{default:"home"},homeLabel:{default:""},rootClass:{default:""},itemClass:{default:""},linkClass:{default:""},currentClass:{default:""},separatorClass:{default:""},containerClass:{default:""},ariaLabel:{default:"Breadcrumb"},expandOnEllipsis:{default:!0,type:Boolean},maxItems:{default:4,type:Number}}}constructor(){super(),this._itemObserver=null,this._readyCaptureHandler=null,this._ellipsisExpanded=!1,this._preserveEllipsisExpanded=!1}connectedCallback(){this._isMounted||(this.observeItemChildren(),this.style.display="contents",this.hasAttribute("items")||this.captureInitialItems()?this.mountComponent():this.scheduleReadyCapture())}disconnectedCallback(){this.disconnectItemObserver(),this.cancelReadyCapture(),super.disconnectedCallback()}get items(){return this.getProp("items")}attributeChangedCallback(e,t,s){super.attributeChangedCallback(e,t,s),"items"!==e||t===s||this._preserveEllipsisExpanded||(this._ellipsisExpanded=!1),"items"===e&&t!==s&&this.isConnected&&!this._isMounted&&this.mountComponent()}mountComponent(){this.isConnected&&!this._isMounted&&super.connectedCallback()}observeItemChildren(){this._itemObserver||(this._itemObserver=new MutationObserver(()=>{this.captureInitialItems()&&(this.cancelReadyCapture(),this._isMounted?this._isMounted&&this.requestComponentUpdate("items"):this.mountComponent())}),this._itemObserver.observe(this,{childList:!0}))}scheduleReadyCapture(){"loading"!==document.readyState||this._readyCaptureHandler||(this._readyCaptureHandler=()=>{this._readyCaptureHandler=null,this.captureInitialItems()&&this.mountComponent()},document.addEventListener("DOMContentLoaded",this._readyCaptureHandler,{once:!0}))}cancelReadyCapture(){this._readyCaptureHandler&&(document.removeEventListener("DOMContentLoaded",this._readyCaptureHandler),this._readyCaptureHandler=null)}disconnectItemObserver(){this._itemObserver?.disconnect?.(),this._itemObserver=null}isItemNode(e){if(!e||e.nodeType!==Node.ELEMENT_NODE)return!1;const t=e?.tagName?.toLowerCase?.();return"item"===t||"sf-breadcrumbs-item"===t||e?.hasAttribute?.("data-sf-breadcrumb-item")}captureInitialItems(){return this.captureChildTemplates(this.constructor.itemTemplateSlot,e=>this.isItemNode(e)).length>0}getCapturedItems(){return(this._slotTemplates.get(this.constructor.itemTemplateSlot)||[]).map(e=>{const t=e.getAttribute("label")||e.getAttribute("text")||e.getAttribute("title")||e.textContent?.trim()||"";return{label:t,href:e.getAttribute("href")||e.getAttribute("url")||"",icon:e.getAttribute("icon")||"",current:e.hasAttribute("current")||void 0,active:e.hasAttribute("active")||void 0,disabled:e.hasAttribute("disabled"),ellipsis:e.hasAttribute("ellipsis")||"..."===t,target:e.getAttribute("target")||"",rel:e.getAttribute("rel")||"",itemClass:e.getAttribute("item-class")||"",containerClass:e.getAttribute("container-class")||"",ariaLabel:e.getAttribute("aria-label")||"",value:e.getAttribute("value")||"",hiddenItems:m(e.getAttribute("hidden-items")||e.getAttribute("items")||"",{defaultCurrent:!1})}})}get sourceItems(){const e=this.items;if(e.length)return e.map((t,s)=>u(t,s,e.length));const t=this.getCapturedItems();return t.length?t.map((e,s)=>u(e,s,t.length)):[]}get normalizedItems(){const e=this.sourceItems;return this.getDisplayItems(e)}getDisplayItems(e=[]){const t=this.getNumberAttr("maxItems",4);if(this._ellipsisExpanded||t<3||e.length<=t)return this.reindexItems(e);const s=t-1,i=Math.floor(s/2),r=s-i,a=e.slice(0,i),n=e.slice(e.length-r),l=e.slice(i,e.length-r);return l.length?this.reindexItems([...a,u({label:"...",ellipsis:!0,hiddenItems:l,ariaLabel:"Show hidden breadcrumbs"},i,e.length,{defaultCurrent:!1}),...n]):this.reindexItems(e)}reindexItems(e=[]){return e.map((t,s)=>({...t,index:s,current:Boolean(t.current&&s===e.length-1),active:Boolean(t.active||t.current&&s===e.length-1)}))}templateContext(){const e=this.getPropsContext();return this.createTemplateContext({...e,component:this,items:this.normalizedItems,rootClass:this.getRootClass()})}template(){return c(this.templateContext())}get state(){return{...this.getPropsContext(),items:this.normalizedItems,rootClass:this.getRootClass()}}setState(e={}){return Object.entries(e||{}).forEach(([e,t])=>{const s=a(e);s&&(!1!==t&&null!=t?Array.isArray(t)?this.setAttribute(s,JSON.stringify(t)):this.setAttribute(s,!0===t?"":String(t)):this.removeAttribute(s))}),this}onItemClick(e,t){return"function"==typeof e&&this.addEventListener("sf-breadcrumb-click",t=>{e(t.detail?.item,t.detail,t)},t),this}expandEllipsis(e){if(!e?.ellipsis)return!1;if(!e.hiddenItems?.length)return this._ellipsisExpanded=!0,this.requestComponentUpdate("ellipsis"),!0;const t=this.normalizedItems.flatMap(t=>t.index!==e.index?[t]:e.hiddenItems);this._ellipsisExpanded=!0,this._preserveEllipsisExpanded=!0;try{this.setState({items:t.map((e,s)=>({...e,index:s,active:!1,current:Boolean(e.current&&s===t.length-1)}))})}finally{this._preserveEllipsisExpanded=!1}return!0}handleItemClick=(e,t)=>{(t.disabled||t.current)&&e.preventDefault();const s=new CustomEvent("sf-breadcrumb-click",{bubbles:!0,composed:!0,cancelable:!0,detail:{component:this,tagName:this.componentTagName,template:this.componentTemplateName,item:t,index:t.index,items:this.normalizedItems,originalEvent:e}});this.dispatchEvent(s),t.ellipsis&&this.getBooleanAttr("expandOnEllipsis",!0)&&!s.defaultPrevented&&this.expandEllipsis(t)}}).define("sf-breadcrumbs")})();