(()=>{"use strict";const e="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},t="undefined"!=typeof window?window:{},n=e.SfBaseElement||t.SfBaseElement;if(!n)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const s=e.html||t.html,i=e.nothing||t.nothing,a=e.render||t.render,r=(e.litProps||t.litProps,e.toBoolean,e.toAttributeName,e.toNumber,e.normalizeEnum,e.parseJsonAttribute,n),o=new Set(["а","без","в","во","для","до","за","из","из-за","из-под","и","к","ко","между","на","над","о","об","от","по","под","при","про","с","со","у","через","the","a","an","and","for","from","in","of","on","to"]);function l(e="",t={}){const{maxLetters:n=2,skipWords:s=o}=t,i=function(e=""){return String(e||"").trim().split(/[\s/|]+/).map(e=>e.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu,"")).filter(Boolean)}(e),a=i.filter((e,t)=>0===t||!s.has(String(e).toLowerCase()));return a.length?a.length>1?a.slice(0,n).map(e=>Array.from(e)[0]||"").join("").toUpperCase():Array.from(a[0]).slice(0,1).join("").toUpperCase():""}function c(...e){return e.flat().filter(Boolean).join(" ")}function m(e){const t=l(e);return s`<span
    class="sf-admin-menu-item-placeholder flex items-cross-center content-main-center flex-none"
    >${t}</span
  >`}function u(e,t=""){return e?function(e=""){const t=String(e||"").trim();return!!t&&(/^(https?:)?\/\//i.test(t)||/^(data:image\/|blob:)/i.test(t)||t.startsWith("/")||t.startsWith("./")||t.startsWith("../")||/\.(svg|png|jpe?g|webp|gif|avif)(\?.*)?(#.*)?$/i.test(t))}(e)?s`<span class="sf-admin-menu-item-icon flex-none">
      <img
        src=${e}
        class="w-full h-full object-contain"
        alt=${t}
        aria-hidden=${t?i:"true"}
      />
    </span> `:s` <sf-icon
    root-class="flex-none"
    aria-hidden="true"
    icon="${e}"
  ></sf-icon>`:i}function d(e){return e.badge?s` <sf-badge
    size="1/3"
    type="main"
    scheme="primary"
    text="${e.badge}"
  ></sf-badge>`:i}function p(e){const t=e.component,{panels:n,hasHidden:a,visible:r,open:o,menuSettings:l,searchQuery:p,searchResults:f}=t.state;function h(t,n=i,a=!1){return e.compact?s`<span
          class="sf-admin-menu-item-container flex items-cross-center flex-1"
        >
              ${t.leftIcon?u(t.leftIcon):t.placeholder?m(t.label):i}
        </span> `:s`
          <span
            class="sf-admin-menu-item-container max-w-full wrap-none flex items-cross-center flex-1"
          >
            ${t.leftIcon?u(t.leftIcon):t.placeholder?m(t.label):i}
            <span class="overflow-hidden whitespace-nowrap t-ellipsis"
              >${t.label}</span
            >
          </span>
          ${a?i:t.badge?d(t):n}
        `}function g(e){const n=s`
      <span
        class="sf-admin-menu-item-container max-w-full wrap-none flex items-cross-center flex-1"
      >
        ${e.leftIcon?u(e.leftIcon):e.placeholder?m(e.label):i}
        <span class="flex flex-col min-w-0">
          <span class="overflow-hidden whitespace-nowrap t-ellipsis"
            >${e.label}</span
          >
          ${function(e){const t=(e.path||[]).slice(0,-1);return t.length?s`
      <span
        class="sf-admin-menu-search-result-path sf-text-1/3 color-on-surface-variant overflow-hidden whitespace-nowrap t-ellipsis"
        >${t.join(" / ")}</span
      >
    `:i}(e)}
        </span>
      </span>
      ${e.badge?d(e):i}
    `;return e.href&&"#"!==e.href?s`
        <li class="sf-admin-menu-item-wrap flex items-cross-center">
          <a
            class="sf-admin-menu-item flex items-cross-center flex-1 max-w-full min-w-0"
            href=${e.href}
            target=${e.target||i}
            rel=${e.rel||i}
            @click=${n=>t.openSearchResult(e,n)}
          >
            ${n}
          </a>
        </li>
      `:s`
      <li class="sf-admin-menu-item-wrap flex items-cross-center">
        <button
          type="button"
          class="sf-admin-menu-item flex items-cross-center flex-1 max-w-full min-w-0"
          @click=${n=>t.openSearchResult(e,n)}
        >
          ${n}
        </button>
      </li>
    `}function b(n=!0,a=null){return n?e.logo||e.brand?s`
        <div class="sf-admin-menu-head flex flex-none">
          <div class="sf-admin-menu-head-container flex items-cross-center">
            ${e.logo?s`<a
                  class="sf-admin-menu-head-logo flex"
                  href=${e.logoHref||"#"}
                >
                  <img
                    class="sf-admin-menu-logo"
                    src=${e.logo}
                    alt=${e.brand||""}
                  />
                </a>`:i}
            ${e.brand?s`<span>${e.brand}</span>`:i}
          </div>
        </div>
      `:i:s` <div
        class="sf-admin-menu-head items-cross-center flex content-main-between flex-none"
      >
        <div class="sf-admin-menu-head-container flex items-cross-center">
          <sf-icon-button
            @click=${e=>{e.preventDefault(),e.stopPropagation(),t.togglePanel(a.panelId,!1)}}
            type="link"
            scheme="on-surface"
            aria-label="Back"
            icon="chevron_left"
          ></sf-icon-button>
          <span>${a.label}</span>
        </div>
      </div>`}function v(e,a=!1){if("divider"===e.type)return function(e,n=!1){const a=n&&l,c=!l&&!o&&n&&r[e.panelId]&&!r[e.panelId].visible;return s`
      <li
        :key=${e.panelId}
        data-order="${e.order}"
        data-panel-id="${e.panelId}"
        :ref=${n?t.getItemRef(e.panelId):i}
        class="sf-admin-menu-item-wrap sf-admin-menu-divider-wrap flex items-cross-center${c?" hidden":""}${a?" settings-on relative":""}"
        role="presentation"
      >
        ${a?s` <sf-icon-button
              id="${e.panelId}_move"
              type="link"
              data-move
              scheme="on-surface"
              aria-label="Set order"
              icon="drag_indicator"
              root-class="cursor-move"
            ></sf-icon-button>`:i}
        <span
          class="sf-admin-menu-divider flex-1${a?" settings-active":""}"
        >
          <span
            class="flex flex-1"
            role="separator"
            aria-orientation="horizontal"
          ></span>
        </span>
        ${a?s` <sf-icon-button
              id="${e.panelId}_settings"
              type="link"
              @click=${e=>t.openContextMenu(e)}
              data-settings
              scheme="on-surface"
              aria-label="Item Settings"
              root-class="absolute sf-admin-menu-item-settings"
              icon="more_vert"
            ></sf-icon-button>`:i}
      </li>
    `}(e,a);const m=r[e.panelId],d=!0===m?.temp,p=a&&l,f=!l&&!o&&a&&!d&&!1===m?.visible,g=c("sf-admin-menu-item flex items-cross-center flex flex-1 max-w-full min-w-0",e.active||e.current?"active":"",d?" opacity-5":"",e.disabled?"disabled":"",p?"settings-active":""),b=e.hidden&&!d||f;return s`
      <li
        :key=${e.panelId}
        data-order="${e.order}"
        data-panel-id="${e.panelId}"
        :ref=${a?t.getItemRef(e.panelId):i}
        class="sf-admin-menu-item-wrap flex items-cross-center${b?" hidden":""}${p?" settings-on relative":""}"
      >
        <!-- Продумать touch-action: none;-->
        ${p?s` <sf-icon-button
              id="${e.panelId}_move"
              type="link"
              data-move
              scheme="on-surface"
              aria-label="Set order"
              icon="drag_indicator"
              root-class="cursor-move"
            ></sf-icon-button>`:i}
        ${e.children?.length?function(e,i,a=!1){const r=u("chevron_right");return s`
      <button
        type="button"
        class=${i}
        aria-expanded=${n[e.panelId]?.open?"true":"false"}
        @click=${n=>{n.preventDefault(),n.stopPropagation(),t.togglePanel(e.panelId,!0)}}
        ?disabled=${Boolean(e.disabled)}
      >
        ${h(e,r,a)}
      </button>
    `}(e,g,p):function(e,t,n=!1){return e.disabled?s`
        <span class=${t} aria-disabled="true">
          ${h(e,n)}
        </span>
      `:s`
      <a
        class=${t}
        href=${e.href||"#"}
        target=${e.target||i}
        rel=${e.rel||i}
        aria-current=${e.current?"page":i}
      >
        ${h(e,i,n)}
      </a>
    `}(e,g,p)}
        ${p?s` <sf-icon-button
              id="${e.panelId}_settings"
              type="link"
              @click=${e=>t.openContextMenu(e,{tempVisible:d})}
              data-settings
              scheme="on-surface"
              aria-label="Item Settings"
              root-class="absolute sf-admin-menu-item-settings"
              icon="more_vert"
            ></sf-icon-button>`:i}
      </li>
    `}function x(e,t=1){return e.children?.length?s`
      <section
        class=${c("sf-admin-menu-panel sf-admin-menu-panel-sub flex flex-col transition-all top-0 bottom-0 absolute overflow-hidden z-7",n[e.panelId]?.open?"translate-x-0":"-translate-x-full")}
        data-panel=${e.panelId}
        data-level=${t}
        aria-label=${e.label||i}
      >
        ${b(!1,e)}
        <nav
          class="sf-admin-menu-section sf-admin-menu-main-sub flex-auto min-h-0"
        >
          <ul class="p-0 m-0 gap-1/3 flex flex-col">
            ${e.children.map(e=>v(e))}
          </ul>
        </nav>
      </section>
      ${e.children.map(e=>x(e,t+1))}
    `:i}const I=c("sf-admin-menu-panel flex flex-col overflow-hidden z-6",e.compact?"small":"",e.panelClass);return s`
    <aside
      :ref=${t.refs.mainPanel}
      class=${c("sf-admin-menu flex h-full relative z-6",e.rootClass)}
      style=${e.rootStyle||i}
      aria-label=${e.ariaLabel||i}
    >
      <section class=${I}>
        ${b()} ${e.searchable?s`
      <div class="sf-admin-menu-search flex-none">
        ${e.compact?s` <button
              id="search_toggle_menu"
              @click=${()=>t.toggleCompact()}
              type="button"
              class="sf-admin-menu-item flex items-cross-center"
            >
              <span
                class="sf-admin-menu-item-container flex items-cross-center flex-1"
              >
                <i class="sf-icon sf-icon-loaded">search</i>
              </span>
            </button>`:i}
        ${e.compact?i:s` <sf-input
              size="1"
              type="filled"
              @input=${e=>{t.search(e.target.value)}}
              placeholder="${e.searchPlaceholder||i}"
              name="sf_admin_search_input"
              left-icon="search"
            ></sf-input>`}
      </div>
    `:i}
        <nav
          :ref=${t.refs.menuPanel}
          class="sf-admin-menu-section sf-admin-menu-main flex-auto min-h-0 ${o||l?"overflow-auto open":""}"
        >
          <ul class="p-0 m-0 gap-1/3 flex flex-col">
            ${(e.items||[]).map(e=>v(e,!0))}
            ${a&&!l?s` <li class="sf-admin-menu-item-wrap flex flex-col more">
                  <button
                    type="button"
                    @click=${()=>t.toggleOpen()}
                    class="sf-admin-menu-item flex items-cross-center"
                  >
                    <span
                      class="sf-admin-menu-item-container flex items-cross-center flex-1"
                      ><i class="sf-icon sf-icon-loaded"
                        >keyboard_arrow_${o?"up":"down"}</i
                      ><span class="sf-admin-menu-more-text"
                        >${o?"Свернуть":"Развернуть"}</span
                      ></span
                    >
                  </button>
                </li>`:i}
          </ul>
        </nav>
        ${e.bottomItems?.length||e.collapsible?s`
      <div class="sf-admin-menu-bottom flex-none">
        <nav>
          <ul class="p-0 m-0 gap-1/3 flex flex-col">
            ${(e.bottomItems||[]).map(e=>v(e))}
            ${e.collapsible||e.settings?s`
      <li class="sf-admin-menu-item-wrap flex flex-col">
        <button
          type="button"
          class="sf-admin-menu-item flex-1 flex items-cross-center"
        >
          <span
            class="sf-admin-menu-item-container flex items-cross-center flex-1"
          >
            <i class="sf-icon sf-icon-loaded">star</i>
            <span>Избранное</span>
          </span>
        </button>
      </li>
      <li class="sf-admin-menu-item-wrap flex flex-col">
        ${l?s` <div
              class="sf-admin-menu-item-segment flex items-cross-center"
            >
              <button
                type="button"
                @click="${()=>t.saveMenuSettings()}"
                class="sf-admin-menu-item segment-start flex-1 flex items-cross-center"
              >
                <span
                  class="sf-admin-menu-item-container flex items-cross-center flex-1"
                >
                  <i class="sf-icon sf-icon-loaded">save</i>
                  <span>Сохранить</span>
                </span>
              </button>
              <button
                @click=${e=>t.openContextMenu(e,{position:"left-bottom",items:[{component:"sf-button",props:{type:"link",scheme:"on-surface",iconLeft:"save",text:"Сохранить","@click":()=>{t.saveMenuSettings()}}},{component:"sf-button",props:{type:"link",scheme:"on-surface",iconLeft:"edit",text:"Изменить","@click":()=>{console.log("ok")}}},{component:"sf-button",props:{type:"link",scheme:"on-surface",iconLeft:"visibility",text:"Скрытые пункты","@click":()=>{t.toggleHidden()}}},{component:"sf-button",props:{type:"link",scheme:"on-surface",iconLeft:"horizontal_rule",text:"Добавить разделитель","@click":()=>{t.createDivider()}}}]})}
                type="button"
                class="sf-admin-menu-item segment-end flex items-cross-center"
                data-admin-menu-settings
              >
                <span
                  class="sf-admin-menu-item-container pointer-event-none flex items-cross-center flex-1"
                >
                  <sf-icon icon="settings"></sf-icon>
                </span>
              </button>
            </div>`:s` <div
              class="sf-admin-menu-item${e.collapsible&&e.settings?"-segment":""} flex items-cross-center"
            >
              ${e.settings&&!e.compact?s` <button
                    type="button"
                    @click="${()=>t.toggleMenuSettings()}"
                    class="sf-admin-menu-item flex-1${e.collapsible?" segment-start ":" "}flex items-cross-center"
                  >
                    <span
                      class="sf-admin-menu-item-container flex items-cross-center flex-1"
                    >
                      <i class="sf-icon sf-icon-loaded">settings</i>
                      <span>${e.settingsTitle}</span>
                    </span>
                  </button>`:i}
              ${e.collapsible?s`
                    <button
                      @click=${()=>t.toggleCompact()}
                      type="button"
                      class="sf-admin-menu-item${e.settings?" segment-end ":" "}flex items-cross-center"
                      data-admin-menu-toggle
                      aria-label=${e.compact?"Expand menu":"Collapse menu"}
                    >
                      <span
                        class="sf-admin-menu-item-container flex items-cross-center flex-1"
                      >
                        <sf-icon
                          icon="keyboard_double_arrow_${e.compact?"right":"left"}"
                        ></sf-icon>
                      </span>
                    </button>
                  `:i}
            </div>`}
      </li>
    `:i}
          </ul>
        </nav>
      </div>
    `:i}
      </section>
      ${(e.items||[]).map(e=>x(e))}
      ${(e.bottomItems||[]).map(e=>x(e))}
      ${e.searchable?s` <section
            class=${c("sf-admin-menu-panel sf-admin-menu-panel-search w-full flex flex-col transition-all top-0 bottom-0 bg-surface-1 absolute overflow-hidden z-5",n.search_panel?.open?"translate-x-full":"-translate-x-full")}
          >
            ${b(!1,{label:"Поиск",panelId:"search_panel"})}
            <nav
              class="sf-admin-menu-section sf-admin-menu-search-section flex-auto min-h-0 overflow-auto"
            >
              ${p?f?.length?s`
      <ul class="sf-admin-menu-search-results p-0 m-0 gap-1/3 flex flex-col">
        ${f.map(g)}
      </ul>
    `:s`
        <div class="sf-admin-menu-search-empty p-2 color-on-surface-variant">
          Ничего не найдено
        </div>
      `:i}
            </nav>
          </section>`:i}
    </aside>
  `}function f(e){if("undefined"==typeof SF||!SF.Loader)return;const t=SF.Loader,n=Number(t.dragObserverLockCount||0);t.dragObserverLockCount=e?n+1:Math.max(n-1,0),t.stopObserver=t.dragObserverLockCount>0}function h(e,t={}){const n="function"==typeof t.accept?t.accept:()=>!0;return Array.from(e?.children||[]).filter(e=>e instanceof HTMLElement&&!e.classList.contains("is-dragging")&&!e.classList.contains("drag-placeholder")&&n(e)).map(e=>{const t=e.getBoundingClientRect();return{item:e,top:t.top,height:t.height,middle:t.top+t.height/2}})}function g(e={}){const{handle:t,item:n,container:s,holdDelay:i=0,boundAttr:a="data-sf-sortable-drag-bound",draggingClass:r="is-dragging",placeholderClass:o="drag-placeholder",placeholderExtraClasses:l=[],shouldIgnorePointerDown:c,getAfterElement:m,getSortableItems:u,insertPlaceholder:d,onDragStart:p,onDrop:g,onCancel:b,dragContainer:v,minSortableItems:x=2}=e;if(!t||!n||!s)return null;if("1"===t.getAttribute(a))return null;t.setAttribute(a,"1");let I,y=!1,$=null,S=!1,w=0,M=0,C=null,E=null,L=[],_=null,A=null,k=null;const D=()=>{$&&(clearTimeout($),$=null)},N=()=>{Object.assign(n.style,{position:"",left:"",top:"",width:"",zIndex:"",pointerEvents:"",boxSizing:"",backgroundColor:""})},P=e=>{const t="function"==typeof m?m(s,e.clientY,e,L):function(e,t,n={}){const s=Array.isArray(n.itemsLayout)?n.itemsLayout:h(e,n);let i={offset:Number.NEGATIVE_INFINITY,element:null};for(const e of s){const n=t-e.middle;n<0&&n>i.offset&&(i={offset:n,element:e.item})}return i.element}(s,e.clientY,{itemsLayout:L});if(t!==I)if(I=t,"function"!=typeof d)if(t){if(_.nextSibling===t)return;s.insertBefore(_,t)}else{if(_.parentNode===s&&!_.nextSibling)return;s.appendChild(_)}else d(s,_,t,e)},O=e=>{if(y)return;if(e.preventDefault?.(),Number(x)>1){if((()=>{if("function"==typeof u){const e=u(s,n);return Array.isArray(e)?e:Array.from(e||[])}return h(s,{accept:"function"==typeof m?()=>!0:void 0}).map(e=>e.item)})().filter(e=>e instanceof HTMLElement&&!e.classList.contains(r)&&!e.classList.contains(o)).length<Number(x))return}y=!0,S=!0,f(!0),C=n.getBoundingClientRect(),E=s.getBoundingClientRect(),w=e.clientX-C.left,M=e.clientY-C.top,_=document.createElement(n.nodeName.toLowerCase()),_.className=o,_.style.width=`${C.width}px`,_.style.minHeight=`${C.height}px`,_.classList.add(...l,...n.classList),A=n.parentNode,k=n.nextSibling,n.before(_),(v||document.body).appendChild(n),n.classList.add(r);const i={position:"fixed",left:`${C.left}px`,top:`${C.top}px`,width:`${C.width}px`,zIndex:"9999",pointerEvents:"none",boxSizing:"border-box"};n.style.backgroundColor||(i.backgroundColor="var(--sf-primary-container)"),Object.assign(n.style,i),L=h(s,{accept:"function"==typeof m?()=>!0:void 0}),I=void 0,t.setPointerCapture?.(e.pointerId),p?.({event:e,item:n,container:s,placeholder:_}),document.addEventListener("pointermove",T)},T=e=>{if(!y)return;let t=e.clientX-w,s=e.clientY-M;t=Math.max(E.left,t),s=Math.max(E.top,s),t=Math.min(E.right-C.width,t),s=Math.min(E.bottom-C.height,s),n.style.left=`${t}px`,n.style.top=`${s}px`,P(e)},B=e=>{if(D(),document.removeEventListener("pointermove",T),document.removeEventListener("pointercancel",z),!y)return;y=!1,f(!1),t.releasePointerCapture?.(e.pointerId),_?.parentNode&&_.replaceWith(n),n.classList.remove(r),N();const i=_;_=null,C=null,E=null,L=[],I=void 0,A=null,k=null,g?.({event:e,item:n,container:s,placeholder:i})},z=()=>{if(D(),document.removeEventListener("pointermove",T),document.removeEventListener("pointerup",B),!y)return;y=!1,f(!1),A&&A.insertBefore(n,k),_?.remove(),n.classList.remove(r),N();const e=_;_=null,C=null,E=null,L=[],I=void 0,A=null,k=null,b?.({item:n,container:s,placeholder:e})},R=e=>{0===e.button&&(c?.(e)||(D(),i>0?$=setTimeout(()=>{$=null,O(e)},i):O(e),document.addEventListener("pointerup",B,{once:!0}),document.addEventListener("pointercancel",z,{once:!0})))},j=e=>{S&&(S=!1,e.preventDefault(),e.stopImmediatePropagation())};return t.addEventListener("pointerdown",R),t.addEventListener("click",j,!0),()=>{D(),document.removeEventListener("pointermove",T),document.removeEventListener("pointerup",B),document.removeEventListener("pointercancel",z),t.removeEventListener("pointerdown",R),t.removeEventListener("click",j,!0),t.removeAttribute(a),f(!1)}}function b(e){return e?.nodeType===Node.ELEMENT_NODE&&"sf-admin-menu-item"===e?.tagName?.toLowerCase?.()}function v(e=""){const t=String(e||"").trim().toLowerCase();return["bottom","footer"].includes(t)?"bottom":"main"}function x(e=[]){return`admin-menu-${e.join("-")||"root"}`}function I(e,t=0){if(null==e||""===e)return t;const n=Number(e);return Number.isFinite(n)?n:t}function y(e=[]){return[...e].sort((e,t)=>e.order!==t.order?e.order-t.order:e.sourceIndex-t.sourceIndex)}const $="main-menu-settings";function S(e={},t={}){const n=new Set([...Object.keys(e||{}),...Object.keys(t||{})]);for(const s of n)if(!Object.is(e?.[s],t?.[s]))return!1;return!0}(class extends r{static get props(){return{templateName:{attribute:"template",default:"default"},brand:{default:""},logo:{default:""},logoHref:{attribute:"logo-href",default:"#"},ariaLabel:{attribute:"aria-label",default:"Admin menu"},searchable:{type:Boolean,default:!1},collapsible:{type:Boolean,default:!1},settings:{type:Boolean,default:!0},settingsTitle:{default:"Настройки меню"},compact:{type:Boolean,default:!1},searchPlaceholder:{attribute:"search-placeholder",default:"Поиск по разделам"},count:0,toggleLabel:{attribute:"toggle-label",default:"Меню"},panelClass:{attribute:"panel-class",default:""},rootClass:{default:""}}}constructor(){super(),this.refs={mainPanel:this.createRef(),menuPanel:this.createRef(),contextMenu:this.createRef(),items:new Map},this.createdItems=[],this._itemObserver=null,this.parentGap=0,this.contextTarget=null,this._itemsData=[],this.resizeObserver=null,this._adminMenuInitToken=0,this._panels={},this.debounce=(e,t=300)=>{let n;return(...s)=>{clearTimeout(n),n=setTimeout(()=>{e.apply(this,s)},t)}},this.search=this.debounce(this.startSearch),this.menuSettings=this.getMainMenuSettings(),this.contextEvent=this.contextEvent.bind(this),this._contextEventBound=!1,this.state={panels:{},menuSettings:!1,openSearch:!1,searchQuery:"",searchResults:[],visible:{},hasHidden:!1,open:!1}}connectedCallback(){this.observeItemChildren(),this.captureInitialItems(),this.set({panels:{...this._panels}}),super.connectedCallback()}disconnectedCallback(){this.unbindContextEvent(),this.closeContextMenu(),this.disconnectItemObserver(),this.resizeObserver?.disconnect?.(),this.resizeObserver=null,this._adminMenuInitToken++,super.disconnectedCallback()}itemNodeToData(e,t=[]){const n=t[t.length-1]||0,s=function(e){const t=String(e?.getAttribute?.("type")||"").trim().toLowerCase();return e?.hasAttribute?.("divider")||"divider"===t||"separator"===t?"divider":"item"}(e),i="divider"===s?[]:y(Array.from(e?.children||[]).filter(b).map((e,n)=>this.itemNodeToData(e,[...t,n]))),a={type:s,label:e.getAttribute("label")||e.getAttribute("text")||e.getAttribute("title")||function(e){return Array.from(e?.childNodes||[]).filter(e=>!b(e)).map(e=>e.textContent||"").join(" ").replace(/\s+/g," ").trim()}(e),leftIcon:e.getAttribute("left-icon")||"",rightIcon:e.getAttribute("right-icon")||"",href:e.getAttribute("href")||"",target:e.getAttribute("target")||"",rel:e.getAttribute("rel")||"",badge:e.getAttribute("badge")||"",value:e.getAttribute("value")||"",hidden:e.getAttribute("hidden")||!1,placeholder:"divider"!==s&&(e.getAttribute("placeholder")||!0),order:I(e.getAttribute("order"),n),sourceIndex:n,slot:v(e.getAttribute("slot")||e.getAttribute("position")),activePanels:{},active:e.hasAttribute("active"),current:e.hasAttribute("current"),disabled:e.hasAttribute("disabled"),children:i,panelId:e.getAttribute("panelId")||x(t)};return this.applyMenuItemSettings(a)}getMenuItemSettings(e){if(!e||!this.menuSettings||"object"!=typeof this.menuSettings)return{};const t=this.menuSettings[e];return t&&"object"==typeof t?t:{}}applyMenuItemSettings(e={}){const t=this.getMenuItemSettings(e.panelId);return Object.keys(t).length?{...e,...t,panelId:e.panelId,children:e.children}:e}patchMenuItemSettings(e,t={},n={}){if(!e)return{};const s=this.menuSettings&&"object"==typeof this.menuSettings?this.menuSettings:{},i=this.getMenuItemSettings(e),a="function"==typeof t?t(i):t,r={...i,...a||{}};return S(i,r)?i:(this.menuSettings={...s,[e]:r},!1!==n.persist&&this.persistMenuSettings(),r)}removeMenuItemSettings(e,t=null,n={}){if(!e||!this.menuSettings?.[e])return{};if(!t){const{[e]:t,...s}=this.menuSettings;return this.menuSettings=s,!1!==n.persist&&this.persistMenuSettings(),t||{}}const s=Array.isArray(t)?t:[t],i={...this.menuSettings[e]};return s.forEach(e=>{delete i[e]}),S(this.menuSettings[e],i)?this.menuSettings[e]:(this.menuSettings={...this.menuSettings,[e]:i},!1!==n.persist&&this.persistMenuSettings(),i)}persistMenuSettings(){const e=JSON.stringify(this.menuSettings||{});return localStorage.getItem($)!==e&&(localStorage.setItem($,e),!0)}createDivider(){const e=document.createElement("sf-admin-menu-item");e.setAttribute("type","divider");const t=this.itemNodeToData(e,[`custom-divider-${this._itemsData.length+1}`]);this.createdItems.push(t),this._itemsData=[t,...this._itemsData],this.requestComponentUpdate("createDivider")}findItemByPanelId(e,t=this._itemsData){if(!e)return null;for(const n of t||[]){if(n.panelId===e)return n;const t=this.findItemByPanelId(e,n.children||[]);if(t)return t}return null}updateItemByPanelId(e,t,n=this._itemsData){return(n||[]).map(n=>n.panelId===e?t(n):n.children?.length?{...n,children:this.updateItemByPanelId(e,t,n.children)}:n)}mapItems(e,t=this._itemsData){return(t||[]).map(t=>{const n=e(t);return{...n,children:n.children?.length?this.mapItems(e,n.children):n.children}})}toggleHidden(){const e={...this.state.visible||{}};this._itemsData=this.mapItems(t=>{const n=!0===this.getMenuItemSettings(t.panelId).hidden,s=!0===e[t.panelId]?.temp;if(!n&&!s)return t;const i=!s;return e[t.panelId]={...e[t.panelId]||{},temp:i},{...t,hidden:n&&!i}}),this.set({visible:e},"toggleHidden")}toggleItemVisibility(e,t){const n=e.closest("li"),{panelId:s}=n.dataset;this.patchMenuItemSettings(s,{hidden:!t}),this._itemsData=this.updateItemByPanelId(s,e=>({...e,hidden:!t}));const i={...this.state.visible||{}};t?i[s]={visible:!0}:delete i[s],this.closeContextMenu(),this.set({visible:i},"toggleItemVisibility")}deleteItem(e){const t=e.closest("li"),{panelId:n}=t.dataset;this._itemsData=this._itemsData.filter(e=>e.panelId!==n),this.closeContextMenu(),this.requestComponentUpdate("deleteItem")}normalizeSearchText(e=""){return String(e||"").trim().replace(/\s+/g," ").toLowerCase()}flattenMenuItems(e=[],t=[],n=[]){return e.flatMap(e=>{if(e.hidden||"divider"===e.type)return[];const s=[...t,e.label].filter(Boolean),i=[...n],a={...e,path:s,panelPath:i,searchText:this.normalizeSearchText(s.join(" ")),searchLabel:this.normalizeSearchText(e.label)},r=e.children?.length?[...i,e.panelId]:i;return[a,...this.flattenMenuItems(e.children||[],s,r)]})}scoreSearchItem(e,t){return t?e.searchLabel===t?100:e.searchLabel.startsWith(t)?90:e.searchLabel.includes(t)?70:e.searchText.includes(t)?40:0:0}getSearchResults(e=""){const t=this.normalizeSearchText(e);return t?this.flattenMenuItems(this._itemsData).map(e=>({...e,score:this.scoreSearchItem(e,t)})).filter(e=>e.score>0&&!e.disabled).sort((e,t)=>t.score!==e.score?t.score-e.score:e.path.join(" ").localeCompare(t.path.join(" "))).slice(0,20):[]}startSearch(e=""){const t=String(e||"").trim();if(!t.length)return this.set(e=>({openSearch:!1,searchQuery:"",searchResults:[],panels:{...e.panels||{},search_panel:{...e.panels?.search_panel||{},open:!1}}})),!1;const n=this.getSearchResults(t);return this.set(e=>({openSearch:!0,searchQuery:t,searchResults:n,panels:{...e.panels||{},search_panel:{...e.panels?.search_panel||{},open:!0}}})),n}openSearchResult(e,t=null){if(e&&e.children?.length){t?.preventDefault?.();const n={...this.state.panels||{}};[...e.panelPath||[],e.panelId].forEach(e=>{n[e]={...n[e]||{},open:!0}}),n.search_panel={...n.search_panel||{},open:!1},this.set({panels:n,openSearch:!1})}}observeItemChildren(){this._itemObserver||(this._itemObserver=new MutationObserver(e=>{e.some(e=>Array.from(e.addedNodes||[]).some(b))&&this.captureInitialItems()&&this.requestComponentUpdate("items")}),this._itemObserver.observe(this,{childList:!0}))}toggleMenuSettings(){this.set(e=>{const{menuSettings:t}=e;return{menuSettings:!t,visible:{},hasHidden:!1}})}disconnectItemObserver(){this._itemObserver?.disconnect?.(),this._itemObserver=null}toggleCompact(){this.setState({compact:!this.getProp("compact")})}toggleOpen(){this.set(e=>{const{open:t}=e;return{open:!t}})}getItemRef(e){return this.refs.items.has(e)||this.refs.items.set(e,this.createRef()),this.refs.items.get(e)}updateMenuItemHeight(){const e=[...this.refs.items.values()].find(e=>{const t=e.value;return t&&!t.classList.contains("hidden")&&!t.classList.contains("sf-admin-menu-divider-wrap")}),t=e?.value?.offsetHeight||this.menuItemHeight||56;return t&&t!==this.menuItemHeight&&(this.menuItemHeight=t),this.menuItemHeight}saveNewItemsData(){this.createdItems.forEach(e=>{const t=this.findItemByPanelId(e.panelId);this.patchMenuItemSettings(e.panelId,{created:!0,type:t.type,order:t.order})}),this.createdItems=[]}saveMenuSettings(){this.saveNewItemsData(),this.persistMenuSettings(),this.closeContextMenu(),this.toggleMenuSettings()}updateOverflow(){if(!this.refs.menuPanel.value)return;if(!this.refs.items.size)return;const e=[...this.refs.items.entries()].filter(([e])=>{const t=this.findItemByPanelId(e);return!t?.hidden}),t=this.updateMenuItemHeight()||56,n=t+this.parentGap,s=Math.max(0,this.refs.menuPanel.value.clientHeight-n),i={};let a=!1,r=0;return e.forEach(([e,n],o)=>{const l=n?.value,c=l?.offsetHeight||0;c>0&&(l.dataset.sfAdminMenuHeight=String(c));const m=c||Number(l?.dataset.sfAdminMenuHeight)||t,u=r+m+(o>0?this.parentGap:0),d=u<=s;d||(a=!0);const p=this.state.visible||{};i[e]={...p[e]||{},visible:d},d&&(r=u)}),{items:i,hidden:a}}closeContextMenu(){this.refs.contextMenu&&this.refs.contextMenu.value&&(a(null,this.getPortalContainer()),this.refs.contextMenu.value=null,this.unbindContextEvent(),this.contextTarget.classList.remove("active"),this.contextTarget=null)}openContextMenu(e,t={}){if(this.contextTarget===e.target)return void this.closeContextMenu();this.contextTarget?.classList.remove("active"),this.contextTarget=e.target,this.contextTarget.classList.add("active");const n=e.target.getBoundingClientRect();e.preventDefault(),e.stopPropagation(),this.renderContextMenu(Object.assign(t,{id:e.target,x:n.left+n.width,y:n.y+n.height/2}))}bindContextEvent(){this._contextEventBound||(document.addEventListener("click",this.contextEvent),this._contextEventBound=!0)}unbindContextEvent(){this._contextEventBound&&(document.removeEventListener("click",this.contextEvent),this._contextEventBound=!1)}contextEvent(e){this.isContextMenuEvent(e)||this.closeContextMenu()}isContextMenuEvent(e){const t=this.refs?.contextMenu?.value;if(!(t instanceof Node))return!1;const n=e?.target;return n instanceof Node&&(!(t!==n&&!t.contains(n))||(e.composedPath?.().includes(t)||!1))}renderContextMenu(e){const{x:t,y:n,position:i,tempVisible:r,id:o,transform:l,items:c=[{component:"sf-button",props:{type:"link",scheme:"on-surface",iconLeft:"save",text:"Сохранить","@click":()=>{this.saveMenuSettings()}}},{component:"sf-button",props:{type:"link",scheme:"on-surface",iconLeft:"edit",text:"Изменить"}},{component:"sf-button",props:{type:"link",scheme:"on-surface",iconLeft:"visibility"+(r?"":"_off"),text:""+(r?"Показать":"Скрыть"),"@click":()=>{this.toggleItemVisibility(o,r)}}},{component:"sf-button",props:{type:"link",scheme:"on-surface",iconLeft:"delete",text:"Удалить","@click":()=>{this.deleteItem(o)}}}]}=e;let m=`translateY(calc(${void 0!==l?l:-50}%))`;if(i)switch(i){case"left-bottom":case"right-bottom":m=`translateY(calc(${void 0!==l?l:-100}% + var(--sf-context-menu-tail-corner-offset)))`}a(s`
                <sf-context-menu
                        :key=${t+n}
                        style="
            position: fixed;
            inset-inline-start: calc(${t}px + var(--sf-context-menu-tail-corner-offset));
            inset-block-start: ${n}px;
            transform: ${m};
            z-index: 10000;
          "
                        .items=${c}
                        :ref=${this.refs.contextMenu}
                        position="${i||"left"}"
                >
                </sf-context-menu>
            `,this.getPortalContainer()),this.bindContextEvent()}isSameVisibleState(e={}){const t=this.state?.visible||{},n=new Set([...Object.keys(t),...Object.keys(e||{})]);for(const s of n)if(t[s]?.visible!==e[s]?.visible)return!1;return!0}scheduleOverflowUpdate(){this.resizeFrame||this.isMeasuring||this.state.menuSettings||(this.parentGap=function(e){const t=e.values().next().value,n=t?.value;if(!n)return;const s=n.parentNode;var i;return s?{gap:(i=s,parseFloat(getComputedStyle(i).rowGap)||0),item:n,parent:s}:void 0}(this.refs.items).gap,this.resizeFrame=requestAnimationFrame(()=>{this.resizeFrame=null,this.isMeasuring=!0;const{items:e,hidden:t}=this.updateOverflow();e&&!this.isSameVisibleState(e)&&this.set({visible:e,hasHidden:t},"overflow"),requestAnimationFrame(()=>{this.isMeasuring=!1})}))}observeMainResize(){this.refs.menuPanel.value&&"undefined"!=typeof ResizeObserver&&!this.resizeObserver&&this.refs.items.size&&(this.resizeObserver=new ResizeObserver(()=>{this.scheduleOverflowUpdate()}),this.resizeObserver.observe(this.refs.menuPanel.value))}togglePanel(e,t=!0){if(!e)return this;"search_panel"!==e||t||this.set({openSearch:!1});return!1!==this.getProp("compact")&&this.setState({compact:!1}),this.set(n=>{const s=n.panels||{};return s[e]?.open===t?{}:{panels:{...s,[e]:{...s[e]||{},open:t}}}}),this}buildPanels(e=[],t={}){return e.forEach(e=>{e.children?.length&&(t[e.panelId]=t[e.panelId]||{open:!1},this.buildPanels(e.children,t))}),t.search_panel=t.search_panel||{open:!1},t}captureInitialItems(){const e=Array.from(this.childNodes||[]).filter(b);for(const[t,n]of Object.entries(this.menuSettings))if(n.created){const s=document.createElement("sf-admin-menu-item");s.setAttribute("type",n.type),s.setAttribute("panelId",t),e.push(s)}return!!e.length&&(this._itemsData=e.map((e,t)=>this.itemNodeToData(e,[t])),this._itemsData=y(this._itemsData),this._panels=this.buildPanels(this._itemsData,this._panels),e.forEach(e=>e.remove()),!0)}getMainMenuSettings(){const e=localStorage.getItem($);if(!e)return{};try{const t=JSON.parse(e);return t&&"object"==typeof t?t:{}}catch(e){return console.warn("SF AdminMenu: failed to parse menu settings",e),{}}}get items(){return this._itemsData.filter(e=>"bottom"!==e.slot)}get bottomItems(){return this._itemsData.filter(e=>"bottom"===e.slot)}templateContext(){const e=this.getPropsContext();return this.createTemplateContext({...e,component:this,items:this.items,bottomItems:this.bottomItems,rootClass:this.getRootClass(),rootStyle:this.getRootStyle()})}template(){return p(this.templateContext())}beforeRender(){super.beforeRender(),this.refs.items=new Map}makeDraggable(e,t,n,s={}){const i=g({handle:e,item:t,container:n,holdDelay:Number(s.holdDelay)||0,boundAttr:"data-sf-admin-menu-drag-bound",placeholderExtraClasses:["sf-admin-menu-item-cloned"],shouldIgnorePointerDown:e=>Number(s.holdDelay)>0&&e.target?.closest?.("[data-move]"),getAfterElement:(e,t,n,s)=>this.getDragAfterElement(e,t,s),onDragStart:()=>{this.isMeasuring=!0},onDrop:()=>{this.syncItemsOrderFromContainer(n),this.isMeasuring=!1,this.requestComponentUpdate("order")},onCancel:()=>{this.isMeasuring=!1}});if(i||"1"===e?.getAttribute("data-sf-admin-menu-drag-bound"))return i;if(!e||!t||!n)return;if("1"===e.dataset.sfAdminMenuDragBound)return;e.dataset.sfAdminMenuDragBound="1";const a=Number(s.holdDelay)||0;let r=!1,o=null,l=!1,c=0,m=0,u=null,d=null;const p=()=>{o&&(clearTimeout(o),o=null)},f=n=>{if(r)return;this.isMeasuring=!0,n.preventDefault?.(),r=!0,l=!0,u=t.getBoundingClientRect(),c=n.clientX-u.left,m=n.clientY-u.top;const s=t.nodeName.toLowerCase();d=document.createElement(s),d.className="drag-placeholder",d.style.width=`${u.width}px`,d.style.height=`${u.height}px`,d.classList.add("sf-admin-menu-item-cloned",...t.classList),t.before(d),t.classList.add("is-dragging"),Object.assign(t.style,{position:"fixed",left:`${u.left}px`,top:`${u.top}px`,width:`${u.width}px`,zIndex:"9999",pointerEvents:"none"}),e.setPointerCapture?.(n.pointerId),document.addEventListener("pointermove",h)};function h(e){if(!r)return;const s=n.getBoundingClientRect();let i=e.clientX-c,a=e.clientY-m;i=Math.max(s.left,i),a=Math.max(s.top,a),i=Math.min(s.right-u.width,i),a=Math.min(s.bottom-u.height,a),t.style.left=`${i}px`,t.style.top=`${a}px`,b(e.clientX,e.clientY)}e.addEventListener("pointerdown",e=>{0===e.button&&(a>0&&e.target?.closest?.("[data-move]")||(p(),a>0?o=setTimeout(()=>{o=null,f(e)},a):f(e),document.addEventListener("pointerup",v,{once:!0}),document.addEventListener("pointercancel",x,{once:!0})))}),e.addEventListener("click",e=>{l&&(l=!1,e.preventDefault(),e.stopImmediatePropagation())},!0);const b=(e,t)=>{const s=this.getDragAfterElement(n,t);s?n.insertBefore(d,s):n.appendChild(d)},v=s=>{p(),document.removeEventListener("pointermove",h),document.removeEventListener("pointercancel",x),r&&(r=!1,e.releasePointerCapture?.(s.pointerId),d?.parentNode&&d.replaceWith(t),t.classList.remove("is-dragging"),Object.assign(t.style,{position:"",left:"",top:"",width:"",zIndex:"",pointerEvents:""}),d=null,u=null,this.syncItemsOrderFromContainer(n),this.isMeasuring=!1,this.requestComponentUpdate("order"))},x=()=>{p(),document.removeEventListener("pointermove",h),document.removeEventListener("pointerup",v),r&&(r=!1,d?.remove(),t.classList.remove("is-dragging"),Object.assign(t.style,{position:"",left:"",top:"",width:"",zIndex:"",pointerEvents:""}),d=null,u=null,this.isMeasuring=!1)}}getDragAfterElement(e,t,n=null){const s=Array.isArray(n)?n.filter(e=>e.item?.dataset?.panelId&&!e.item.classList.contains("hidden")&&!e.item.classList.contains("more")):Array.from(e?.children||[]).filter(e=>e instanceof HTMLElement&&e.dataset.panelId&&!e.classList.contains("is-dragging")&&!e.classList.contains("drag-placeholder")&&!e.classList.contains("hidden")&&!e.classList.contains("more")).map(e=>{const t=e.getBoundingClientRect();return{item:e,middle:t.top+t.height/2}});let i={offset:Number.NEGATIVE_INFINITY,element:null};for(const e of s){const n=t-e.middle;n<0&&n>i.offset&&(i={offset:n,element:e.item})}return i.element}syncItemsOrderFromContainer(e){const t=Array.from(e?.children||[]).filter(e=>e instanceof HTMLElement&&e.dataset.panelId&&!e.classList.contains("more")&&!e.classList.contains("drag-placeholder")).map(e=>e.dataset.panelId);if(!t.length)return;const n=new Map(t.map((e,t)=>[e,t]));this.state.menuSettings||t.forEach((e,t)=>{this.patchMenuItemSettings(e,{order:t})});const s=this._itemsData.filter(e=>"bottom"===e.slot);let i={};const a=this._itemsData.filter(e=>"bottom"!==e.slot).map(e=>{if(!n.has(e.panelId))return e;const t=n.get(e.panelId);return i[e.panelId]=t,{...e,order:t,sourceIndex:t}}).sort((e,t)=>{const s=n.has(e.panelId)?n.get(e.panelId):Number.MAX_SAFE_INTEGER,i=n.has(t.panelId)?n.get(t.panelId):Number.MAX_SAFE_INTEGER;return s!==i?s-i:e.sourceIndex-t.sourceIndex});this._itemsData=[...a,...s]}pruneItemRefs(){const e=new Set,t=(n=[])=>{n.forEach(n=>{e.add(n.panelId),t(n.children)})};t(this._itemsData);for(const t of this.refs.items.keys())e.has(t)||this.refs.items.delete(t)}getPortalContainer(){let e=document.getElementById("sf-admin-menu-portal");return e||(e=document.createElement("div"),e.id="sf-admin-menu-portal",document.body.append(e)),e}async afterRender(){const e=++this._adminMenuInitToken;this.scheduleOverflowUpdate(),await this.whenChildrenDefined(),await new Promise(e=>requestAnimationFrame(e)),requestAnimationFrame(()=>{this.isConnected&&e===this._adminMenuInitToken&&(this.observeMainResize(),[...this.refs.items.values()].forEach(e=>{const{value:t}=e;if(!t)return!1;const n=this.refs.menuPanel.value.children[0];if(this.state.menuSettings){const e=t.querySelector("[data-move]");this.makeDraggable(e,t,n)}this.makeDraggable(t,t,n,{holdDelay:200})}))})}}).define("sf-admin-menu")})();