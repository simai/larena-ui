(()=>{"use strict";const e="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},t="undefined"!=typeof window?window:{},s=e.SfBaseElement||t.SfBaseElement;if(!s)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const i=e.html||t.html,r=e.nothing||t.nothing,n=(e.render||t.render,e.litProps||t.litProps,e.toBoolean,e.toAttributeName,e.toNumber,e.normalizeEnum,e.parseJsonAttribute,s),o=".sf-slider",a="sfSliderBound",d="sfSliderWaiting",l=["a11y","autoplay","cardsEffect","coverflowEffect","creativeEffect","cubeEffect","fadeEffect","flipEffect","freeMode","grid","keyboard","mousewheel","scrollbar","thumbs","virtual"];function u(e,t=!1){return null==e||""===e?t:"boolean"==typeof e?e:["1","true","yes","on"].includes(String(e).toLowerCase())}function c(e,t){const s=Number.parseFloat(String(e??""));return Number.isFinite(s)?s:t}function f(e,t=1){return"auto"===String(e||"").trim().toLowerCase()?"auto":c(e,t)}function h(e,t,s){return t?.dataset?.[s]??e?.dataset?.[s]}function p(e=""){return e?e.charAt(0).toLowerCase()+e.slice(1):""}function b(e){const t=String(e??"").trim();if(""===t)return"";if("true"===t)return!0;if("false"===t)return!1;if("null"===t)return null;if(/^-?\d+(\.\d+)?$/.test(t))return Number(t);if(t.startsWith("{")&&t.endsWith("}")||t.startsWith("[")&&t.endsWith("]"))try{return JSON.parse(t)}catch(e){console.warn("SF slider: invalid data-swiper-options JSON",e)}return t}function m(e){return e&&"object"==typeof e&&!Array.isArray(e)&&!(e instanceof Element)}function w(e={},t={}){const s={...e};return Object.entries(t||{}).forEach(([e,t])=>{m(t)&&m(s[e])?s[e]=w(s[e],t):s[e]=t}),s}function y(...e){return e.reduce((e,t)=>{if(!t?.dataset)return e;if(t.dataset.swiperOptions){const s=b(t.dataset.swiperOptions);m(s)&&(e=w(e,s))}return Object.entries(t.dataset).forEach(([t,s])=>{!function(e,t,s){if(!t.startsWith("swiper")||"swiperOptions"===t)return;const i=p(t.slice(6));if(!i)return;const r=l.find(e=>{const t=i.slice(e.length);return i===e||/^[A-Z]/.test(t)});if(r&&i!==r){const t=p(i.slice(r.length));return void(e[r]={...m(e[r])?e[r]:{},[t]:s})}e[i]=s}(e,t,b(s))}),e},{})}function S(e,t,s=1){let i={centeredSlides:u(h(e,t,"centeredSlides"),!1),loop:u(h(e,t,"loop"),!1),slidesPerView:f(h(e,t,"slidesPerView"),s),spaceBetween:c(h(e,t,"spaceBetween"),0),speed:c(h(e,t,"speed"),300),watchSlidesProgress:!0};const r=function(e,t){if(u(h(e,t,"autoplay"),!1))return{enabled:!0,delay:c(h(e,t,"autoplayDelay"),3e3),disableOnInteraction:u(h(e,t,"autoplayDisableOnInteraction"),!0),pauseOnMouseEnter:u(h(e,t,"autoplayPauseOnMouseEnter"),!1),reverseDirection:u(h(e,t,"autoplayReverseDirection"),!1),stopOnLastSlide:u(h(e,t,"autoplayStopOnLastSlide"),!1)}}(e,t);return r&&(i.autoplay=r),i=w(i,y(e,t)),function(e={}){return!0===e.autoplay?e.autoplay={enabled:!0}:m(e.autoplay)&&(e.autoplay={enabled:!0,...e.autoplay}),e}(i)}function g(e){const t=Array.from(e.querySelectorAll?.('sf-icon-button[root-class*="sf-slider-button-"]')||[]);return!!t.length&&t.some(e=>!e.querySelector(".sf-icon-button"))}function v(e){if("true"===e.dataset[d])return null;e.dataset[d]="true";let t=0;const s=()=>{if(document.documentElement.contains(e)){if("function"==typeof window.Swiper&&!g(e))return delete e.dataset[d],void _(e);t+=1,t<40?window.setTimeout(s,50):delete e.dataset[d]}else delete e.dataset[d]};return window.setTimeout(s,0),null}function _(e){if(!(e instanceof HTMLElement))return null;if("true"===e.dataset[a])return e._sfSlider;if("undefined"==typeof window||"function"!=typeof window.Swiper)return v(e);const t=e.querySelector(".sf-slider-main.swiper, .swiper");if(!(t instanceof HTMLElement))return null;if(g(e))return v(e);const s=e.querySelector(".sf-slider-button-prev"),i=e.querySelector(".sf-slider-button-next"),r=e.querySelector(".sf-slider-pagination"),n=e.querySelector(".sf-slider-thumbnails.swiper");let o=null;const d=(l=n,l?.querySelectorAll?.(".swiper-wrapper > .swiper-slide")?.length||0);var l;n instanceof HTMLElement&&d>0&&(o=new window.Swiper(n,{...S(e,n,Math.min(d,6)),loop:!1,centeredSlides:!1,spaceBetween:6,slidesPerView:Math.min(d,6),slideToClickedSlide:!1}));const u={...S(e,t,1)},c=function(e,t){if(e||t)return{disabledClass:"swiper-button-disabled",hiddenClass:"swiper-button-hidden",lockClass:"swiper-button-lock",nextEl:t,prevEl:e}}(s,i),f=function(e){if(e)return{el:e,bulletActiveClass:"active",bulletClass:"sf-slider-dots-dot",bulletElement:"button",clickable:!0}}(r);c&&(u.navigation=c),f&&(u.pagination=f),o&&(u.thumbs={swiper:o});const h=new window.Swiper(t,u);return e.dataset[a]="true",e._sfSlider=h,e._sfSliderThumbs=o,h}function C(e){if(!(e instanceof HTMLElement))return null;const t=e._sfSlider||_(e);return t?(e._sfSliderThumbs?.update?.(),t.update?.(),t.navigation?.update?.(),t.pagination?.update?.(),"number"==typeof t.activeIndex&&t.slideTo?.(t.activeIndex,0,!1),t):null}function E(e){e instanceof HTMLElement&&(e._sfSlider?.destroy?.(!0,!0),e._sfSliderThumbs?.destroy?.(!0,!0),delete e._sfSlider,delete e._sfSliderThumbs,delete e.dataset[a])}function A(e){(e instanceof Element||e===document)&&(e instanceof Element&&e.matches?.(o)&&_(e),e.querySelectorAll?.(o).forEach(_))}function T(e=document){A(e)}"undefined"!=typeof window&&(window.SF=window.SF||{},window.SF.Slider=window.SF.Slider||{},window.SF.Slider.bind=_,window.SF.Slider.refresh=C,window.SF.Slider.unbind=E),"loading"===document.readyState?document.addEventListener("DOMContentLoaded",()=>T()):T();function $(...e){return e.flat().filter(Boolean).join(" ")}function k(e=""){return String(e||"").trim().toLowerCase()}function R(e){return e&&e!==r?Array.isArray(e)?e:[e]:[]}function B(){return[i`
      <div class="radius-3 bg-primary color-on-primary p-2">
        Slide 1
      </div>
    `,i`
      <div class="radius-3 bg-secondary color-on-secondary p-2">
        Slide 2
      </div>
    `,i`
      <div class="radius-3 bg-tertiary color-on-tertiary p-2">
        Slide 3
      </div>
    `]}function x(e){const t=function(e){return e instanceof Node?e.cloneNode(!0):e}(e);if(!(t instanceof Element))return t;const s="img, picture, video",i=t.matches(s)?t:t.querySelector(s);return i?(r=i.cloneNode(!0))instanceof Element?([r,...r.querySelectorAll("*")].forEach(e=>{e.removeAttribute("class"),e.removeAttribute("style")}),r):r:t;var r}function N(e){if(!e.arrows)return"";const t=function(e="primary"){const t={primary:{type:"default",scheme:"primary"},secondary:{type:"tonal",scheme:"secondary"},dark:{type:"default",scheme:"on-surface"},light:{type:"link",scheme:"on-surface"}};return t[k(e)]||t.primary}(e.buttonType),s=e.buttonSize||"1";return i`
    <div class="sf-slider-arrows sf-slider-arrows--size-2">
      <sf-icon-button
        root-class="sf-slider-button-prev"
        icon="keyboard_arrow_left"
        size=${s}
        type=${t.type}
        scheme=${t.scheme}
        aria-label="Previous slide"
      ></sf-icon-button>
      <sf-icon-button
        root-class="sf-slider-button-next"
        icon="keyboard_arrow_right"
        size=${s}
        type=${t.type}
        scheme=${t.scheme}
        aria-label="Next slide"
      ></sf-icon-button>
    </div>
  `}function q(e){const t=$("sf-slider",e.rootClass);return i`
    <div
      class=${t}
      data-loop=${String(!!e.loop)}
      data-space-between=${String(e.spaceBetween)}
      data-speed=${String(e.speed)}
    >
      <div class="sf-slider-main swiper">
        <div class="swiper-wrapper">
          ${function(e){const t=R(e.slides);return(t.length?t:B()).map(t=>i`
      <div class="swiper-slide">
        <div class=${$("sf-slider-slide",e.slideClass)}>
          ${t}
        </div>
      </div>
    `)}(e)}
        </div>
      </div>

      ${e.thumbs?i`
            <div class=${$("sf-slider-thumbnails swiper",e.thumbsClass)}>
              <div class="swiper-wrapper">
                ${function(e){const t=R(e.slides);return(t.length?t.map(x):B()).map(t=>i`
      <div class="swiper-slide">
        <div class=${$("sf-slider-thumbnail",e.thumbClass)}>
          ${t}
        </div>
      </div>
    `)}(e)}
              </div>
            </div>
          `:r}

      ${e.arrows||e.dots?i`
            <div class="sf-slider-controls">
              ${N(e)}
              ${e.dots?i`<div class=${function(e="primary-dark",t="2"){const s={primary:["sf-slider-dots--primary","sf-slider-dots--dark"],"primary-light":["sf-slider-dots--primary","sf-slider-dots--light"],"primary-dark":["sf-slider-dots--primary","sf-slider-dots--dark"],light:["sf-slider-dots--clear","sf-slider-dots--light"],dark:["sf-slider-dots--clear","sf-slider-dots--dark"],clear:["sf-slider-dots--clear","sf-slider-dots--light"]};return $("sf-slider-dots",s[k(e)]||s["primary-dark"],"sf-slider-dots--framed",`sf-slider-dots--size-${t||"2"}`,"flex","sf-slider-pagination")}(e.dotsType,e.dotsSize)}></div>`:""}
            </div>
          `:""}
    </div>
  `}new MutationObserver(e=>{e.forEach(e=>{e.addedNodes.forEach(e=>{e instanceof Element&&A(e)})})}).observe(document.documentElement,{childList:!0,subtree:!0});const z=new Set(["data-autoplay","data-autoplay-delay","data-autoplay-disable-on-interaction","data-autoplay-pause-on-mouse-enter","data-autoplay-reverse-direction","data-autoplay-stop-on-last-slide","data-centered-slides","data-loop","data-slides-per-view","data-space-between","data-speed"]);(class extends n{static get props(){return{buttonType:{default:"primary"},buttonSize:{default:"1"},dots:{type:Boolean,default:!0},dotsType:{default:"primary-dark"},dotsSize:{default:"2"},thumbs:{type:Boolean,default:!1},thumbsClass:{default:""},thumbClass:{default:""},arrows:{type:Boolean,default:!0},loop:{type:Boolean,default:!1},spaceBetween:{type:Number,default:12},speed:{type:Number,default:450},rootClass:{default:""},slideClass:{default:""}}}constructor(){super(),this._boundRoot=null,this._boundSlider=null,this._sliderInitToken=0}get buttonType(){return this.getAttribute("button-type")||"primary"}get buttonSize(){return this.getAttribute("button-size")||"1"}get dots(){return this.getBooleanAttr("dots",!0)}get dotsType(){return this.getAttribute("dots-type")||"primary-dark"}get dotsSize(){return this.getAttribute("dots-size")||"2"}get thumbs(){return this.getBooleanAttr("thumbs",!1)}get thumbsClass(){return this.getAttribute("thumbs-class")||""}get thumbClass(){return this.getAttribute("thumb-class")||""}get arrows(){return this.getBooleanAttr("arrows",!0)}get loop(){return this.getBooleanAttr("loop",!1)}get spaceBetween(){return this.getNumberAttr("space-between",12)}get speed(){return this.getNumberAttr("speed",450)}get slideClass(){return this.getAttribute("slide-class")||""}get slides(){return this.getSlotContent("slide")}templateContext(){const e=this.getPropsContext();return this.createTemplateContext({...e,component:this,rootClass:this.getRootClass(),slides:this.slides})}template(){return q(this.templateContext())}async waitForSliderControls(e){const t=()=>Array.from(e?.querySelectorAll?.('sf-icon-button[root-class*="sf-slider-button-"]')||[]);if(t().length)for(let e=0;e<20;e++){if(t().every(e=>e.querySelector(".sf-icon-button")))return;await new Promise(e=>requestAnimationFrame(e))}}forwardSliderDataAttributes(e){e&&Array.from(this.attributes||[]).forEach(({name:t,value:s})=>{("data-swiper-options"===t||t.startsWith("data-swiper-")||z.has(t))&&e.setAttribute(t,s)})}async afterRender(){const e=++this._sliderInitToken;await this.whenChildrenDefined(),await new Promise(e=>requestAnimationFrame(e)),this.isConnected&&e===this._sliderInitToken&&(this._boundRoot&&(this.detachSliderEvents(),E(this._boundRoot),this._boundRoot=null,this._boundSlider=null),this._boundRoot=this.querySelector(".sf-slider"),this._boundRoot&&(this.forwardSliderDataAttributes(this._boundRoot),await this.waitForSliderControls(this._boundRoot),this.isConnected&&e===this._sliderInitToken&&(E(this._boundRoot),this._boundSlider=_(this._boundRoot),this.attachSliderEvents())))}onDisconnected(){this._sliderInitToken++,this._boundRoot&&(this.detachSliderEvents(),E(this._boundRoot),this._boundRoot=null,this._boundSlider=null)}attachSliderEvents(){this._boundSlider?.on&&this._boundSlider.on("slideChange",this._handleSlideChange)}detachSliderEvents(){this._boundSlider?.off&&this._boundSlider.off("slideChange",this._handleSlideChange)}_handleSlideChange=()=>{const e=this._boundSlider;e&&this.emitComponentEvent("slide-change",{activeIndex:e.activeIndex,realIndex:e.realIndex,previousIndex:e.previousIndex})};getSlider(){return this._boundSlider||null}refresh(){return this._boundRoot||(this._boundRoot=this.querySelector(".sf-slider")),this._boundRoot&&(this.detachSliderEvents(),this.forwardSliderDataAttributes(this._boundRoot),this._boundSlider=C(this._boundRoot),this.attachSliderEvents()),this}slideNext(){return this._boundSlider?.slideNext?.(),this}slidePrev(){return this._boundSlider?.slidePrev?.(),this}get state(){return{buttonType:this.buttonType,buttonSize:this.buttonSize,dots:this.dots,dotsType:this.dotsType,dotsSize:this.dotsSize,thumbs:this.thumbs,thumbsClass:this.thumbsClass,thumbClass:this.thumbClass,arrows:this.arrows,loop:this.loop,spaceBetween:this.spaceBetween,speed:this.speed,rootClass:this.getRootClass(),slideClass:this.slideClass}}}).define("sf-slider")})();