(()=>{"use strict";const t="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},e="undefined"!=typeof window?window:{},a=t.SfBaseElement||e.SfBaseElement;if(!a)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const n=t.html||e.html,s=t.nothing||e.nothing,o=(t.render||e.render,t.litProps||e.litProps,t.toBoolean,t.toAttributeName,t.toNumber,t.normalizeEnum,t.parseJsonAttribute,a);function r(t){switch(t.type){case"checkbox":return function(t){return t.component?.hasSlotContent?.("leading")?t.component.getSlotContent("leading"):n`
                <sf-checkbox
                        checked="${t.active}"
                        disabled=${t.disabled}
                        size="${e=t.size,"1"===e?"1":"1/3"}"
                ></sf-checkbox>
        `;var e}(t);case"icon":return function(t){const e=t.icon||"sell";return t.component?.hasSlotContent?.("leading")?t.component.getSlotContent("leading"):n`<i class="sf-icon sf-tag-icon">${e}</i>`}(t);case"color":return function(t){const e=t.colorClass||"";return t.component?.hasSlotContent?.("leading")?t.component.getSlotContent("leading"):n`<span class=${["sf-tag-color-icon",e].filter(Boolean).join(" ")}></span>`}(t);case"avatar":return function(t){return t.component?.hasSlotContent?.("avatar")?t.component.getSlotContent("avatar"):t.avatarImageUrl?n`
            <span
                    class="sf-avatar sf-avatar--size-1/4 bg-cover"
                    style=${`background-image: url(${t.avatarImageUrl});`}
            ></span>
        `:t.avatarText?n`
            <span class="sf-avatar sf-avatar--size-1/4 sf-avatar--text flex justify-center items-center">
        ${t.avatarText}
      </span>
        `:n`
        <span class="sf-avatar sf-avatar--size-1/4 sf-avatar--placeholder flex justify-center items-center">
      <i class="sf-icon">person</i>
    </span>
    `}(t);case"success":case"error":case"primary":case"warning":return function(t){return t.component?.hasSlotContent?.("leading")?t.component.getSlotContent("leading"):n`
                <div class="sf-dot sf-dot--size-${e=t.size,"1"===e?"1/2":"1/3"}">
                    <div class="sf-dot-item"></div>
                </div>
        `;var e}(t);default:return s}}function i(t){const e=t.component?.hasSlotContent?.("text")?t.component.getSlotContent("text"):t.text,a=["sf-tag","transition",`sf-tag--${t.type}`,`sf-tag--size-${t.size}`,"inline-flex","flex-row","flex-nowrap","items-center",`${t.rootClass}`,t.active?"active":"",t.disabled?"disabled":""].filter(Boolean);return n`
        <div
                tabindex=${t.disabled?"-1":"0"}
                role="button"
                class=${a.join(" ")}
                aria-label=${t.ariaLabel||s}
                aria-disabled=${t.disabled?"true":s}
                aria-pressed=${"checkbox"===t.type?String(t.active):s}
        >
            ${r(t)}
            <span class="sf-tag-container pointer-events-none">${e}</span>
            ${function(t){return"default"!==t.type?s:t.component?.hasSlotContent?.("count")?t.component.getSlotContent("count"):n`<span class="sf-tag-count pointer-events-none flex">${t.count||s}</span>`}(t)}
            ${function(t){return t.closable?t.component?.hasSlotContent?.("close")?t.component.getSlotContent("close"):n`
                <sf-icon-button
                        variant="close"
                        size="${e=t.size,"1"===e?"1/3":"1/4"}"
                        type="link"
                        scheme="on-surface"
                        disabled=${t.disabled}
                        @click="${e=>{e.stopPropagation(),t.component.onClose(this)}}"
                ></sf-icon-button>
        `:s;var e}(t)}
        </div>
    `}(class extends o{static get props(){return{templateName:{attribute:"template",default:"default"},type:{default:"checkbox",values:["checkbox","icon","default","color","avatar","success","error","warning","primary"]},size:{default:"1/2",values:["1/2","1"]},text:{default:""},count:{default:""},icon:{default:""},colorClass:{default:""},avatarImageUrl:{default:""},avatarText:{default:""},rootClass:{default:""},avatarStatus:{default:""},active:{type:Boolean,default:!1},disabled:{type:Boolean,default:!1},closable:{type:Boolean,default:!0},ariaLabel:{default:""}}}get componentName(){return"tag"}get templateName(){return this.getAttribute("template")||"default"}get type(){return this.getEnumAttr("type",["checkbox","icon","quantity","color","avatar","success","error","warning","primary"],"checkbox")}get size(){return this.getEnumAttr("size",["1/2","1"],"1/2")}get text(){return this.getAttribute("text")||""}get count(){return this.getAttribute("count")||""}get icon(){return this.getAttribute("icon")||""}get colorClass(){return this.getAttribute("color-class")||""}get avatarImageUrl(){return this.getAttribute("avatar-image-url")||""}get avatarText(){return this.getAttribute("avatar-text")||""}get avatarStatus(){return this.getAttribute("avatar-status")||""}get rootClass(){return this.getRootClass()}get active(){return this.getBooleanAttr("active",!1)}get disabled(){return this.getBooleanAttr("disabled",!1)}get closable(){return this.hasAttribute("closable")?this.getBooleanAttr("closable",!0):["icon","quantity","color","avatar"].includes(this.type)}get ariaLabel(){return this.getAttribute("aria-label")||""}templateContext(){const t=this.getPropsContext();return this.createTemplateContext({...t,component:this,rootClass:this.rootClass,closable:this.closable})}onClose(t){this.dispatchEvent(new CustomEvent("close",{bubbles:!0,composed:!0,detail:{component:t}}))}template(){return i(this.templateContext())}get value(){return{template:this.templateName,type:this.type,size:this.size,text:this.text,count:this.count,icon:this.icon,colorClass:this.colorClass,avatarImageUrl:this.avatarImageUrl,avatarText:this.avatarText,avatarStatus:this.avatarStatus,rootClass:this.rootClass,active:this.active,disabled:this.disabled,closable:this.closable,ariaLabel:this.ariaLabel}}set value(t){this.setValueAttributes(t)}}).define("sf-tag")})();