(()=>{"use strict";const t="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},e="undefined"!=typeof window?window:{},i=t.SfBaseElement||e.SfBaseElement;if(!i)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const a=t.html||e.html,s=t.nothing||e.nothing,o=(t.render||e.render,t.litProps||e.litProps,t.toBoolean,t.toAttributeName),n=(t.toNumber,t.normalizeEnum,t.parseJsonAttribute,i);function r(...t){return t.flat().filter(Boolean).join(" ")}function l(t){const{component:e}=t,i=r("sf-pagination","flex","flex-col",t.rootClass),o=r("sf-pagination-top","flex","content-main-center",t.topClass),n=r("sf-pagination-main","flex","items-cross-center","content-main-between",t.mainClass),l=r("sf-pagination-bottom","flex","items-cross-center",t.bottomClass);return a`
    <div class=${i}>
      ${t.top?a`
            <div class=${o}>
              <sf-button
                size="1"
                type="outline"
                disabled=${!t.hasNext}
                scheme="primary"
                @click=${t=>e.showMore(t.target)}
                text="${t.showMoreText}"
              ></sf-button>
            </div>
          `:""}
      ${t.middle?a`
            <div class=${n}>
              <div class="sf-pagination-left flex items-cross-center">
                <div class="sf-pagination-marked flex">
                  <div class="sf-pagination-marked-text">Отмечено:</div>
                  <div class="sf-pagination-marked-text">0/10</div>
                </div>
                  ${t.showTotal?a`<div class="sf-pagination-total flex items-cross-center">
                  <div class="sf-pagination-total-text">Всего:</div>
                  <sf-button
                    size="1"
                    type="link"
                    scheme="primary"
                    text="Показать количество"
                  ></sf-button>
                </div>`:s}
              </div>

              <div class="sf-pagination-container flex items-cross-center">
                <span class="sf-pagination-prev">Страницы:</span>
                <sf-icon-button
                  size="1"
                  type="link"
                  scheme="on-surface"
                  icon="keyboard_arrow_left"
                  disabled="${!t.hasPrev}"
                  aria-label="Предыдущая страница"
                  text="Показать количество"
                  @click=${()=>e.goToPage(t.current-1)}
                ></sf-icon-button>

                ${t.pageItems.map(e=>function(t,e){const i="ellipsis"===t.type?t.target:t.value,s="ellipsis"===t.type?`Перейти к странице ${t.target}`:`Страница ${t.value}`;return"ellipsis"===t.type?a`
      <button
        type="button"
        class="sf-page-number sf-page-number--square transition"
        data-page=${String(t.target||"")}
        aria-label=${s}
        @click=${()=>e.component.goToPage(i)}
      >
        ...
      </button>
    `:a`
    <button
      type="button"
      class=${r("sf-page-number","sf-page-number--square","transition",t.selected?"selected":"")}
      data-page=${String(t.value)}
      aria-current=${t.selected?"page":"false"}
      aria-label=${s}
      @click=${()=>e.component.goToPage(i)}
    >
      ${t.value}
    </button>
  `}(e,t))}
                <sf-icon-button
                  size="1"
                  type="link"
                  scheme="on-surface"
                  icon="keyboard_arrow_right"
                  disabled="${!t.hasNext}"
                  aria-label="Следующая страница"
                  text="Показать количество"
                  @click=${()=>e.goToPage(t.current+1)}
                ></sf-icon-button>
                <sf-button
                  size="1"
                  type="link"
                  scheme="primary"
                  disabled=${!t.hasNext}
                  text="Последняя"
                  @click=${()=>e.lastPage()}
                ></sf-button>
              </div>

              ${t.showPageSize?a`
                    <div class="sf-pagination-count flex items-cross-center">
                      <span>${t.pageSizeLabel}</span>
                      <sf-dropdown
                        size="1"
                        type="outlined"
                        search="false"
                        mode="select"
                        portal="true"
                        value=${String(t.pageSize)}
                        @change=${t=>e.setPageSize(Number(t.detail.value))}
                      >
                        ${(t.pageSizes||[]).map(e=>a`
                            <sf-list-item
                              type="text"
                              size="1"
                              text=${String(e)}
                              value=${String(e)}
                              ?selected=${Number(e)===Number(t.pageSize)}
                            ></sf-list-item>
                          `)}
                      </sf-dropdown>
                    </div>
                  `:""}
            </div>
          `:""}
      ${t.bottom&&t.showActions&&t.actions?.length?a`
            <div class=${l}>
              ${t.showActions&&t.actions?.length?a`
                    <sf-dropdown
                      size="1"
                      type="outlined"
                      search="false"
                      mode="select"
                      value=${t.action}
                      @change=${t=>e.setAction(t.detail.value)}
                    >
                      ${t.actions.map(e=>a`
                          <sf-list-item
                            type="text"
                            size="1"
                            text=${e.text}
                            value=${e.value}
                            ?selected=${e.value===t.action}
                            ?disabled=${Boolean(e.disabled)}
                          ></sf-list-item>
                        `)}
                    </sf-dropdown>
                    <sf-button
                      size="1"
                      type="default"
                      scheme="primary"
                      text=${t.actionApplyText}
                      ?disabled=${!t.action}
                      @click=${()=>e.applyAction()}
                    ></sf-button>
                    ${t.showActionForAll?a`
                          <sf-checkbox
                            label=${t.actionForAllLabel}
                            ?checked=${Boolean(t.actionForAll)}
                            @click=${()=>e.setActionForAll(!t.actionForAll)}
                          ></sf-checkbox>
                        `:""}
                  `:""}
            </div>
          `:""}
    </div>
  `}function c(t,e=[10,20,30,40]){if(Array.isArray(t))return t.map(Number).filter(Number.isFinite);const i=String(t||"").split(",").map(t=>Number(t.trim())).filter(Number.isFinite);return i.length?i:e}function u(t,e=[]){if(Array.isArray(t))return t.filter(Boolean);const i=String(t||"").split("|").map(t=>t.trim()).filter(Boolean).map(t=>{const[e,i=""]=t.split("::"),[a,...s]=e.split(":"),o=String(a||"").trim(),n=s.join(":").trim()||o,r=i.split(",").map(t=>t.trim().toLowerCase()).filter(Boolean);return{value:o,text:n,disabled:r.includes("disabled"),selected:r.includes("selected")}}).filter(t=>t.value||t.text).map((t,e)=>({...t,value:t.value||`action-${e+1}`}));return i.length?i:e}(class extends n{static get props(){return{templateName:{attribute:"template",default:"default"},top:{type:Boolean,default:!0},middle:{type:Boolean,default:!0},bottom:{type:Boolean,default:!0},topClass:{default:""},mainClass:{default:""},bottomClass:{default:""},showTotal:{type:Boolean,default:!0},showMoreText:{attribute:"show-more-text",default:"Показать еще"},current:{type:Number,default:1},total:{type:Number,default:10},pageSize:{attribute:"page-size",type:Number,default:10},pageSizes:{attribute:"page-sizes",default:[10,20,30,40],parser:(t,e)=>c(t,e)},showPageSize:{attribute:"show-page-size",type:Boolean,default:!0},pageSizeLabel:{attribute:"page-size-label",default:"На странице:"},showActions:{attribute:"show-actions",type:Boolean,default:!0},actions:{default:[],parser:(t,e)=>u(t,e)},action:{default:""},actionApplyText:{attribute:"action-apply-text",default:"Применить"},showActionForAll:{attribute:"show-action-for-all",type:Boolean,default:!1},actionForAll:{attribute:"action-for-all",type:Boolean,default:!1},actionForAllLabel:{attribute:"action-for-all-label",default:"Для всех"}}}get top(){return this.getBooleanAttr("top",!0)}get middle(){return this.getBooleanAttr("middle",!0)}get showTotal(){return this.getBooleanAttr("show-total",!0)}get bottom(){return this.getBooleanAttr("bottom",!0)}get topClass(){return this.getAttribute("top-class")||""}get mainClass(){return this.getAttribute("main-class")||""}get bottomClass(){return this.getAttribute("bottom-class")||""}get showMoreText(){return this.getAttribute("show-more-text")||"Показать еще"}get total(){const t=Math.trunc(this.getNumberAttr("total",10));return Number.isFinite(t)&&t>=0?t:10}get pageSize(){const t=Math.trunc(this.getNumberAttr("page-size",10));return Number.isFinite(t)&&t>0?t:10}get pageCount(){return Math.max(1,Math.ceil(this.total/this.pageSize))}get pageSizes(){return c(this.getAttribute("page-sizes"),[10,20,30,40])}get showPageSize(){return this.getBooleanAttr("show-page-size",!1)}get pageSizeLabel(){return this.getAttribute("page-size-label")||"На странице:"}get showActions(){return this.getBooleanAttr("show-actions",!0)}get actions(){return u(this.getAttribute("actions"),[])}get action(){const t=this.getAttribute("action")||"";return t||(this.actions.find(t=>t.selected&&!t.disabled)?.value||this.actions.find(t=>!t.disabled)?.value||"")}get actionApplyText(){return this.getAttribute("action-apply-text")||"Применить"}get showActionForAll(){return this.getBooleanAttr("show-action-for-all",!1)}get actionForAll(){return this.getBooleanAttr("action-for-all",!1)}get actionForAllLabel(){return this.getAttribute("action-for-all-label")||"Для всех"}get current(){const t=Math.trunc(this.getNumberAttr("current",1));return Number.isFinite(t)?Math.min(Math.max(t,1),this.pageCount):1}get pageItems(){const t=this.pageCount,e=this.current;if(t<=7)return Array.from({length:t},(t,i)=>({type:"page",value:i+1,selected:i+1===e}));const i=[{type:"page",value:1,selected:1===e}],a=Math.max(2,e-1),s=Math.min(t-1,e+1);a>2&&i.push({type:"ellipsis",value:"start-ellipsis",target:Math.max(2,a-1)});for(let t=a;t<=s;t+=1)i.push({type:"page",value:t,selected:t===e});return s<t-1&&i.push({type:"ellipsis",value:"end-ellipsis",target:Math.min(t-1,s+1)}),i.push({type:"page",value:t,selected:e===t}),i}templateContext(){const t=this.getPropsContext();return this.createTemplateContext({...t,component:this,rootClass:this.getRootClass(),showMoreText:this.showMoreText,current:this.current,total:this.total,pageCount:this.pageCount,hasPrev:this.current>1,showTotal:this.showTotal,hasNext:this.current<this.pageCount,pageItems:this.pageItems,pageSize:this.pageSize,pageSizes:this.pageSizes,showPageSize:this.showPageSize,pageSizeLabel:this.pageSizeLabel,showActions:this.showActions,actions:this.actions,action:this.action,actionApplyText:this.actionApplyText,showActionForAll:this.showActionForAll,actionForAll:this.actionForAll,actionForAllLabel:this.actionForAllLabel})}template(){return l(this.templateContext())}getTopSection(){return this.querySelector(".sf-pagination-top")}getMainSection(){return this.querySelector(".sf-pagination-main")}getBottomSection(){return this.querySelector(".sf-pagination-bottom")}goToPage(t){const e=Number.parseInt(String(t||""),10);if(!Number.isFinite(e))return this;const i=this.current,a=Math.min(Math.max(e,1),this.pageCount);return a===i||(this.setState({current:a}),this.emitComponentEvent("page-change",{previous:i,current:a,total:this.total,pageCount:this.pageCount,pageSize:this.pageSize})),this}lastPage(){return this.goToPage(this.pageCount)}showMore(t=null){return this.emitComponentEvent("show-more",{current:this.current,total:this.total,pageSize:this.pageSize,pageCount:this.pageCount,hasNext:this.current<this.pageCount,item:t}),this}setPageSize(t){const e=Math.trunc(Number(t));if(!Number.isFinite(e)||e<=0)return this;const i=this.pageSize;if(e===i)return this;const a=Math.max(1,Math.ceil(this.total/e)),s=Math.min(this.current,a);return this.setState({pageSize:e,current:s}),this.emitComponentEvent("page-size-change",{previous:i,pageSize:e,current:s,total:this.total,pageCount:a}),this}setAction(t){const e=this.action,i=String(t||"").trim();return i&&i!==e?(this.setState({action:i}),this.emitComponentEvent("action-change",{previous:e,action:i}),this):this}setActionForAll(t){const e=this.actionForAll,i=Boolean(t);return i===e||(this.setState({actionForAll:i}),this.emitComponentEvent("action-for-all-change",{previous:e,actionForAll:i})),this}applyAction(){return this.action?(this.emitComponentEvent("action-apply",{action:this.action,actionForAll:this.actionForAll,current:this.current,total:this.total,pageSize:this.pageSize,pageCount:this.pageCount}),this):this}get state(){return{topClass:this.topClass,mainClass:this.mainClass,bottomClass:this.bottomClass,top:this.top,middle:this.middle,bottom:this.bottom,rootClass:this.getRootClass(),showMoreText:this.showMoreText,current:this.current,total:this.total,pageCount:this.pageCount,pageSize:this.pageSize,pageSizes:this.pageSizes,showPageSize:this.showPageSize,pageSizeLabel:this.pageSizeLabel,showActions:this.showActions,actions:this.actions,action:this.action,actionApplyText:this.actionApplyText,showActionForAll:this.showActionForAll,actionForAll:this.actionForAll,actionForAllLabel:this.actionForAllLabel}}setState(t={}){return Object.entries(t||{}).forEach(([t,e])=>{const i=o(t);i&&(!1!==e&&null!=e&&""!==e?!0!==e?this.setAttribute(i,String(e)):this.setAttribute(i,""):this.removeAttribute(i))}),this}onPageChange(t,e){return"function"==typeof t&&this.addEventListener("sf-page-change",e=>{t(e.detail?.current,e.detail,e)},e),this}onShowMore(t,e){return"function"==typeof t&&this.addEventListener("sf-show-more",e=>{t(e.detail,e)},e),this}}).define("sf-pagination")})();