(()=>{"use strict";const t="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},e="undefined"!=typeof window?window:{},n=t.SfBaseElement||e.SfBaseElement;if(!n)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const a=t.html||e.html,s=t.nothing||e.nothing,i=(t.render||e.render,t.litProps||e.litProps,t.toBoolean,t.toAttributeName),o=t.toNumber,r=(t.normalizeEnum,t.parseJsonAttribute,n);function l(...t){return t.flat().filter(Boolean).join(" ")}function c(t){return t?.type?SF.litHtml(t.type,t.props||{}):s}function d(t){const e="vertical"===t.type,n=l("sf-tabs",t.type?`sf-tabs--${t.type}`:"",e?"sf-tabs--vertical flex":"flex flex-col",t.rootClass);return a`
    <div
      class=${n}
      data-active-index=${String(t.activeIndex)}
      role="group"
    >
      <div class="sf-tabs-top-container">
        <div
          class=${l(`sf-tabs-top flex content-main-${t.topPosition}`,"vertical"===t.type?"flex-col":"",t.topClass)}
          role="tablist"
          aria-orientation=${e?"vertical":"horizontal"}
        >
          ${t.items.map(e=>function(t,e){const n=e.component?.hasSlotContent?.(t.tabSlotName)?e.component.getSlotContent(t.tabSlotName):s;return t.component?a`
      <span
        data-sf-tab-index=${String(t.index)}
        data-tab=${String(t.index)}
        role="tab"
        aria-selected=${t.selected?"true":"false"}
        tabindex=${t.selected?"0":"-1"}
      >
        ${c({...t.component,props:{...t.component.props||{},rootClass:l(t.component.props?.rootClass||"",t.selected?"selected":""),disabled:t.disabled||t.component.props?.disabled||!1}})}
      </span>
    `:"icons"!==e.variant?a`
          <sf-button
                  type="primary"
                  size=${e.size}
                  scheme=${e.scheme}
                  text=${t.label}
                  icon=${t.icon||s}
                  icon-left=${t.iconLeft||s}
                  icon-right=${t.iconRight||s}
                  root-class=${l(t.selected?"selected":"")}
                  data-sf-tab-index=${String(t.index)}
                  data-tab=${String(t.index)}
                  aria-selected=${t.selected?"true":"false"}
                  tabindex=${t.selected?"0":"-1"}
                  ?disabled=${t.disabled}
          >
              ${n===s?s:a`<span slot="text">${n}</span>`}
          </sf-button>
      `:a`
          <sf-icon-button
                  type="primary"
                  size=${e.size}
                  scheme=${e.scheme}
                  icon=${t.icon||s}
                  root-class=${l(t.selected?"selected":"")}
                  data-sf-tab-index=${String(t.index)}
                  data-tab=${String(t.index)}
                  aria-selected=${t.selected?"true":"false"}
                  tabindex=${t.selected?"0":"-1"}
                  ?disabled=${t.disabled}
          >
          </sf-icon-button>
      `}(e,t))}
        </div>
      </div>

      <div class="sf-tabs-main-container">
        ${t.items.map(e=>function(t,e){const n=!e.lazy||t.selected,i=n&&e.component?.hasSlotContent?.(t.slotName)?e.component.getSlotContent(t.slotName):s,o=n&&t.panel?.component?c(t.panel.component):n&&void 0!==t.panel?.text?t.panel.text:s;return a`
    <div
      class=${l("sf-tabs-main-tab",t.selected?"selected":"",e.panelClass)}
      role="tabpanel"
      data-sf-tab-panel=${String(t.index)}
      ?hidden=${!t.selected}
    >
      ${i===s?o:i}
    </div>
  `}(e,t))}
      </div>
    </div>
  `}function u(t){return t instanceof HTMLElement&&t.tagName.toLowerCase().startsWith("sf-")}function m(t){return t instanceof HTMLElement&&t.localName.includes("-")}function f(t){if(!(t instanceof HTMLElement))return null;const e=Array.from(t.children);for(;e.length;){const t=e.shift();if(t instanceof HTMLElement){if(!m(t))return t;e.unshift(...Array.from(t.children))}}return null}function p(t){if(!(t instanceof HTMLElement))return t;if(m(t))return f(t)||t;return t.getBoundingClientRect().height||t.offsetHeight?t:f(t)||t.firstElementChild||t}function h(t){const e=function(t){const e=Number.parseInt(t?.dataset?.maxItems||"",10);return Number.isFinite(e)&&e>0?e:0}(t);if(function(t){t&&(t.style.maxHeight="",t.style.paddingInlineEnd="",t.style.overflowY="")}(t),!e)return 0;const n=function(t){return t?Array.from(t.children).reduce((t,e)=>{if(!(e instanceof HTMLElement)||e.hidden)return t;const n=p(e);return"none"!==getComputedStyle(n).display&&t.push(n),t},[]):[]}(t);if(!n.length||n.length<=e)return t.getBoundingClientRect().height||t.scrollHeight||0;const a=function(t=[],e){if(!t.length)return 0;const n=e?getComputedStyle(e):null,a=n&&parseFloat(n.rowGap||n.gap)||0;return t.reduce((t,e)=>{const n=p(e);return t+(n.getBoundingClientRect().height||n.offsetHeight||0)},0)+a*Math.max(0,t.length-1)}(n.slice(0,e),t);return a?(t.style.maxHeight=`${Math.ceil(a)}px`,t.style.paddingInlineEnd="var(--sf-space-1\\/2)",t.style.overflowY="auto",a):0}function b(t,e={}){if(!(t instanceof Element))return[];const n=e.boundaryRoot||t,a=[];t.matches?.("[data-max-items]")&&a.push(t),t.querySelectorAll?.("[data-max-items]").forEach(t=>{a.push(t)});const s=a.filter(t=>function(t,e){if(!u(e))return!0;let n=t;for(;n&&n instanceof HTMLElement;){if(u(n))return n===e;n=n.parentElement}return!1}(t,n));return s.map(t=>({element:t,height:h(t)}))}function g(t,e){const n=o(t,0);return!Number.isFinite(n)||n<0||n>=e?0:n}function y(t=null){return t&&"object"==typeof t&&t.type?{type:t.type,props:t.props&&"object"==typeof t.props?t.props:{}}:null}function x(t={}){if("string"==typeof t)return{label:t};if(!t||"object"!=typeof t)return null;const e=y(t.component);return{...t,component:e,label:t.label||t.text||t.title||""}}function v(t={}){return"string"==typeof t?{text:t}:t&&"object"==typeof t?{...t,component:y(t.component)}:null}(class extends r{static get props(){return{templateName:{attribute:"template",default:"default"},type:{default:null},size:{default:"1"},variant:{default:"buttons"},scheme:{default:"default"},topPosition:{default:"start"},activeIndex:{type:Number,default:0},lazy:{type:Boolean,default:!1},items:{default:[],parser:t=>function(t=""){return Array.isArray(t)?t.map(t=>"string"==typeof t?{label:t}:t).filter(Boolean):String(t||"").split("|").map(t=>t.trim()).filter(Boolean).map(t=>{const[e,n=""]=t.split("::"),a=n.split(",").map(t=>t.trim().toLowerCase()).filter(Boolean),s={};return a.forEach(t=>{const[e,n]=t.split("=");n&&(s[e]=n)}),{label:e.trim(),disabled:a.includes("disabled"),icon:s.icon||"",iconLeft:s["icon-left"]||s.iconleft||"",iconRight:s["icon-right"]||s.iconright||""}})}(t)},rootClass:{default:""},topClass:{default:""},panelClass:{default:""}}}constructor(){super(),this._data={tabs:[],panels:[]},this._maxItemsFrame=null,this.addEventListener("click",this.handleRootClick),this.addEventListener("keydown",this.handleRootKeyDown)}getData(){const t=this._data;return t&&"object"==typeof t?t:{tabs:[],panels:[]}}normalizeData(t={}){const e=t.tabs||t.items||[],n=t.panels||t.content||[];return{...t,tabs:Array.isArray(e)?e.map(x).filter(Boolean):[],panels:Array.isArray(n)?n.map(v).filter(Boolean):[]}}setData(t={},e="data"){const n=this.getData(),a="function"==typeof t?t(n):t;return a&&"object"==typeof a?(this._data=this.normalizeData({...n,...a}),this.requestComponentUpdate(e),this):this}setItems(t=[],e="items"){const n="function"==typeof t?t(this.dataTabs):t;return this.setData({tabs:Array.isArray(n)?n:[]},e)}addItems(t=[],e="items"){const n=Array.isArray(t)?t:[t];return this.setItems(t=>[...t,...n.filter(Boolean)],e)}setPanels(t=[],e="panels"){const n="function"==typeof t?t(this.dataPanels):t;return this.setData({panels:Array.isArray(n)?n:[]},e)}addPanels(t=[],e="panels"){const n=Array.isArray(t)?t:[t];return this.setPanels(t=>[...t,...n.filter(Boolean)],e)}get items(){return this.getProp("items")}get dataTabs(){const t=this.getData();return Array.isArray(t.tabs)?t.tabs:[]}get dataPanels(){const t=this.getData();return Array.isArray(t.panels)?t.panels:[]}get panelSlotNames(){const t=new Set;return[this._slotTemplates,this._liveSlotNodes].forEach(e=>{e&&e.forEach((e,n)=>{/^panel-\d+$/.test(n)&&t.add(n)})}),Array.from(t).sort((t,e)=>o(t.replace("panel-",""),0)-o(e.replace("panel-",""),0))}get tabCount(){return Math.max(this.dataTabs.length,this.dataPanels.length,this.items.length,this.panelSlotNames.length)}get computedItems(){const t=this.dataTabs.length?this.dataTabs:this.items,e=this.dataPanels,n=this.activeIndex;return Array.from({length:this.tabCount}).map((a,s)=>{const i=t[s]||{};return{...i,label:i.label||`Tab ${s+1}`,disabled:Boolean(i.disabled),icon:i.icon||"",iconLeft:i.iconLeft||i.icon||"",iconRight:i.iconRight||"",component:i.component||null,panel:e[s]||null,index:s,slotName:i.slotName||`panel-${s}`,tabSlotName:i.tabSlotName||`tab-${s}`,selected:s===n}})}get activeIndex(){return g(this.getAttribute("active-index")||this.getAttribute("active")||this.getAttribute("data-active-index")||0,Math.max(this.tabCount,1))}templateContext(){const t=this.getPropsContext();return this.createTemplateContext({...t,component:this,activeIndex:this.activeIndex,rootClass:this.getRootClass(),items:this.computedItems,data:this.getData()})}template(){return d(this.templateContext())}getActivePanelElement(){return this.querySelector(`[data-sf-tab-panel="${this.activeIndex}"]`)}applyActivePanelMaxItems(){this._maxItemsFrame&&cancelAnimationFrame(this._maxItemsFrame),this._maxItemsFrame=requestAnimationFrame(()=>{this._maxItemsFrame=requestAnimationFrame(()=>{this._maxItemsFrame=null,b(this.getActivePanelElement()||this,{boundaryRoot:this})})})}get state(){return{...this.getPropsContext(),activeIndex:this.activeIndex,items:this.items,data:this.getData(),rootClass:this.getRootClass()}}setState(t={}){return Object.entries(t||{}).forEach(([t,e])=>{const n=i(t);if(n)if(!1!==e&&null!=e&&""!==e){if(Array.isArray(e)){const t=e.map(t=>{if("string"==typeof t)return t;const e=[];return t?.disabled&&e.push("disabled"),t?.icon&&e.push(`icon=${t.icon}`),t?.iconLeft&&e.push(`icon-left=${t.iconLeft}`),t?.iconRight&&e.push(`icon-right=${t.iconRight}`),e.length?`${t.label}::${e.join(",")}`:t.label}).join("|");return void this.setAttribute(n,t)}this.setAttribute(n,!0===e?"":String(e))}else this.removeAttribute(n)}),this}goTo(t){const e=this.computedItems,n=g(t,Math.max(e.length,1)),a=e[n];if(!a||a.disabled||n===this.activeIndex)return this;const s=this.activeIndex;return this.setAttribute("active-index",String(n)),this.emitComponentEvent("tab-change",{previous:s,current:n,item:a,items:e}),this}onTabChange(t,e){return"function"==typeof t&&this.addEventListener("sf-tab-change",e=>{t(e.detail?.current,e.detail,e)},e),this}handleRootClick=t=>{const e=t.target?.closest?.("[data-sf-tab-index]");e instanceof HTMLElement&&this.goTo(e.dataset.sfTabIndex)};handleRootKeyDown=t=>{if(!["Enter"," ","ArrowLeft","ArrowRight","ArrowUp","ArrowDown"].includes(t.key))return;const e=t.target?.closest?.("[data-sf-tab-index]");if(!(e instanceof HTMLElement))return;if(t.preventDefault(),"Enter"===t.key||" "===t.key)return void this.goTo(e.dataset.sfTabIndex);const n="ArrowLeft"===t.key||"ArrowUp"===t.key?-1:1,a=this.computedItems.filter(t=>!t.disabled);if(!a.length)return;const s=(a.findIndex(t=>t.index===this.activeIndex)+n+a.length)%a.length;this.goTo(a[s]?.index)};afterRender(){this.applyActivePanelMaxItems()}onDisconnected(){this._maxItemsFrame&&(cancelAnimationFrame(this._maxItemsFrame),this._maxItemsFrame=null),super.onDisconnected?.()}}).define("sf-tabs")})();