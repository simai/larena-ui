(()=>{"use strict";const t="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},e="undefined"!=typeof window?window:{},a=t.SfBaseElement||e.SfBaseElement;if(!a)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const i=t.html||e.html,s=t.nothing||e.nothing,r=(t.render||e.render,t.litProps||e.litProps,t.toBoolean,t.toAttributeName,t.toNumber,t.normalizeEnum,t.parseJsonAttribute,a);function n(t){switch(t.status){case"company":return t.component?.hasSlotContent?.("company-badge")?t.component.getSlotContent("company-badge"):function(t){return i`<span
            class="sf-avatar-badge sf-avatar-badge--size-${t.size} sf-avatar-badge--company overflow-hidden flex absolute bottom-0 inline-end-0"
    >
    <svg viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M56 0H0V55.9998H56V0Z" fill="#E81123"></path>
      <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M8.12891 28.0004L23.1261 12.9463L27.9999 17.8386L17.8754 28.0016L27.998 38.1627L23.1254 43.0538L8.12891 28.0004Z"
              fill="#F7F7F7"
      ></path>
      <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M47.8706 28.0004L32.8735 12.9463L27.9996 17.8386L38.1241 28.0016L28.0015 38.1627L32.8741 43.0538L47.8706 28.0004Z"
              fill="#F7F7F7"
      ></path>
    </svg>
  </span>`}(t);case"verified":return t.component?.hasSlotContent?.("verified-badge")?t.component.getSlotContent("verified-badge"):function(t){return i`
        <span
                class="sf-avatar-badge sf-avatar-badge--size-${t.size} sf-avatar-badge--verified overflow-hidden flex absolute bottom-0 inline-end-0"
        >
      <svg viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g clip-path="url(#sf-avatar-verified-badge)">
          <path
                  d="M15.4447 3.54197C15.6347 4.00136 15.9993 4.36651 16.4584 4.55716L18.0683 5.22398C18.5277 5.41428 18.8927 5.7793 19.083 6.23872C19.2733 6.69815 19.2733 7.21436 19.083 7.67379L18.4167 9.28249C18.2263 9.74212 18.226 10.2589 18.4173 10.7183L19.0824 12.3265C19.1768 12.554 19.2254 12.7979 19.2254 13.0443C19.2254 13.2906 19.1769 13.5345 19.0827 13.7621C18.9884 13.9897 18.8502 14.1965 18.676 14.3706C18.5018 14.5448 18.295 14.6829 18.0674 14.7771L16.4587 15.4434C15.9993 15.6334 15.6341 15.998 15.4435 16.4571L14.7767 18.067C14.5864 18.5264 14.2213 18.8914 13.7619 19.0817C13.3025 19.272 12.7863 19.272 12.3269 19.0817L10.7181 18.4153C10.2587 18.2255 9.74268 18.2259 9.28353 18.4164L7.67367 19.0823C7.2145 19.2722 6.69874 19.272 6.23969 19.0818C5.78063 18.8917 5.41582 18.5271 5.22539 18.0682L4.55837 16.4578C4.36841 15.9985 4.00381 15.6333 3.5447 15.4427L1.93484 14.7758C1.47561 14.5856 1.11071 14.2208 0.920338 13.7617C0.729967 13.3025 0.729708 12.7865 0.91962 12.3272L1.58597 10.7185C1.7758 10.259 1.77541 9.74301 1.58489 9.28386L0.919499 7.67284C0.82516 7.44529 0.776583 7.20139 0.776543 6.95506C0.776504 6.70873 0.825003 6.4648 0.919269 6.23723C1.01354 6.00965 1.15172 5.80287 1.32593 5.62872C1.50014 5.45457 1.70696 5.31645 1.93457 5.22225L3.54327 4.55591C4.00226 4.36612 4.3672 4.00197 4.55798 3.5434L5.22481 1.93354C5.41511 1.47411 5.78012 1.10909 6.23955 0.918793C6.69898 0.728492 7.21519 0.728492 7.67461 0.918793L9.28332 1.58514C9.74276 1.77497 10.2588 1.77459 10.7179 1.58406L12.3285 0.919827C12.7878 0.729632 13.3039 0.729671 13.7633 0.919935C14.2226 1.1102 14.5876 1.47511 14.7779 1.93442L15.4449 3.54475L15.4447 3.54197Z"
                  fill="#005BBE"
          ></path>
          <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  d="M13.9166 7.37864C14.0502 7.16879 14.0949 6.91446 14.041 6.6716C13.9871 6.42874 13.8389 6.21724 13.6291 6.08364C13.4192 5.95004 13.1649 5.90527 12.922 5.95919C12.6792 6.0131 12.4677 6.16129 12.3341 6.37114L8.66283 12.1399L6.98283 10.0399C6.82751 9.84562 6.60138 9.72101 6.35418 9.69346C6.10699 9.66592 5.85897 9.7377 5.6647 9.89302C5.47043 10.0483 5.34582 10.2745 5.31827 10.5217C5.29073 10.7689 5.36251 11.0169 5.51783 11.2111L8.01783 14.3361C8.111 14.4528 8.23066 14.5454 8.36687 14.6065C8.50308 14.6675 8.65189 14.6951 8.80093 14.6871C8.94998 14.679 9.09494 14.6355 9.22376 14.5601C9.35258 14.4847 9.46154 14.3796 9.54158 14.2536L13.9166 7.37864V7.37864Z"
                  fill="white"
          ></path>
        </g>
        <defs>
          <clipPath id="sf-avatar-verified-badge">
            <rect width="20" height="20" fill="white"></rect>
          </clipPath>
        </defs>
      </svg>
    </span>
    `}(t);default:return function(t){return t.component?.hasSlotContent?.("online-indicator")?t.component.getSlotContent("online-indicator"):["online","offline"].includes(t.status)?i`
        <span
                class="sf-online-indicator sf-online-indicator--${t.status} ${{"1/4":"sf-online-indicator--size-1/4","1/3":"sf-online-indicator--size-1/3","1/2":"sf-online-indicator--size-1/2",1:"sf-online-indicator--size-1"}[t.size]||""} flex absolute bottom-0 inline-end-0"
        ></span>
    `:s}(t)}}function l(t,e={}){const a=function(t,e={}){const a=!1!==e.includeRootClass,i=["sf-avatar","transition","flex-none",`sf-avatar--size-${t.size}`,"inline-flex"];return t.isImage&&i.push("bg-cover"),t.isText&&i.push("sf-avatar--text","items-cross-center","content-main-center"),t.isImage||t.isText||i.push("sf-avatar--placeholder","items-cross-center","content-main-center"),"none"!==t.status&&i.push("relative"),"online"===t.status&&i.push("sf-avatar--status-icon-online-indicator"),t.inactive&&i.push("sf-avatar--static"),a&&t.rootClass&&i.push(t.rootClass),i.join(" ")}(t,e),s=function(...t){return t.filter(Boolean).join("; ")}(function(t){return t.isImage?`background-image: url(${t.imageUrl});`:""}(t),!1===e.includeRootStyle?"":t.rootStyle),r=i`${function(t){return t.isText?i`<span class="sf-avatar-text">${t.text}</span>`:t.isImage?"":i`<i class="sf-icon">person</i>`}(t)} ${n(t)}`;return t.inactive?i`
            <span
                    class="${a}"
                    style=${s}
                    aria-label=${t.ariaLabel}
                    role="img"
            >
                ${r}
            </span>
        `:i`
        <button
                class="${a}"
                style=${s}
                aria-label=${t.ariaLabel}
                ?disabled=${t.disabled}
                type="button"
        >
            ${r}
        </button>
    `}const o=new Set(["а","без","в","во","для","до","за","из","из-за","из-под","и","к","ко","между","на","над","о","об","от","по","под","при","про","с","со","у","через","the","a","an","and","for","from","in","of","on","to"]);function d(t="",e={}){const{maxLetters:a=2,skipWords:i=o}=e,s=function(t=""){return String(t||"").trim().split(/[\s/|]+/).map(t=>t.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu,"")).filter(Boolean)}(t),r=s.filter((t,e)=>0===e||!i.has(String(t).toLowerCase()));return r.length?r.length>1?r.slice(0,a).map(t=>Array.from(t)[0]||"").join("").toUpperCase():Array.from(r[0]).slice(0,1).join("").toUpperCase():""}const u={default:function(t){return l(t)},label:function(t){return i`
    <div
      class="sf-avatar-label-group sf-avatar-label-group--size-${t.size} max-w-full flex items-cross-center ${t.rootClass||""}"
      style=${t.rootStyle||""}
    >
      ${l(t,{includeRootClass:!1,includeRootStyle:!1})}
      <div class="sf-avatar-label-group-container flex flex-col">
        ${t.title?i`<div class="sf-avatar-label-group-title${t.noWrap?" overflow-hidden wrap-none t-ellipsis":""}">
              ${t.title}
            </div>`:""}
        ${t.description?i`<div class="sf-avatar-label-group-text${t.noWrap?" overflow-hidden wrap-none t-ellipsis":""}">
              ${t.description}
            </div>`:""}
      </div>
    </div>
  `},card:function(t){const e=t.cardVariant||"square",a=t.imageAlt||t.ariaLabel||t.title||"Avatar card";return i`
    <div
      class="sf-avatar-card sf-avatar-card-${e} flex flex-col ${t.rootClass||""}"
      style=${t.rootStyle||""}
    >
      <div class="sf-avatar-card-image flex flex-col">
        ${t.imageUrl?i`<img src=${t.imageUrl} alt=${a} />`:i`<div
              class="sf-avatar-card-placeholder bg-surface-container w-full h-full"
            ></div>`}
      </div>
      <div class="sf-avatar-card-content flex-1 flex flex-col">
        ${t.title?i`<div class="sf-avatar-card-title">${t.title}</div>`:""}
        ${t.meta||t.description?i`
              <div class="sf-avatar-card-row flex flex-row items-center">
                ${t.metaIcon?i`<i class="sf-icon">${t.metaIcon}</i>`:""}
                <span>${t.meta||t.description}</span>
              </div>
            `:""}
      </div>
    </div>
  `}};(class extends r{static get props(){return{templateName:{attribute:"template",default:"default"},size:{default:"1"},imageUrl:{default:""},imageAlt:{default:""},noWrap:{type:Boolean,default:!1},text:{default:""},status:{default:"none"},ariaLabel:{default:"Avatar"},title:{default:""},description:{default:""},meta:{default:""},metaIcon:{default:""},cardVariant:{default:"square"},disabled:{type:Boolean,default:!1},inactive:{type:Boolean,default:!1}}}constructor(){super()}get templateName(){return this.getAttribute("template")||"default"}set templateName(t){this.setAttribute("template",t||"default")}get size(){return this.getAttribute("size")||"1"}set size(t){this.setAttribute("size",t)}get imageUrl(){return this.getAttribute("image-url")||""}set imageUrl(t){null!=t&&""!==t?this.setAttribute("image-url",t):this.removeAttribute("image-url")}get imageAlt(){return this.getAttribute("image-alt")||""}set imageAlt(t){null!=t&&""!==t?this.setAttribute("image-alt",t):this.removeAttribute("image-alt")}get text(){return this.getAttribute("text")||""}set text(t){null!=t&&""!==t?this.setAttribute("text",t):this.removeAttribute("text")}get status(){return this.getAttribute("status")||"none"}set status(t){this.setAttribute("status",t||"none")}get ariaLabel(){return this.getAttribute("aria-label")||"Avatar"}set ariaLabel(t){t?this.setAttribute("aria-label",t):this.removeAttribute("aria-label")}get title(){return this.getAttribute("title")||""}set title(t){t?this.setAttribute("title",t):this.removeAttribute("title")}get description(){return this.getAttribute("description")||""}set description(t){t?this.setAttribute("description",t):this.removeAttribute("description")}get meta(){return this.getAttribute("meta")||""}set meta(t){t?this.setAttribute("meta",t):this.removeAttribute("meta")}get metaIcon(){return this.getAttribute("meta-icon")||""}set metaIcon(t){t?this.setAttribute("meta-icon",t):this.removeAttribute("meta-icon")}get cardVariant(){return this.getAttribute("card-variant")||"square"}set cardVariant(t){this.setAttribute("card-variant",t||"square")}get disabled(){return this.getBooleanAttr("disabled",!1)}set disabled(t){t?this.setAttribute("disabled",""):this.removeAttribute("disabled")}get inactive(){return this.getBooleanAttr("inactive",!1)}get interactive(){return!this.inactive}get isImage(){return!!this.imageUrl}get isText(){return!this.isImage&&!!this.displayText}get displayText(){return this.text?this.text:this.isImage?"":d(this.title||(this.hasAttribute("aria-label")?this.ariaLabel:""))}templateContext(){const t=this.getPropsContext();return this.createTemplateContext({...t,component:this,isImage:this.isImage,isText:this.isText,text:this.displayText,rootClass:this.getRootClass(),rootStyle:this.getRootStyle()})}hasBuiltInTemplate(t=this.templateName){return Object.prototype.hasOwnProperty.call(u,t)}templateRenderer(){return u[this.templateName]||u.default}template(){return this.templateRenderer()(this.templateContext())}resolveUpdateMode(t=[]){const e=["disabled"];return t.length>0&&t.every(t=>e.includes(t))?"dom":"lit"}updateDom(t=[]){const e=this.querySelector(".sf-avatar");return!!e&&(t.includes("aria-label")&&e.setAttribute("aria-label",this.ariaLabel),t.includes("disabled")&&(e.disabled=this.disabled),!0)}get value(){return{template:this.templateName,size:this.size,imageUrl:this.imageUrl,imageAlt:this.imageAlt,text:this.text,status:this.status,ariaLabel:this.ariaLabel,title:this.title,description:this.description,meta:this.meta,metaIcon:this.metaIcon,cardVariant:this.cardVariant,disabled:this.disabled,inactive:this.inactive}}set value(t){this.setValueAttributes(t)}}).define("sf-avatar")})();