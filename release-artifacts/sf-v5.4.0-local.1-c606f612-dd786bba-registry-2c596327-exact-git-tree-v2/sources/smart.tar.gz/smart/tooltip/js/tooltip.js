(()=>{"use strict";const t="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},e="undefined"!=typeof window?window:{},o=t.SfBaseElement||e.SfBaseElement;if(!o)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const n=t.html||e.html,i=t.nothing||e.nothing,s=(t.render||e.render,t.litProps||e.litProps,t.toBoolean,t.toAttributeName,t.toNumber,t.normalizeEnum,t.parseJsonAttribute,o);function l(t){const e=["sf-tooltip",`sf-tooltip--${t.type}`,`sf-tooltip--arrow-${t.arrow}`,`sf-tooltip--size-${t.size}`,"relative"].filter(Boolean);return n`
    <div class=${e.join(" ")}>
      ${function(t){if(t.component?.hasSlotContent?.("content"))return t.component.getSlotContent("content");const e=t.component?.hasSlotContent?.("text")?t.component.getSlotContent("text"):t.text,o=t.component?.hasSlotContent?.("supporting-text")?t.component.getSlotContent("supporting-text"):t.supportingText;return n`
    <div class="sf-tooltip-content flex flex-col">
      ${e?n`<div class="sf-tooltip-text">${e}</div>`:i}
      ${o?n`<div class="sf-tooltip-supporting-text">${o}</div>`:i}
    </div>
  `}(t)}
      ${function(t){return t.component?.hasSlotContent?.("tail")?t.component.getSlotContent("tail"):n`<div class="sf-tooltip-tail"></div>`}(t)}
    </div>
  `}(class extends s{static get props(){return{templateName:{attribute:"template",default:"default"},type:{type:String,default:"light"},size:{default:"1"},arrow:{default:"none"},text:{default:""},supportingText:{default:""}}}templateContext(){return this.createTemplateContext({component:this,...this.getPropsContext()})}template(){return l(this.templateContext())}}).define("sf-tooltip")})();