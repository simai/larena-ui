(()=>{"use strict";const e="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},t="undefined"!=typeof window?window:{},i=e.SfBaseElement||t.SfBaseElement;if(!i)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const n=e.html||t.html,s=e.nothing||t.nothing,a=e.render||t.render,l=(e.litProps||t.litProps,e.toBoolean,e.toAttributeName,e.toNumber,e.normalizeEnum,e.parseJsonAttribute,i),r=globalThis,o=e=>e,c=r.trustedTypes,d=c?c.createPolicy("lit-html",{createHTML:e=>e}):void 0,u="$lit$",p=`lit$${Math.random().toFixed(9).slice(2)}$`,m="?"+p,h=`<${m}>`,f=document,g=()=>f.createComment(""),y=e=>null===e||"object"!=typeof e&&"function"!=typeof e,b=Array.isArray,v=e=>b(e)||"function"==typeof e?.[Symbol.iterator],S="[ \t\n\f\r]",C=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,x=/-->/g,T=/>/g,k=RegExp(`>|${S}(?:([^\\s"'>=/]+)(${S}*=${S}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),A=/'/g,F=/"/g,w=/^(?:script|style|textarea|title)$/i,$={},D=new WeakMap,E=e=>(t,...i)=>({_$litType$:e,strings:t,values:i}),_=(E(1),E(2),E(3),Symbol.for("lit-noChange")),z=Symbol.for("lit-nothing"),M=new WeakMap,R=f.createTreeWalker(f,129);function L(e,t){if(!b(e)||!e.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==d?d.createHTML(t):t}const O=(e,t)=>{const i=e.length-1,n=[];let s,a=2===t?"<svg>":3===t?"<math>":"",l=C;for(let t=0;t<i;t++){const i=e[t];let r,o,c=-1,d=0;for(;d<i.length&&(l.lastIndex=d,o=l.exec(i),null!==o);)d=l.lastIndex,l===C?"!--"===o[1]?l=x:void 0!==o[1]?l=T:void 0!==o[2]?(w.test(o[2])&&(s=RegExp("</"+o[2],"g")),l=k):void 0!==o[3]&&(l=k):l===k?">"===o[0]?(l=s??C,c=-1):void 0===o[1]?c=-2:(c=l.lastIndex-o[2].length,r=o[1],l=void 0===o[3]?k:'"'===o[3]?F:A):l===F||l===A?l=k:l===x||l===T?l=C:(l=k,s=void 0);const m=l===k&&e[t+1].startsWith("/>")?" ":"";a+=l===C?i+h:c>=0?(n.push(r),i.slice(0,c)+u+i.slice(c)+p+m):i+p+(-2===c?t:m)}return[L(e,a+(e[i]||"<?>")+(2===t?"</svg>":3===t?"</math>":"")),n]};class P{constructor({strings:e,_$litType$:t},i){let n;this.parts=[];let s=0,a=0,l=0;const r=e.length-1,o=this.parts,d=(e,t=1)=>{o.push(e),l+=t},[h,f]=O(e,t);if(this.el=P.createElement(h,i),R.currentNode=this.el.content,2===t||3===t){const e=this.el.content.firstChild;e.replaceWith(...e.childNodes)}for(;null!==(n=R.nextNode())&&o.length<r;){if(1===n.nodeType){if(n.hasAttributes())for(const e of n.getAttributeNames())if(e.endsWith(u)){const t=f[a++],i=n.getAttribute(e).split(p),r=/([.?@:])?(.*)/.exec(t);"..."===t?d({type:10,index:s},i.length-1):":"!==r[1]||"key"!==r[2]&&"ref"!==r[2]?d({type:1,index:s,name:r[2],strings:i,ctor:"."===r[1]?U:"?"===r[1]?K:"@"===r[1]?G:H},i.length-1):"key"===r[2]?(this.keyedValueIndex=l,d({type:8,index:s},i.length-1)):d({type:9,index:s},i.length-1),n.removeAttribute(e)}else e.startsWith(p)&&(d({type:6,index:s}),n.removeAttribute(e));if(w.test(n.tagName)){const e=n.textContent.split(p),t=e.length-1;if(t>0){n.textContent=c?c.emptyScript:"";for(let i=0;i<t;i++)n.append(e[i],g()),R.nextNode(),d({type:2,index:++s});n.append(e[t],g())}}}else if(8===n.nodeType)if(n.data===m)d({type:2,index:s});else{let e=-1;for(;-1!==(e=n.data.indexOf(p,e+1));)d({type:7,index:s}),e+=p.length-1}s++}}static createElement(e,t){const i=f.createElement("template");return i.innerHTML=e,i}}function N(e,t,i=e,n){if(t===_)return t;let s=void 0!==n?i._$Co?.[n]:i._$Cl;const a=y(t)?void 0:t._$litDirective$;return s?.constructor!==a&&(s?._$AO?.(!1),void 0===a?s=void 0:(s=new a(e),s._$AT(e,i,n)),void 0!==n?(i._$Co??=[])[n]=s:i._$Cl=s),void 0!==s&&(t=N(e,s._$AS(e,t.values),s,n)),t}class I{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){const{el:{content:t},parts:i}=this._$AD,n=(e?.creationScope??f).importNode(t,!0);R.currentNode=n;let s=R.nextNode(),a=0,l=0,r=i[0];for(;void 0!==r;){if(a===r.index){let t;2===r.type?t=new V(s,s.nextSibling,this,e):1===r.type?t=new r.ctor(s,r.name,r.strings,this,e):9===r.type?t=new j(s,this,e):10===r.type?t=new W(s,this,e):6===r.type&&(t=new Y(s,this,e)),this._$AV.push(t),r=i[++l]}a!==r?.index&&(s=R.nextNode(),a++)}return R.currentNode=f,n}p(e){let t=0;for(const i of this._$AV)void 0!==i&&(void 0!==i.strings?(i._$AI(e,i,t),t+=i.strings.length-2):i._$AI(e[t])),t++}v(){for(const e of this._$AV)B(e)}}const B=e=>{if(e instanceof j)e.m();else if(e instanceof W)e._();else if(e instanceof V)B(e._$AH);else if(e instanceof I)e.v();else if(b(e))for(const t of e)B(t)};class V{get _$AU(){return this._$AM?._$AU??this._$C$}constructor(e,t,i,n){this.type=2,this._$AH=z,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=i,this.options=n,this._$C$=n?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return void 0!==t&&11===e?.nodeType&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=N(this,e,t),y(e)?e===z||null==e||""===e?(this._$AH!==z&&this._$AR(),this._$AH=z):e!==this._$AH&&e!==_&&this.T(e):void 0!==e._$litType$?this.S(e):void 0!==e.nodeType?this.j(e):v(e)?this.O(e):this.T(e)}M(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}j(e){this._$AH!==e&&(this._$AR(),this._$AH=this.M(e))}T(e){this._$AH!==z&&y(this._$AH)?this._$AA.nextSibling.data=e:this.j(f.createTextNode(e)),this._$AH=e}S(e){const{values:t,_$litType$:i}=e,n="number"==typeof i?this._$AC(e):(void 0===i.el&&(i.el=P.createElement(L(i.h,i.h[0]),this.options)),i);if(this._$AH?._$AD===n)this._$AH.p(t);else{const e=new I(n,this),i=e.u(this.options);e.p(t),this.j(i),this._$AH=e}}_$AC(e){let t=M.get(e.strings);return void 0===t&&M.set(e.strings,t=new P(e)),t}A(e){if(void 0===e?._$litType$)return $;const{values:t,_$litType$:i}=e;if("number"!=typeof i)return $;const n=this._$AC(e);return void 0===n.keyedValueIndex?$:t[n.keyedValueIndex]}P(e){const t=this._$AA.parentNode;let i=e._$AA;const n=e._$AB;for(;null!==i;){const e=o(i).nextSibling;if(o(t).insertBefore(i,this._$AB),i===n)break;i=e}}C(e){B(e._$AH),e._$AP?.(!1,!0);let t=e._$AA;const i=e._$AB;for(;null!==t;){const e=o(t).nextSibling;if(o(t).remove(),t===i)break;t=e}}O(e){const t=Array.from(e),i=t.map(e=>this.A(e));if(i.some(e=>e!==$)&&i.every(e=>e!==$)){const e=new Set;let n=!1;for(const t of i){if(e.has(t)){n=!0;break}e.add(t)}if(!n)return void this.L(t,i)}b(this._$AH)||(this._$AH=[],this._$AR());const n=this._$AH;let s,a=0;for(const e of t)a===n.length?n.push(s=new V(this.M(g()),this.M(g()),this,this.options)):s=n[a],s._$AI(e),a++;a<n.length&&(this._$AR(s&&s._$AB.nextSibling,a),n.length=a)}L(e,t){b(this._$AH)||(this._$AH=[],this._$AR());const i=this._$AH,n=new Map;for(const e of i)Object.prototype.hasOwnProperty.call(e,"_$key")&&n.set(e.R,e);const s=[];for(let i=0;i<e.length;i++){const a=t[i];let l=n.get(a);void 0===l?l=new V(this.M(g()),this.M(g()),this,this.options):n.delete(a),l.R=a,l._$AI(e[i]),this.P(l),s.push(l)}for(const e of i)s.includes(e)||this.C(e);i.length=0,i.push(...s)}_$AR(e=this._$AA.nextSibling,t){for(B(void 0!==t&&b(this._$AH)?this._$AH.slice(t):this._$AH),this._$AP?.(!1,!0,t);e!==this._$AB;){const t=o(e).nextSibling;o(e).remove(),e=t}}setConnected(e){void 0===this._$AM&&(this._$C$=e,this._$AP?.(e))}}class H{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,i,n,s){this.type=1,this._$AH=z,this._$AN=void 0,this.element=e,this.name=t,this._$AM=n,this.options=s,i.length>2||""!==i[0]||""!==i[1]?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=z}_$AI(e,t=this,i,n){const s=this.strings;let a=!1;if(void 0===s)e=N(this,e,t,0),a=!y(e)||e!==this._$AH&&e!==_,a&&(this._$AH=e);else{const n=e;let l,r;for(e=s[0],l=0;l<s.length-1;l++)r=N(this,n[i+l],t,l),r===_&&(r=this._$AH[l]),a||=!y(r)||r!==this._$AH[l],r===z?e=z:e!==z&&(e+=(r??"")+s[l+1]),this._$AH[l]=r}a&&!n&&this.D(e)}D(e){e===z?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}}class U extends H{constructor(){super(...arguments),this.type=3}D(e){this.element[this.name]=e===z?void 0:e}}class K extends H{constructor(){super(...arguments),this.type=4}D(e){this.element.toggleAttribute(this.name,!!e&&e!==z)}}class j{constructor(e,t,i){this.type=9,this._$AH=z,this._$AN=void 0,this.element=e,this._$AM=t,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(e){e!==_&&(e=e===z||null==e?void 0:e)!==this._$AH&&(this.I(void 0),this._$AH=e,this.H=e,this.N=this.options?.host,this.I(this.element))}I(e){if(void 0!==this.H)if("function"==typeof this.H){const t=this.N??globalThis;let i=D.get(t);void 0===i&&(i=new WeakMap,D.set(t,i)),void 0!==i.get(this.H)&&this.H.call(this.N,void 0),i.set(this.H,e),void 0!==e&&this.H.call(this.N,e)}else this.H.value=e}m(){this.I(void 0),this._$AH=z,this.H=void 0}}const q=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();class W{constructor(e,t,i){this.type=10,this._$AH=z,this._$AN=void 0,this.U=new Set,this.B=new Set,this.F=new Set,this.W=new Map,this.element=e,this._$AM=t,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(e){if(e===_)return;e!==z&&null!=e||(e={});const t=e,i=new Set,n=new Set,s=new Set,a=new Set;let l=!1;for(const[e,r]of Object.entries(t)){if("key"===e||":key"===e)continue;if("ref"===e||":ref"===e){l=!0,(this.Z??=new j(this.element,this._$AM,this.options))._$AI(r);continue}const t=e[0],c=e.slice(1);if("."===t)n.add(c),this.element[c]=r===z?void 0:r;else if("?"===t){const e=q(c);s.add(e),o(this.element).toggleAttribute(e,!!r&&r!==z)}else if("@"===t){a.add(c);const e=this.W.get(c),t=r===z||null==r?void 0:r;e!==t&&(void 0!==e&&this.element.removeEventListener(c,e,e),void 0!==t?(this.element.addEventListener(c,t,t),this.W.set(c,t)):this.W.delete(c))}else{const t=q(e);i.add(t),r===z||null==r||!1===r?o(this.element).removeAttribute(t):o(this.element).setAttribute(t,!0===r?"":r+"")}}for(const e of this.U)i.has(e)||o(this.element).removeAttribute(e);for(const e of this.F)s.has(e)||o(this.element).removeAttribute(e);for(const e of this.B)n.has(e)||(this.element[e]=void 0);for(const[e,t]of this.W)a.has(e)||(this.element.removeEventListener(e,t,t),this.W.delete(e));l||this.Z?.m(),this.U=i,this.B=n,this.F=s,this._$AH=e}_(){for(const[e,t]of this.W)this.element.removeEventListener(e,t,t);this.W.clear(),this.Z?.m(),this._$AH=z}}class G extends H{constructor(e,t,i,n,s){super(e,t,i,n,s),this.type=5}_$AI(e,t=this){if((e=N(this,e,t,0)??z)===_)return;const i=this._$AH,n=e===z&&i!==z||e.capture!==i.capture||e.once!==i.once||e.passive!==i.passive,s=e!==z&&(i===z||n);n&&this.element.removeEventListener(this.name,this,i),s&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){"function"==typeof this._$AH?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}}class Y{constructor(e,t,i){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(e){N(this,e)}}const X={q:u,G:p,K:m,Y:1,X:O,J:I,tt:v,et:N,it:V,st:H,nt:K,ot:G,rt:U,lt:Y},Z=r.litHtmlPolyfillSupport;Z?.(P,V),(r.litHtmlVersions??=[]).push("3.3.3");const J=2,Q=e=>(...t)=>({_$litDirective$:e,values:t});class ee{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,i){this._$Ct=e,this._$AM=t,this._$Ci=i}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}}const{it:te}=X,ie={},ne=Q(class extends ee{constructor(){super(...arguments),this.key=z}render(e,t){return this.key=e,t}update(e,[t,i]){return t!==this.key&&(((e,t=ie)=>{e._$AH=t})(e),this.key=t),i}});class se extends ee{constructor(e){if(super(e),this.yt=z,e.type!==J)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(e){if(e===z||null==e)return this.Mt=void 0,this.yt=e;if(e===_)return e;if("string"!=typeof e)throw Error(this.constructor.directiveName+"() called with a non-string value");if(e===this.yt)return this.Mt;this.yt=e;const t=[e];return t.raw=t,this.Mt={_$litType$:this.constructor.resultType,strings:t,values:[]}}}se.directiveName="unsafeHTML",se.resultType=1;const ae=Q(se),le="__sf_fill";function re(e,t=""){const i=e?.composedPath?.()?.[0],n=[i,e?.target,e?.currentTarget];for(const e of n){if(!e)continue;if(void 0!==e.value)return e.value;const t=e.querySelector?.("input, textarea");if(t&&void 0!==t.value)return t.value}return t}function oe(e){return null==e||""===e?"":"number"==typeof e?`${e}px`:String(e)}function ce(e={}){const t=oe(e.colWidth??e.width??e.size);return t?`width: ${t}; min-width: ${t}; max-width: ${t}`:""}function de(e){return null==e?"":"object"==typeof e?e.href||e.url||e.value||e.displayValue||"":String(e)}function ue(e){return null==e?"":"object"==typeof e?e.label||e.title||e.name||e.text||de(e):String(e)}function pe(e){const t=de(e).trim();return t?/^(https?:|mailto:|tel:)/i.test(t)?t:`https://${t}`:""}function me(e,t={}){const i=e.component.getFieldType?.(t);return"link"===(t.column?.renderer||t.detail?.renderer||t.renderer)||"link"===i||"link"===t.type||"url"===t.dataType}function he(e){const t=pe(e),i=ue(e);return t&&i?n`
        <sf-link
                link=${t}
                text=${i}
                root-class="min-w-0 overflow-hidden"
        ></sf-link>
    `:s}function fe(e){if(!e?.type)return s;const t=e.props||{};return t[":key"]=`item_${Math.random()}`,SF.litHtml(e.type,t)}function ge(e={}){return{id:e.id??e.value,title:e.title||e.label||e.name||e.fullName||"",imageUrl:e.imageUrl||e.avatarImageUrl||e.avatar||e.image||""}}function ye(e={},t,i={}){const n=e.type,s={};if("avatars"===n){const i=Array.isArray(t?.items)?t.items:Array.isArray(t)?t:[];s.avatars=i.length?i.map(ge):t?.component?.props?.avatars||e.props?.avatars||[]}else if("avatar"===n)Object.assign(s,ge(t||{}));else if("tag"===n){const i=t?.label||t?.title||t?.name||t?.text||t?.value||t||"";s.text=i,s.type=t?.type||t?.component?.props?.type||e.props?.type||"default"}else"progress-scale"===n?s.value=t?.value??t:"file-preview"===n?(s.value=t?.value||t?.url||t?.displayValue||"",s.name=t?.name||t?.fileName||t?.title||s.value,s.fileSize=t?.fileSize||t?.sizeText||"",s.imageUrl=t?.imageUrl||t?.previewUrl||""):"link"===n?(s.link=pe(t),s.text=ue(t)):s.value=t?.value??t;return{...e.props||{},...s,...i.props||{}}}function be(e,t,i={}){if(!e?.type)return s;const a=fe({...e,props:ye(e,t,i)}),l=t?.detailEntity||t?.entity,r=t?.detailRow||t;return l&&!1!==t?.detail?n`
        <span
                class="sf-table-cell-detail-trigger inline-flex items-cross-center max-w-full"
                role="button"
                tabindex="0"
                @click=${e=>{e.preventDefault(),e.stopPropagation(),i.context?.component?.openEntityDetail?.(l,r)}}
                @keydown=${e=>{"Enter"!==e.key&&" "!==e.key||(e.preventDefault(),e.stopPropagation(),i.context?.component?.openEntityDetail?.(l,r))}}
        >
            ${a}
        </span>
    `:a}function ve(e,t={}){if(null==e)return s;if("object"==typeof e){const{component:i,props:a,...l}=e;if(!i?.type)return s;const r=fe({...i,props:{...l,...a||{},...i.props||{}}}),o=e.detailEntity||e.entity,c=e.detailRow||e;return o&&!1!==e.detail?n`
            <span
                    class="sf-table-cell-detail-trigger inline-flex items-cross-center max-w-full"
                    role="button"
                    tabindex="0"
                    @click=${e=>{e.preventDefault(),e.stopPropagation(),t.context?.component?.openEntityDetail?.(o,c)}}
                    @keydown=${e=>{"Enter"!==e.key&&" "!==e.key||(e.preventDefault(),e.stopPropagation(),t.context?.component?.openEntityDetail?.(o,c))}}
            >
                ${r}
            </span>
        `:r}return e}function Se(e){if("boolean"==typeof e)return e;if("number"==typeof e)return 0!==e;const t=String(e??"").trim().toLowerCase();return!!["true","1","yes","y","on"].includes(t)||!["false","0","no","n","off"].includes(t)&&null}function Ce(e){const{state:t}=e.component;function i(i,a){if(!a||!i)return s;let l="actions"===a.key&&e.component?.getActionRowItems?e.component.getActionRowItems(i):i[a.key];if(a.component){const t=a.rowComponent||a.component;return null==l||Array.isArray(l)&&!l.length?"settings"!==a.key||l&&(!Array.isArray(l)||l.length)?fe(t):fe({type:"icon-button",props:{size:"1",type:"link",scheme:"on-surface",icon:"menu",ariaLabel:"Меню",value:"menu"}}):be(t,l,{context:e,row:i,column:a})}if(null==l)return s;if(me(e,a)){const e=he(l);if(e!==s)return n`<div class="flex min-w-0">${e}</div>`}if(Array.isArray(l))return"actions"===a.key&&(l=l.filter(e=>{const{actions:i}=t,n=i.find(t=>t.id===e.id);return n?.visible??!1})),n`
                <div class="flex items-cross-center gap-1/3">
                    ${l.map(t=>{const l=ve(t,{context:e,row:i,column:a});if(l!==s)return l;const r=e.component.getCellDisplayValue?.(t,a)??t;return n`
                            <div class="flex"><span
                                    class="sf-text-1 color-on-surface overflow-hidden whitespace-nowrap t-ellipsis">${r}</span>
                            </div>`})}
                </div>
            `;if("object"==typeof l){const t=ve(l,{context:e,row:i,column:a});if(t!==s)return t;const r=e.component.getCellDisplayValue?.(l,a)??"";return n`
                <div class="flex"><span class="sf-text-1 color-on-surface overflow-hidden whitespace-nowrap t-ellipsis">${r}</span>
                </div>`}return n`
            <div class="flex"><span
                    class="sf-text-1 color-on-surface overflow-hidden whitespace-nowrap t-ellipsis">${l}</span>
            </div>`}function a(){return e.component.getFieldCreateState?.()||{}}function l(){const t=a(),i=e.component.getSelectedFieldType?.()||null,l=t.settings||{},r=Boolean(t.selectedType&&String(l.label||"").trim()),o="edit"===t.mode,c=o&&e.component.canDeleteField?.(t.fieldKey),d=(u=i,Array.isArray(u?.settings)?u.settings.filter(e=>e?.key&&"label"!==e.key&&"options"!==e.key):[]);var u;return n`
            <div class="flex flex-col gap-1">
                <div class="flex items-cross-center gap-1/2">
                    <div class="flex items-cross-center gap-1/3">
                        <sf-icon icon="${i?.icon||"text_fields"}"></sf-icon>
                        <span class="sf-text-1 color-on-surface">${i?.label||t.selectedType}</span>
                    </div>
                </div>

                <sf-input
                        size="1"
                        type="bordered"
                        value=${l.label||""}
                        label="Field name"
                        placeholder="Field name"
                        name="sf_new_field_label"
                        @input=${t=>{e.component.updateFieldCreateSetting?.("label",re(t))}}
                ></sf-input>

                <sf-input
                        size="1"
                        type="bordered"
                        value=${l.key||""}
                        label="Field key"
                        placeholder="Field key"
                        name="sf_new_field_key"
                        ?disabled=${o}
                        @input=${t=>{o||e.component.updateFieldCreateSetting?.("key",re(t))}}
                ></sf-input>

                ${d.map(t=>function(t,i){const a=t?.key,l=t?.type||"text";return a?"checkbox"===l?n`
                <sf-checkbox
                        size="1"
                        label=${t.label||a}
                        ?checked=${Boolean(i[a])}
                        @change=${t=>{e.component.updateFieldCreateSetting?.(a,Boolean(t.target?.checked))}}
                ></sf-checkbox>
            `:"number"===l?n`
                <sf-input
                        size="1"
                        type="bordered"
                        input-type="number"
                        value=${i[a]??t.defaultValue??""}
                        label=${t.label||a}
                        placeholder=${t.label||a}
                        name=${`sf_field_setting_${a}`}
                        @input=${t=>{const i=re(t);e.component.updateFieldCreateSetting?.(a,""===i?"":Number(i))}}
                ></sf-input>
            `:n`
            <sf-input
                    size="1"
                    type="bordered"
                    value=${i[a]??t.defaultValue??""}
                    label=${t.label||a}
                    placeholder=${t.label||a}
                    name=${`sf_field_setting_${a}`}
                    @input=${t=>{e.component.updateFieldCreateSetting?.(a,re(t))}}
            ></sf-input>
        `:s}(t,l))}

                ${"dropdown"===t.selectedType?function(t){const i=Array.isArray(t.options)?t.options:[];return n`
            <div class="flex flex-col gap-1/3">
                <span class="sf-text-2 color-on-surface-muted">Dropdown options</span>
                ${i.map((t,s)=>n`
                    <div class="flex items-cross-start gap-1/3">
                        <sf-input
                                size="1"
                                type="bordered"
                                root-class="flex-1"
                                value=${t.label||t.title||t.name||""}
                                label="Option name"
                                placeholder="Option name"
                                @input=${i=>{const n=re(i);e.component.updateFieldCreateOption?.(s,{id:t.id||s+1,value:t.value||t.id||s+1,label:n,title:n,name:n},"field-create-option-input")}}
                        ></sf-input>
                        <sf-icon-button
                                size="1"
                                type="link"
                                scheme="on-surface"
                                icon="delete"
                                ?disabled=${i.length<=1}
                                @click=${()=>{e.component.removeFieldCreateOption?.(s)}}
                        ></sf-icon-button>
                    </div>
                `)}
                <sf-button
                        size="1"
                        type="link"
                        scheme="primary"
                        icon-left="add"
                        text="Добавить option"
                        @click=${()=>{e.component.addFieldCreateOption?.()}}
                ></sf-button>
            </div>
        `}(l):s}

                <div class="flex items-cross-center gap-1/2 m-top-1">
                    ${c?n`
                        <sf-icon-button
                                size="1"
                                type="outline"
                                scheme="on-surface"
                                icon="delete"
                                aria-label="Remove field"
                                style="margin-inline-end: auto;"
                                @click=${()=>{e.component.submitFieldDelete?.()}}
                        ></sf-icon-button>
                    `:s}
                    <div class="flex items-cross-center gap-1/2 m-inline-start-auto">
                        <sf-button
                                size="1"
                                type="tonal"
                                scheme="secondary"
                                text="Отмена"
                                @click=${()=>{e.component.closeFieldCreateModal?.()}}
                        ></sf-button>
                        <sf-button
                                size="1"
                                type="default"
                                scheme="primary"
                                text=${o?"Сохранить":"Создать"}
                                ?disabled=${!r}
                                @click=${()=>{e.component.submitFieldCreate?.()}}
                        ></sf-button>
                    </div>
                </div>
            </div>
        `}const r=(e.component.getDetailFields?.()||[]).some(t=>t?.edited||void 0!==e.component.getDetailTempFieldValue?.(t.key)),o=e.component.getPaginationData?.()||{},c=e.component.getPaginationPageSizesString?.(o.pageSizes)||e.pageSizes;return n`
        <section
                class="sf-table min-w-0 flex flex-col gap-1/3 flex-1 min-h-0 ${e.rootClass||""}"
                style=${e.rootStyle||s}
                aria-label=${e.ariaLabel||s}
        >
            ${function(e){const{state:t}=e.component,{searchActive:i,value:a}=t.search,l=e.component.getCurrentFilterTags(),r=e.component.getCurrentFilterValues(),o=e.component.hasUnsavedFilterDataChanges(),c=Object.entries(l||{}).filter(([,e])=>!1!==e?.active);return n`
        <div
                class="sf-table-toolbar flex${i?" gap-1/2":" items-cross-start"} content-main-between flex-none${i&&c.length?" flex-col-reverse":""}"
        >
            <div class="sf-table-toolbar-start flex items-cross-center gap-1/3 flex-wrap ${!c.length&&i?"hidden":""}">
                <div class="flex items-cross-center">
                    <sf-button
                            size="1"
                            type="default"
                            scheme="primary"
                            text=${e.filterText}
                            segment="start"
                            icon-left="filter_list"
                            @click=${t=>{e.component.openContextMenu(t,{type:"bottom",menu:"filter-settings"})}}
                    ></sf-button>
                    <sf-icon-button
                            size="1"
                            type="default"
                            scheme="primary"
                            ?disabled=${!c.length}
                            segment="end"
                            icon="bookmark_add"
                            @click=${t=>{e.component.openContextMenu(t,{type:"bottom",menu:"filter-favorites",parent:!0})}}
                    ></sf-icon-button>
                </div>
                ${c.map(([t,i])=>{const s=r?.[t]||{},a=Object.prototype.hasOwnProperty.call(r||{},t),l=Array.isArray(s.values)?s.values.length:i.count||"";return n`
                        <div class="sf-table-tags">
                            <sf-tag
                                    type="default"
                                    size="1"
                                    text='${i.label}'
                                    closable
                                    :key=${t}
                                    root-class="${a?"active":""}"
                                    @close="${()=>{e.component.removeFilterTag(t)}}"
                                    @click=${i=>{e.component.openContextMenu(i,{type:"bottom",menu:"tag-settings",fieldKey:t})}}
                                    count='${l}'
                            ></sf-tag>
                        </div>`})}
                ${c.length||o?n`
                    ${o?n`
                        <sf-button
                                size="1"
                                type="default"
                                scheme="primary"
                                text="Сохранить"
                                @click="${()=>e.component.saveCurrentFilterTemplateData()}"
                        ></sf-button>
                    `:s}
                    ${c.length?n`
                        <sf-button
                                size="1"
                                type="outline"
                                scheme="on-surface"
                                text=${e.clearText}
                                @click="${()=>e.component.removeFilterTag()}"
                        ></sf-button>
                    `:s}
                `:s}
            </div>

            <div class="sf-table-toolbar-end flex items-cross-center gap-1/3 flex-auto">
                <sf-input
                        size="1"
                        root-class="sf-search-input transition-layout m-inline-start-auto${i?" flex-1":""}"
                        type="bordered"
                        value="${a}"
                        placeholder=${e.searchPlaceholder}
                        name="sf_table_search"
                        @input=${t=>{e.component.searchChange({value:re(t,a)})}}
                        @keydown=${t=>{e.component.handleSearchKeyDown(t)}}
                        @keyup=${t=>{e.component.handleSearchKeyUp(t)}}
                        @focusout=${t=>{e.component.updateSearchState({searchActive:t.currentTarget.contains(t.relatedTarget)},!1)}}
                        @focusin=${()=>{e.component.updateSearchState({searchActive:!0},!1)}}
                        hint-icon="search"
                >
          <span slot="right">
                <sf-icon-button
                        size="1"
                        type="link"
                        scheme="on-surface"
                        icon=${a.length?"close":"search"}
                        @click=${t=>{if(t.preventDefault(),t.stopPropagation(),!a.length)return!1;e.component.updateSearchState({value:""})}}
                ></sf-icon-button>
            
          </span>
                </sf-input>

                <div class="flex items-cross-center">
                    <sf-button
                            size="1"
                            type="outline"
                            scheme="on-surface"
                            text=${e.createText}
                            segment="start"
                    ></sf-button>
                    <sf-icon-button
                            size="1"
                            type="outline"
                            scheme="primary"
                            segment="end"
                            icon="keyboard_arrow_down"
                    ></sf-icon-button>
                </div>

                <sf-icon-button
                        size="1"
                        type="outline"
                        scheme="primary"
                        icon="settings"
                ></sf-icon-button>
            </div>
        </div>
    `}(e)}

            <div class="table-wrap min-w-0 max-w-full flex flex-col flex-1 min-h-0">
                <div class="min-h-0 min-w-0 overflow-auto flex-1 relative m-bottom-2">
                    <table :ref=${e.component.refs.table}
                           class="table border-separate border-spacing-0 w-max table-fixed transition"
                           style="width: max-content; min-width: 100%; max-width: none;">
                        ${function(e){const t=e.component?.getColumns?.()||[];return t.length?n`
        <colgroup>
            ${t.map(e=>{const t=oe(e.colWidth??e.width??e.size),i=oe(e.minWidth),a=oe(e.maxWidth),l=e.system&&t,r=l&&!i?t:i,o=l&&!a?t:a,c=[t?`width: ${t}`:"",r?`min-width: ${r}`:"",o?`max-width: ${o}`:""].filter(Boolean).join("; ");return ne(`col:${e.key}`,n`
                    <col
                            data-key=${e.key||s}
                            style=${c||s}
                    />
                `)})}
            <col data-key=${le} class="sf-table-fill-col"/>
        </colgroup>
    `:s}(e)}
                        ${function(e){if(e.component?.hasSlotContent?.("head"))return e.component.getSlotContent("head");const t=e.component?.getColumns?.()||[];return n`
        <thead class="sticky top-0 z-5">
        <tr>
            ${t.map((e,i)=>{const a=e.headerComponent||(e.system?e.component:null),l=a?n`${SF.litHtml(a.type,a.props)}`:n`<span class="overflow-hidden whitespace-nowrap t-ellipsis"> ${e.label}</span>`,r=!e.system&&i!==t.length-1;return ne(`head:${e.key}`,n`
                            <th
                                    class="relative"
                                    data-key="${e.key}"
                                    data-label="${e.label||e.key||""}"
                                    style=${ce(e)||s}
                            >
                                ${r?n`
                                            <div
                                                    class="sidebar-resizer flex items-cross-center w-full h-full select-none"
                                                    role="separator"
                                                    aria-orientation="vertical"
                                                    aria-label="Resize sidebar">
                                                ${l}
                                                <sf-icon-button size="1/3"
                                                                radius="default"
                                                                root-class="sidebar-resizer-button absolute top-1/2 -translate-y-half translate-x-half inline-end-0 z-1 cursor-col-resize hidden"
                                                                id="column_resizer_${e.key}"
                                                                aria-label="Resize sidebar"
                                                                type="link"
                                                                scheme="on-surface"
                                                                icon="drag_handle"
                                                ></sf-icon-button>
                                            </div>
                                        `:l}
                            </th>
                        `)})}
            <th
                    class="sf-table-fill-cell"
                    data-key=${le}
                    aria-hidden="true"
            ></th>
        </tr>
        </thead>
    `}(e)}
                        ${function(){if(e.component?.hasSlotContent?.("body"))return n`
                <tbody>
                ${e.component.getSlotContent("body")}
                </tbody>`;const{state:t}=e.component,a=e.component?.getColumns?.()||[],{rows:l=[]}=t.data||{};return n`
            <tbody>
            ${l.map(e=>ne(`row:${e.id??e.value??l.indexOf(e)}`,n`
                <tr>
                    ${a.map(t=>ne(`cell:${e.id??e.value??l.indexOf(e)}:${t.key}`,n`
                                <td class="overflow-hidden"
                                    data-key="${t.key}"
                                    data-item="${t.key}_${e.id}"
                                    style=${ce(t)||s}>
                                    <div class="sf-table-cell-content min-w-0 w-full">
                                        ${i(e,t)}
                                    </div>
                                </td>
                            `))}
                    <td
                            class="sf-table-fill-cell"
                            data-key=${le}
                            aria-hidden="true"
                    ></td>
                </tr>
            `))}
            </tbody>`}()}
                    </table>
                </div>

                ${e.pagin?n`
                            <sf-pagination
                                    :ref=${e.component.refs.pagination}
                                    current=${String(o.current||1)}
                                    total=${String(o.total??e.paginationTotal)}
                                    bottom="true"
                                    show-total='false'
                                    show-action-for-all
                                    page-size=${String(o.pageSize||e.paginationPageSize)}
                                    page-sizes=${c}
                                    show-page-size
                                    top-class="content-main-center"
                                    main-class="items-cross-center content-main-between"
                                    bottom-class="items-cross-center gap-2"
                                    @sf-page-change=${t=>{e.component.handlePaginationPageChange(t)}}
                                    @sf-page-size-change=${t=>{e.component.handlePaginationPageSizeChange(t)}}
                                    @sf-show-more=${t=>{e.component.handlePaginationShowMore(t)}}
                            ></sf-pagination>`:s}
            </div>
        </section>
        ${t.contextMenu?.open?e.component.renderContextMenu(e.state.contextMenu):s}
        <sf-modal :ref=${e.component.refs.detailModal}
                  header-class="p-x-5" ?open=${t.modalOpen} content-class="flex-1 min-h-0"
                  root-class="sf-modal-panel min-h-0"
                  width="var(--sf-h0)" id="user_profile"
                  position="right"
                  @modal:after-close=${()=>e.component.closeFieldCreateModal()}
                  title=${function(){const t=e.component.state.detail||{},i=t.entity||"task",n=e.component.getDetailRow?.(),s=n?.id||n?.value||"";return t.title?t.title:"user"===i?n?.fullName||n?.title||n?.name||(s?`Пользователь #${s}`:"Пользователь"):n?.title?.name||n?.title||(s?`Задача #${s}`:"Задача")}()}
                  .contentTemplate=${n`
                      <div class="flex flex-col flex-1 h-full min-h-0">
                          <div class="sf-admin-panel-head p-x-5 p-y-1/2 flex items-cross-center content-main-between flex-none">
                              <span class="sf-h-6">${function(){const t=e.component.state.detail||{},i=t.entity||"task";return t.heading?t.heading:"user"===i?"Пользователь":"task"===i?"Задача":"Карточка"}()}</span>
                              <div class="sf-admin-panel-head-buttons flex items-cross-center gap-1/2 m-0">
                                  ${r?n`
                                              <sf-button
                                                      type=${"link"}
                                                      scheme=${"on-surface"}
                                                      @click=${()=>{e.component.cancelDetailEditedFields()}}
                                                      text=${"Отменить"}></sf-button>`:s}
                                  <sf-button
                                          type=${r?"default":"link"}
                                          scheme=${r?"primary":"on-surface"}
                                          @click=${()=>{r?e.component.saveDetailEditedFields():e.component.setAllDetailFieldsEdited?.(!0)}}
                                          text=${r?"Сохранить":"Редактировать"}></sf-button>
                              </div>
                          </div>
                          <div class="sf-admin-panel-main flex-1 min-h-0 overflow-auto p-y-1/2">
                              ${function(){const t=e.component.state.detail||{},i=e.component.getDetailRow?.()||t.row,a=e.component.getDetailFields?.()||[];return t.loading?n`
                <div class="flex flex-col gap-1">
                    <div class="sf-text-2 color-on-surface-variant">
                        <div class="flex flex-col gap-5 p-x-5">
                            <sf-skeleton size="1" count="2" width="20%,60%"></sf-skeleton>
                            <sf-skeleton size="1" count="2" width="20%,60%"></sf-skeleton>
                            <sf-skeleton size="1" count="2" width="20%,60%"></sf-skeleton>
                            <sf-skeleton size="1" count="2" width="20%,60%"></sf-skeleton>
                            <sf-skeleton size="1" count="2" width="20%,60%"></sf-skeleton>
                            <sf-skeleton size="1" count="2" width="20%,60%"></sf-skeleton>
                            <sf-skeleton size="1" count="2" width="20%,60%"></sf-skeleton>
                            <sf-skeleton size="1" count="2" width="20%,60%"></sf-skeleton>
                            <sf-skeleton size="1" count="2" width="20%,60%"></sf-skeleton>
                        </div>
                    </div>
                </div>
            `:i&&a.length?n`
            <div class="sf-table-detail-fields flex flex-col" :ref=${e.component.refs.fieldList}
                 data-detail-field-list>
                ${a.map(t=>{const a=!1!==t.editor?.enabled,l=r&&a;return n`
                        <div
                                class="sf-table-detail-field flex gap-1 relative items-cross-start p-y-1/2 p-x-5 ${t.edited?"edited":""}"
                                data-detail-field-key=${t.key||s}
                                data-detail-field-draggable=${l?"true":"false"}
                                data-edited=${t.edited?"true":"false"}>
                            ${l?n`
                                        <sf-icon-button
                                                id="${t.id}_move"
                                                type="link"
                                                size="1/2"
                                                data-move
                                                scheme="on-surface"
                                                aria-label="Set order"
                                                icon="drag_indicator"
                                                root-class="cursor-move absolute"
                                        ></sf-icon-button>`:s}
                            <div class="flex flex-col gap-1/4 flex-1 max-w-full min-w-0">
                                <div class="sf-text-1 color-on-surface-muted">
                                    ${t.label||t.key}
                                </div>
                                <div class="sf-table-detail-value m-0 grid">
                                    ${function(t,i){if(!t||!i?.key)return s;const a=e.component.getDetailDisplayValue?.(t,i)??t[i.key],l=e.component.getFieldType?.(i);if(i.edited&&!1!==i.editor?.enabled)return e.component.setEditorData(i,a);if(null==a)return n`<span class="sf-text-2 color-on-surface-variant">-</span>`;if(Array.isArray(a))return n`
                <div class="flex flex-col gap-1/3">
                    ${a.map(n=>ve(n,{context:e,row:t,field:i}))}
                </div>
            `;const r=e.component.getFieldDetailRenderer?.(i)||i.detail?.renderer||i.renderer,o=i.detail?.component;if("checkbox"===l||"boolean"===i.dataType){const e=[...Array.isArray(i.options)?i.options:[],...Array.isArray(i.schema?.options)?i.schema.options:[],...Array.isArray(i.settings?.options)?i.settings.options:[],...Array.isArray(i.schema?.settings?.options)?i.schema.settings.options:[],...Array.isArray(i.editor?.options)?i.editor.options:[],...Array.isArray(i.filter?.options)?i.filter.options:[]],t=Se(a),s=e.find(e=>Se(e?.value??e?.id??e?.code)===t);return n`<span class="sf-text-1 color-on-surface">${s?.label||s?.title||s?.name||s?.text||(a?"Да":"Нет")}</span>`}if(me(e,i)){const e=he(a);if(e!==s)return e}if(o?.type&&"text"!==r)return be(o,a,{context:e,row:t,field:i});if("object"==typeof a){if("text"!==r){const n=ve(a,{context:e,row:t,field:i});if(n!==s)return n}const l=e.component.getCellDisplayValue?.(a,i)||a.label||a.title||a.name||a.value||"",o=e.component.getDetailTextDisplayValue?.(i,l)??l,c=e.component.getDetailHtmlDisplayValue?.(i,l);return null!=c?n`
                    <div class="sf-table-detail-rich-text sf-text-1 color-on-surface">
                        ${ae(c)}
                    </div>
                `:n`
                <span class="sf-text-1 color-on-surface">
                    ${o}
                </span>
            `}const c=e.component.getDetailTextDisplayValue?.(i,a)??a,d=e.component.getDetailHtmlDisplayValue?.(i,a);return null!=d?n`
                <div class="sf-table-detail-rich-text sf-text-1 color-on-surface">
                    ${ae(d)}
                </div>
            `:n`<span class="sf-text-1 color-on-surface">${c}</span>`}(i,t)}
                                </div>
                            </div>
                            ${a&&t.edited?n`
                                <div class="flex-none">
                                    <sf-icon-button
                                            size="1"
                                            type="link"
                                            data-edit
                                            scheme="on-surface"
                                            @click=${async()=>{e.component.openFieldSettingsModal?.(t)}}
                                            icon="settings"
                                    ></sf-icon-button>
                                </div>`:s}
                            ${a&&!t.edited?n`
                                <div class="flex-none">
                                    <sf-icon-button
                                            size="1"
                                            type="link"
                                            data-edit
                                            scheme="on-surface"
                                            @click=${async()=>{await e.component.toggleDetailFieldEdited(t)}}
                                            icon="edit"
                                    ></sf-icon-button>
                                </div>`:s}
                        </div>
                    `})}
            </div>
        `:n`
                <div class="sf-text-2 color-on-surface-variant">
                    Нет данных
                </div>
            `}()}
                          </div>
                          <div class="sf-admin-panel-bottom flex items-cross-center content-main-between flex-none p-y-1/2 p-x-5">
                              <sf-button
                                      type="link"
                                      scheme="primary"
                                      text="Добавить элемент"
                                      @click=${()=>{e.component.emitFieldCreateRequest?.()}}></sf-button>
                              <sf-button
                                      type="tonal"
                                      scheme="secondary"
                                      text="Удалить раздел"></sf-button>
                          </div>
                      </div>
                  `}>
        </sf-modal>
        ${function(){const t=a();return n`
            <sf-modal
                    :ref=${e.component.refs.fieldCreateModal}
                    ?open=${Boolean(t.open)}
                    width="520px"
                    id="sf_table_field_create"
                    title=${"edit"===t.mode?"Редактирование поля":"settings"===t.step?"Настройки поля":"Выбор типа поля"}
                    .headerTemplate=${"settings"===t.step?n`
                        <div class="flex items-cross-center gap-1/2"> ${"edit"!==t.mode?n`
                            <sf-icon-button
                                    size="1"
                                    type="link"
                                    scheme="on-surface"
                                    icon="arrow_back"
                                    @click=${()=>{e.component.set?.(e=>({fieldCreate:{...e.fieldCreate||{},step:"type"}}),"field-create-back")}}
                            ></sf-icon-button>
                        `:s}
                            <h2 class="title-3 m-0">Настройки поля</h2>
                        </div>
                    `:null}
                    .contentTemplate=${n`
                        <div class="p-2 flex flex-col gap-1">
                            ${"settings"===t.step?l():function(){const t=(e.component.getFieldTypes?.()||[]).map(e=>({...e,type:"icon",text:e.label||e.id,value:e.id,icon:e.icon||"text_fields"}));return n`
            <div class="flex flex-col gap-1">
                <sf-list
                        search
                        selectable
                        max-items="8"
                        gap="1/3"
                        search-placeholder="&#1055;&#1086;&#1080;&#1089;&#1082; &#1090;&#1080;&#1087;&#1072;"
                        value=${a().selectedType||""}
                        .items=${t}
                        @sf-list:change=${t=>{e.component.selectFieldCreateType?.(t.detail?.value)}}
                        @change=${e=>e.stopPropagation()}
                ></sf-list>
            </div>
        `}()}
                        </div>
                    `}>
            </sf-modal>
        `}()}
    `}const{entries:xe,setPrototypeOf:Te,isFrozen:ke,getPrototypeOf:Ae,getOwnPropertyDescriptor:Fe}=Object;let{freeze:we,seal:$e,create:De}=Object,{apply:Ee,construct:_e}="undefined"!=typeof Reflect&&Reflect;we||(we=function(e){return e}),$e||($e=function(e){return e}),Ee||(Ee=function(e,t){for(var i=arguments.length,n=new Array(i>2?i-2:0),s=2;s<i;s++)n[s-2]=arguments[s];return e.apply(t,n)}),_e||(_e=function(e){for(var t=arguments.length,i=new Array(t>1?t-1:0),n=1;n<t;n++)i[n-1]=arguments[n];return new e(...i)});const ze=We(Array.prototype.forEach),Me=We(Array.prototype.lastIndexOf),Re=We(Array.prototype.pop),Le=We(Array.prototype.push),Oe=We(Array.prototype.splice),Pe=We(String.prototype.toLowerCase),Ne=We(String.prototype.toString),Ie=We(String.prototype.match),Be=We(String.prototype.replace),Ve=We(String.prototype.indexOf),He=We(String.prototype.trim),Ue=We(Object.prototype.hasOwnProperty),Ke=We(RegExp.prototype.test),je=(qe=TypeError,function(){for(var e=arguments.length,t=new Array(e),i=0;i<e;i++)t[i]=arguments[i];return _e(qe,t)});var qe;function We(e){return function(t){t instanceof RegExp&&(t.lastIndex=0);for(var i=arguments.length,n=new Array(i>1?i-1:0),s=1;s<i;s++)n[s-1]=arguments[s];return Ee(e,t,n)}}function Ge(e,t){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:Pe;Te&&Te(e,null);let n=t.length;for(;n--;){let s=t[n];if("string"==typeof s){const e=i(s);e!==s&&(ke(t)||(t[n]=e),s=e)}e[s]=!0}return e}function Ye(e){for(let t=0;t<e.length;t++){Ue(e,t)||(e[t]=null)}return e}function Xe(e){const t=De(null);for(const[i,n]of xe(e)){Ue(e,i)&&(Array.isArray(n)?t[i]=Ye(n):n&&"object"==typeof n&&n.constructor===Object?t[i]=Xe(n):t[i]=n)}return t}function Ze(e,t){for(;null!==e;){const i=Fe(e,t);if(i){if(i.get)return We(i.get);if("function"==typeof i.value)return We(i.value)}e=Ae(e)}return function(){return null}}const Je=we(["a","abbr","acronym","address","area","article","aside","audio","b","bdi","bdo","big","blink","blockquote","body","br","button","canvas","caption","center","cite","code","col","colgroup","content","data","datalist","dd","decorator","del","details","dfn","dialog","dir","div","dl","dt","element","em","fieldset","figcaption","figure","font","footer","form","h1","h2","h3","h4","h5","h6","head","header","hgroup","hr","html","i","img","input","ins","kbd","label","legend","li","main","map","mark","marquee","menu","menuitem","meter","nav","nobr","ol","optgroup","option","output","p","picture","pre","progress","q","rp","rt","ruby","s","samp","search","section","select","shadow","slot","small","source","spacer","span","strike","strong","style","sub","summary","sup","table","tbody","td","template","textarea","tfoot","th","thead","time","tr","track","tt","u","ul","var","video","wbr"]),Qe=we(["svg","a","altglyph","altglyphdef","altglyphitem","animatecolor","animatemotion","animatetransform","circle","clippath","defs","desc","ellipse","enterkeyhint","exportparts","filter","font","g","glyph","glyphref","hkern","image","inputmode","line","lineargradient","marker","mask","metadata","mpath","part","path","pattern","polygon","polyline","radialgradient","rect","slot","stop","style","switch","symbol","text","textpath","title","tref","tspan","view","vkern"]),et=we(["feBlend","feColorMatrix","feComponentTransfer","feComposite","feConvolveMatrix","feDiffuseLighting","feDisplacementMap","feDistantLight","feDropShadow","feFlood","feFuncA","feFuncB","feFuncG","feFuncR","feGaussianBlur","feImage","feMerge","feMergeNode","feMorphology","feOffset","fePointLight","feSpecularLighting","feSpotLight","feTile","feTurbulence"]),tt=we(["animate","color-profile","cursor","discard","font-face","font-face-format","font-face-name","font-face-src","font-face-uri","foreignobject","hatch","hatchpath","mesh","meshgradient","meshpatch","meshrow","missing-glyph","script","set","solidcolor","unknown","use"]),it=we(["math","menclose","merror","mfenced","mfrac","mglyph","mi","mlabeledtr","mmultiscripts","mn","mo","mover","mpadded","mphantom","mroot","mrow","ms","mspace","msqrt","mstyle","msub","msup","msubsup","mtable","mtd","mtext","mtr","munder","munderover","mprescripts"]),nt=we(["maction","maligngroup","malignmark","mlongdiv","mscarries","mscarry","msgroup","mstack","msline","msrow","semantics","annotation","annotation-xml","mprescripts","none"]),st=we(["#text"]),at=we(["accept","action","align","alt","autocapitalize","autocomplete","autopictureinpicture","autoplay","background","bgcolor","border","capture","cellpadding","cellspacing","checked","cite","class","clear","color","cols","colspan","controls","controlslist","coords","crossorigin","datetime","decoding","default","dir","disabled","disablepictureinpicture","disableremoteplayback","download","draggable","enctype","enterkeyhint","exportparts","face","for","headers","height","hidden","high","href","hreflang","id","inert","inputmode","integrity","ismap","kind","label","lang","list","loading","loop","low","max","maxlength","media","method","min","minlength","multiple","muted","name","nonce","noshade","novalidate","nowrap","open","optimum","part","pattern","placeholder","playsinline","popover","popovertarget","popovertargetaction","poster","preload","pubdate","radiogroup","readonly","rel","required","rev","reversed","role","rows","rowspan","spellcheck","scope","selected","shape","size","sizes","slot","span","srclang","start","src","srcset","step","style","summary","tabindex","title","translate","type","usemap","valign","value","width","wrap","xmlns","slot"]),lt=we(["accent-height","accumulate","additive","alignment-baseline","amplitude","ascent","attributename","attributetype","azimuth","basefrequency","baseline-shift","begin","bias","by","class","clip","clippathunits","clip-path","clip-rule","color","color-interpolation","color-interpolation-filters","color-profile","color-rendering","cx","cy","d","dx","dy","diffuseconstant","direction","display","divisor","dur","edgemode","elevation","end","exponent","fill","fill-opacity","fill-rule","filter","filterunits","flood-color","flood-opacity","font-family","font-size","font-size-adjust","font-stretch","font-style","font-variant","font-weight","fx","fy","g1","g2","glyph-name","glyphref","gradientunits","gradienttransform","height","href","id","image-rendering","in","in2","intercept","k","k1","k2","k3","k4","kerning","keypoints","keysplines","keytimes","lang","lengthadjust","letter-spacing","kernelmatrix","kernelunitlength","lighting-color","local","marker-end","marker-mid","marker-start","markerheight","markerunits","markerwidth","maskcontentunits","maskunits","max","mask","media","method","mode","min","name","numoctaves","offset","operator","opacity","order","orient","orientation","origin","overflow","paint-order","path","pathlength","patterncontentunits","patterntransform","patternunits","points","preservealpha","preserveaspectratio","primitiveunits","r","rx","ry","radius","refx","refy","repeatcount","repeatdur","restart","result","rotate","scale","seed","shape-rendering","slope","specularconstant","specularexponent","spreadmethod","startoffset","stddeviation","stitchtiles","stop-color","stop-opacity","stroke-dasharray","stroke-dashoffset","stroke-linecap","stroke-linejoin","stroke-miterlimit","stroke-opacity","stroke","stroke-width","style","surfacescale","systemlanguage","tabindex","tablevalues","targetx","targety","transform","transform-origin","text-anchor","text-decoration","text-rendering","textlength","type","u1","u2","unicode","values","viewbox","visibility","version","vert-adv-y","vert-origin-x","vert-origin-y","width","word-spacing","wrap","writing-mode","xchannelselector","ychannelselector","x","x1","x2","xmlns","y","y1","y2","z","zoomandpan"]),rt=we(["accent","accentunder","align","bevelled","close","columnsalign","columnlines","columnspan","denomalign","depth","dir","display","displaystyle","encoding","fence","frame","height","href","id","largeop","length","linethickness","lspace","lquote","mathbackground","mathcolor","mathsize","mathvariant","maxsize","minsize","movablelimits","notation","numalign","open","rowalign","rowlines","rowspacing","rowspan","rspace","rquote","scriptlevel","scriptminsize","scriptsizemultiplier","selection","separator","separators","stretchy","subscriptshift","supscriptshift","symmetric","voffset","width","xmlns"]),ot=we(["xlink:href","xml:id","xlink:title","xml:space","xmlns:xlink"]),ct=$e(/\{\{[\w\W]*|[\w\W]*\}\}/gm),dt=$e(/<%[\w\W]*|[\w\W]*%>/gm),ut=$e(/\$\{[\w\W]*/gm),pt=$e(/^data-[\-\w.\u00B7-\uFFFF]+$/),mt=$e(/^aria-[\-\w]+$/),ht=$e(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i),ft=$e(/^(?:\w+script|data):/i),gt=$e(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g),yt=$e(/^html$/i),bt=$e(/^[a-z][.\w]*(-[.\w]+)+$/i);var vt=Object.freeze({__proto__:null,ARIA_ATTR:mt,ATTR_WHITESPACE:gt,CUSTOM_ELEMENT:bt,DATA_ATTR:pt,DOCTYPE_NAME:yt,ERB_EXPR:dt,IS_ALLOWED_URI:ht,IS_SCRIPT_OR_DATA:ft,MUSTACHE_EXPR:ct,TMPLIT_EXPR:ut});const St=1,Ct=3,xt=7,Tt=8,kt=9,At=function(){return"undefined"==typeof window?null:window};var Ft=function e(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:At();const i=t=>e(t);if(i.version="3.2.7",i.removed=[],!t||!t.document||t.document.nodeType!==kt||!t.Element)return i.isSupported=!1,i;let{document:n}=t;const s=n,a=s.currentScript,{DocumentFragment:l,HTMLTemplateElement:r,Node:o,Element:c,NodeFilter:d,NamedNodeMap:u=t.NamedNodeMap||t.MozNamedAttrMap,HTMLFormElement:p,DOMParser:m,trustedTypes:h}=t,f=c.prototype,g=Ze(f,"cloneNode"),y=Ze(f,"remove"),b=Ze(f,"nextSibling"),v=Ze(f,"childNodes"),S=Ze(f,"parentNode");if("function"==typeof r){const e=n.createElement("template");e.content&&e.content.ownerDocument&&(n=e.content.ownerDocument)}let C,x="";const{implementation:T,createNodeIterator:k,createDocumentFragment:A,getElementsByTagName:F}=n,{importNode:w}=s;let $={afterSanitizeAttributes:[],afterSanitizeElements:[],afterSanitizeShadowDOM:[],beforeSanitizeAttributes:[],beforeSanitizeElements:[],beforeSanitizeShadowDOM:[],uponSanitizeAttribute:[],uponSanitizeElement:[],uponSanitizeShadowNode:[]};i.isSupported="function"==typeof xe&&"function"==typeof S&&T&&void 0!==T.createHTMLDocument;const{MUSTACHE_EXPR:D,ERB_EXPR:E,TMPLIT_EXPR:_,DATA_ATTR:z,ARIA_ATTR:M,IS_SCRIPT_OR_DATA:R,ATTR_WHITESPACE:L,CUSTOM_ELEMENT:O}=vt;let{IS_ALLOWED_URI:P}=vt,N=null;const I=Ge({},[...Je,...Qe,...et,...it,...st]);let B=null;const V=Ge({},[...at,...lt,...rt,...ot]);let H=Object.seal(De(null,{tagNameCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},attributeNameCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},allowCustomizedBuiltInElements:{writable:!0,configurable:!1,enumerable:!0,value:!1}})),U=null,K=null,j=!0,q=!0,W=!1,G=!0,Y=!1,X=!0,Z=!1,J=!1,Q=!1,ee=!1,te=!1,ie=!1,ne=!0,se=!1,ae=!0,le=!1,re={},oe=null;const ce=Ge({},["annotation-xml","audio","colgroup","desc","foreignobject","head","iframe","math","mi","mn","mo","ms","mtext","noembed","noframes","noscript","plaintext","script","style","svg","template","thead","title","video","xmp"]);let de=null;const ue=Ge({},["audio","video","img","source","image","track"]);let pe=null;const me=Ge({},["alt","class","for","id","label","name","pattern","placeholder","role","summary","title","value","style","xmlns"]),he="http://www.w3.org/1998/Math/MathML",fe="http://www.w3.org/2000/svg",ge="http://www.w3.org/1999/xhtml";let ye=ge,be=!1,ve=null;const Se=Ge({},[he,fe,ge],Ne);let Ce=Ge({},["mi","mo","mn","ms","mtext"]),Te=Ge({},["annotation-xml"]);const ke=Ge({},["title","style","font","a","script"]);let Ae=null;const Fe=["application/xhtml+xml","text/html"];let $e=null,Ee=null;const _e=n.createElement("form"),qe=function(e){return e instanceof RegExp||e instanceof Function},We=function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};if(!Ee||Ee!==e){if(e&&"object"==typeof e||(e={}),e=Xe(e),Ae=-1===Fe.indexOf(e.PARSER_MEDIA_TYPE)?"text/html":e.PARSER_MEDIA_TYPE,$e="application/xhtml+xml"===Ae?Ne:Pe,N=Ue(e,"ALLOWED_TAGS")?Ge({},e.ALLOWED_TAGS,$e):I,B=Ue(e,"ALLOWED_ATTR")?Ge({},e.ALLOWED_ATTR,$e):V,ve=Ue(e,"ALLOWED_NAMESPACES")?Ge({},e.ALLOWED_NAMESPACES,Ne):Se,pe=Ue(e,"ADD_URI_SAFE_ATTR")?Ge(Xe(me),e.ADD_URI_SAFE_ATTR,$e):me,de=Ue(e,"ADD_DATA_URI_TAGS")?Ge(Xe(ue),e.ADD_DATA_URI_TAGS,$e):ue,oe=Ue(e,"FORBID_CONTENTS")?Ge({},e.FORBID_CONTENTS,$e):ce,U=Ue(e,"FORBID_TAGS")?Ge({},e.FORBID_TAGS,$e):Xe({}),K=Ue(e,"FORBID_ATTR")?Ge({},e.FORBID_ATTR,$e):Xe({}),re=!!Ue(e,"USE_PROFILES")&&e.USE_PROFILES,j=!1!==e.ALLOW_ARIA_ATTR,q=!1!==e.ALLOW_DATA_ATTR,W=e.ALLOW_UNKNOWN_PROTOCOLS||!1,G=!1!==e.ALLOW_SELF_CLOSE_IN_ATTR,Y=e.SAFE_FOR_TEMPLATES||!1,X=!1!==e.SAFE_FOR_XML,Z=e.WHOLE_DOCUMENT||!1,ee=e.RETURN_DOM||!1,te=e.RETURN_DOM_FRAGMENT||!1,ie=e.RETURN_TRUSTED_TYPE||!1,Q=e.FORCE_BODY||!1,ne=!1!==e.SANITIZE_DOM,se=e.SANITIZE_NAMED_PROPS||!1,ae=!1!==e.KEEP_CONTENT,le=e.IN_PLACE||!1,P=e.ALLOWED_URI_REGEXP||ht,ye=e.NAMESPACE||ge,Ce=e.MATHML_TEXT_INTEGRATION_POINTS||Ce,Te=e.HTML_INTEGRATION_POINTS||Te,H=e.CUSTOM_ELEMENT_HANDLING||{},e.CUSTOM_ELEMENT_HANDLING&&qe(e.CUSTOM_ELEMENT_HANDLING.tagNameCheck)&&(H.tagNameCheck=e.CUSTOM_ELEMENT_HANDLING.tagNameCheck),e.CUSTOM_ELEMENT_HANDLING&&qe(e.CUSTOM_ELEMENT_HANDLING.attributeNameCheck)&&(H.attributeNameCheck=e.CUSTOM_ELEMENT_HANDLING.attributeNameCheck),e.CUSTOM_ELEMENT_HANDLING&&"boolean"==typeof e.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements&&(H.allowCustomizedBuiltInElements=e.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements),Y&&(q=!1),te&&(ee=!0),re&&(N=Ge({},st),B=[],!0===re.html&&(Ge(N,Je),Ge(B,at)),!0===re.svg&&(Ge(N,Qe),Ge(B,lt),Ge(B,ot)),!0===re.svgFilters&&(Ge(N,et),Ge(B,lt),Ge(B,ot)),!0===re.mathMl&&(Ge(N,it),Ge(B,rt),Ge(B,ot))),e.ADD_TAGS&&(N===I&&(N=Xe(N)),Ge(N,e.ADD_TAGS,$e)),e.ADD_ATTR&&(B===V&&(B=Xe(B)),Ge(B,e.ADD_ATTR,$e)),e.ADD_URI_SAFE_ATTR&&Ge(pe,e.ADD_URI_SAFE_ATTR,$e),e.FORBID_CONTENTS&&(oe===ce&&(oe=Xe(oe)),Ge(oe,e.FORBID_CONTENTS,$e)),ae&&(N["#text"]=!0),Z&&Ge(N,["html","head","body"]),N.table&&(Ge(N,["tbody"]),delete U.tbody),e.TRUSTED_TYPES_POLICY){if("function"!=typeof e.TRUSTED_TYPES_POLICY.createHTML)throw je('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');if("function"!=typeof e.TRUSTED_TYPES_POLICY.createScriptURL)throw je('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');C=e.TRUSTED_TYPES_POLICY,x=C.createHTML("")}else void 0===C&&(C=function(e,t){if("object"!=typeof e||"function"!=typeof e.createPolicy)return null;let i=null;const n="data-tt-policy-suffix";t&&t.hasAttribute(n)&&(i=t.getAttribute(n));const s="dompurify"+(i?"#"+i:"");try{return e.createPolicy(s,{createHTML:e=>e,createScriptURL:e=>e})}catch(e){return console.warn("TrustedTypes policy "+s+" could not be created."),null}}(h,a)),null!==C&&"string"==typeof x&&(x=C.createHTML(""));we&&we(e),Ee=e}},Ye=Ge({},[...Qe,...et,...tt]),ct=Ge({},[...it,...nt]),dt=function(e){Le(i.removed,{element:e});try{S(e).removeChild(e)}catch(t){y(e)}},ut=function(e,t){try{Le(i.removed,{attribute:t.getAttributeNode(e),from:t})}catch(e){Le(i.removed,{attribute:null,from:t})}if(t.removeAttribute(e),"is"===e)if(ee||te)try{dt(t)}catch(e){}else try{t.setAttribute(e,"")}catch(e){}},pt=function(e){let t=null,i=null;if(Q)e="<remove></remove>"+e;else{const t=Ie(e,/^[\r\n\t ]+/);i=t&&t[0]}"application/xhtml+xml"===Ae&&ye===ge&&(e='<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>'+e+"</body></html>");const s=C?C.createHTML(e):e;if(ye===ge)try{t=(new m).parseFromString(s,Ae)}catch(e){}if(!t||!t.documentElement){t=T.createDocument(ye,"template",null);try{t.documentElement.innerHTML=be?x:s}catch(e){}}const a=t.body||t.documentElement;return e&&i&&a.insertBefore(n.createTextNode(i),a.childNodes[0]||null),ye===ge?F.call(t,Z?"html":"body")[0]:Z?t.documentElement:a},mt=function(e){return k.call(e.ownerDocument||e,e,d.SHOW_ELEMENT|d.SHOW_COMMENT|d.SHOW_TEXT|d.SHOW_PROCESSING_INSTRUCTION|d.SHOW_CDATA_SECTION,null)},ft=function(e){return e instanceof p&&("string"!=typeof e.nodeName||"string"!=typeof e.textContent||"function"!=typeof e.removeChild||!(e.attributes instanceof u)||"function"!=typeof e.removeAttribute||"function"!=typeof e.setAttribute||"string"!=typeof e.namespaceURI||"function"!=typeof e.insertBefore||"function"!=typeof e.hasChildNodes)},gt=function(e){return"function"==typeof o&&e instanceof o};function bt(e,t,n){ze(e,e=>{e.call(i,t,n,Ee)})}const Ft=function(e){let t=null;if(bt($.beforeSanitizeElements,e,null),ft(e))return dt(e),!0;const n=$e(e.nodeName);if(bt($.uponSanitizeElement,e,{tagName:n,allowedTags:N}),X&&e.hasChildNodes()&&!gt(e.firstElementChild)&&Ke(/<[/\w!]/g,e.innerHTML)&&Ke(/<[/\w!]/g,e.textContent))return dt(e),!0;if(e.nodeType===xt)return dt(e),!0;if(X&&e.nodeType===Tt&&Ke(/<[/\w]/g,e.data))return dt(e),!0;if(!N[n]||U[n]){if(!U[n]&&$t(n)){if(H.tagNameCheck instanceof RegExp&&Ke(H.tagNameCheck,n))return!1;if(H.tagNameCheck instanceof Function&&H.tagNameCheck(n))return!1}if(ae&&!oe[n]){const t=S(e)||e.parentNode,i=v(e)||e.childNodes;if(i&&t){for(let n=i.length-1;n>=0;--n){const s=g(i[n],!0);s.__removalCount=(e.__removalCount||0)+1,t.insertBefore(s,b(e))}}}return dt(e),!0}return e instanceof c&&!function(e){let t=S(e);t&&t.tagName||(t={namespaceURI:ye,tagName:"template"});const i=Pe(e.tagName),n=Pe(t.tagName);return!!ve[e.namespaceURI]&&(e.namespaceURI===fe?t.namespaceURI===ge?"svg"===i:t.namespaceURI===he?"svg"===i&&("annotation-xml"===n||Ce[n]):Boolean(Ye[i]):e.namespaceURI===he?t.namespaceURI===ge?"math"===i:t.namespaceURI===fe?"math"===i&&Te[n]:Boolean(ct[i]):e.namespaceURI===ge?!(t.namespaceURI===fe&&!Te[n])&&!(t.namespaceURI===he&&!Ce[n])&&!ct[i]&&(ke[i]||!Ye[i]):!("application/xhtml+xml"!==Ae||!ve[e.namespaceURI]))}(e)?(dt(e),!0):"noscript"!==n&&"noembed"!==n&&"noframes"!==n||!Ke(/<\/no(script|embed|frames)/i,e.innerHTML)?(Y&&e.nodeType===Ct&&(t=e.textContent,ze([D,E,_],e=>{t=Be(t,e," ")}),e.textContent!==t&&(Le(i.removed,{element:e.cloneNode()}),e.textContent=t)),bt($.afterSanitizeElements,e,null),!1):(dt(e),!0)},wt=function(e,t,i){if(ne&&("id"===t||"name"===t)&&(i in n||i in _e))return!1;if(q&&!K[t]&&Ke(z,t));else if(j&&Ke(M,t));else if(!B[t]||K[t]){if(!($t(e)&&(H.tagNameCheck instanceof RegExp&&Ke(H.tagNameCheck,e)||H.tagNameCheck instanceof Function&&H.tagNameCheck(e))&&(H.attributeNameCheck instanceof RegExp&&Ke(H.attributeNameCheck,t)||H.attributeNameCheck instanceof Function&&H.attributeNameCheck(t,e))||"is"===t&&H.allowCustomizedBuiltInElements&&(H.tagNameCheck instanceof RegExp&&Ke(H.tagNameCheck,i)||H.tagNameCheck instanceof Function&&H.tagNameCheck(i))))return!1}else if(pe[t]);else if(Ke(P,Be(i,L,"")));else if("src"!==t&&"xlink:href"!==t&&"href"!==t||"script"===e||0!==Ve(i,"data:")||!de[e]){if(W&&!Ke(R,Be(i,L,"")));else if(i)return!1}else;return!0},$t=function(e){return"annotation-xml"!==e&&Ie(e,O)},Dt=function(e){bt($.beforeSanitizeAttributes,e,null);const{attributes:t}=e;if(!t||ft(e))return;const n={attrName:"",attrValue:"",keepAttr:!0,allowedAttributes:B,forceKeepAttr:void 0};let s=t.length;for(;s--;){const a=t[s],{name:l,namespaceURI:r,value:o}=a,c=$e(l),d=o;let u="value"===l?d:He(d);if(n.attrName=c,n.attrValue=u,n.keepAttr=!0,n.forceKeepAttr=void 0,bt($.uponSanitizeAttribute,e,n),u=n.attrValue,!se||"id"!==c&&"name"!==c||(ut(l,e),u="user-content-"+u),X&&Ke(/((--!?|])>)|<\/(style|title|textarea)/i,u)){ut(l,e);continue}if("attributename"===c&&Ie(u,"href")){ut(l,e);continue}if(n.forceKeepAttr)continue;if(!n.keepAttr){ut(l,e);continue}if(!G&&Ke(/\/>/i,u)){ut(l,e);continue}Y&&ze([D,E,_],e=>{u=Be(u,e," ")});const p=$e(e.nodeName);if(wt(p,c,u)){if(C&&"object"==typeof h&&"function"==typeof h.getAttributeType)if(r);else switch(h.getAttributeType(p,c)){case"TrustedHTML":u=C.createHTML(u);break;case"TrustedScriptURL":u=C.createScriptURL(u)}if(u!==d)try{r?e.setAttributeNS(r,l,u):e.setAttribute(l,u),ft(e)?dt(e):Re(i.removed)}catch(t){ut(l,e)}}else ut(l,e)}bt($.afterSanitizeAttributes,e,null)},Et=function e(t){let i=null;const n=mt(t);for(bt($.beforeSanitizeShadowDOM,t,null);i=n.nextNode();)bt($.uponSanitizeShadowNode,i,null),Ft(i),Dt(i),i.content instanceof l&&e(i.content);bt($.afterSanitizeShadowDOM,t,null)};return i.sanitize=function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},n=null,a=null,r=null,c=null;if(be=!e,be&&(e="\x3c!--\x3e"),"string"!=typeof e&&!gt(e)){if("function"!=typeof e.toString)throw je("toString is not a function");if("string"!=typeof(e=e.toString()))throw je("dirty is not a string, aborting")}if(!i.isSupported)return e;if(J||We(t),i.removed=[],"string"==typeof e&&(le=!1),le){if(e.nodeName){const t=$e(e.nodeName);if(!N[t]||U[t])throw je("root node is forbidden and cannot be sanitized in-place")}}else if(e instanceof o)n=pt("\x3c!----\x3e"),a=n.ownerDocument.importNode(e,!0),a.nodeType===St&&"BODY"===a.nodeName||"HTML"===a.nodeName?n=a:n.appendChild(a);else{if(!ee&&!Y&&!Z&&-1===e.indexOf("<"))return C&&ie?C.createHTML(e):e;if(n=pt(e),!n)return ee?null:ie?x:""}n&&Q&&dt(n.firstChild);const d=mt(le?e:n);for(;r=d.nextNode();)Ft(r),Dt(r),r.content instanceof l&&Et(r.content);if(le)return e;if(ee){if(te)for(c=A.call(n.ownerDocument);n.firstChild;)c.appendChild(n.firstChild);else c=n;return(B.shadowroot||B.shadowrootmode)&&(c=w.call(s,c,!0)),c}let u=Z?n.outerHTML:n.innerHTML;return Z&&N["!doctype"]&&n.ownerDocument&&n.ownerDocument.doctype&&n.ownerDocument.doctype.name&&Ke(yt,n.ownerDocument.doctype.name)&&(u="<!DOCTYPE "+n.ownerDocument.doctype.name+">\n"+u),Y&&ze([D,E,_],e=>{u=Be(u,e," ")}),C&&ie?C.createHTML(u):u},i.setConfig=function(){We(arguments.length>0&&void 0!==arguments[0]?arguments[0]:{}),J=!0},i.clearConfig=function(){Ee=null,J=!1},i.isValidAttribute=function(e,t,i){Ee||We({});const n=$e(e),s=$e(t);return wt(n,s,i)},i.addHook=function(e,t){"function"==typeof t&&Le($[e],t)},i.removeHook=function(e,t){if(void 0!==t){const i=Me($[e],t);return-1===i?void 0:Oe($[e],i,1)[0]}return Re($[e])},i.removeHooks=function(e){$[e]=[]},i.removeAllHooks=function(){$={afterSanitizeAttributes:[],afterSanitizeElements:[],afterSanitizeShadowDOM:[],beforeSanitizeAttributes:[],beforeSanitizeElements:[],beforeSanitizeShadowDOM:[],uponSanitizeAttribute:[],uponSanitizeElement:[],uponSanitizeShadowNode:[]}},i}();function wt(e){if("undefined"==typeof SF||!SF.Loader)return;const t=SF.Loader,i=Number(t.dragObserverLockCount||0);t.dragObserverLockCount=e?i+1:Math.max(i-1,0),t.stopObserver=t.dragObserverLockCount>0}function $t(e,t={}){const i="function"==typeof t.accept?t.accept:()=>!0;return Array.from(e?.children||[]).filter(e=>e instanceof HTMLElement&&!e.classList.contains("is-dragging")&&!e.classList.contains("drag-placeholder")&&i(e)).map(e=>{const t=e.getBoundingClientRect();return{item:e,top:t.top,height:t.height,middle:t.top+t.height/2}})}function Dt(e,t,i={}){const n=Array.isArray(i.itemsLayout)?i.itemsLayout:$t(e,i);let s={offset:Number.NEGATIVE_INFINITY,element:null};for(const e of n){const i=t-e.middle;i<0&&i>s.offset&&(s={offset:i,element:e.item})}return s.element}function Et(e={}){const{handle:t,item:i,container:n,holdDelay:s=0,boundAttr:a="data-sf-sortable-drag-bound",draggingClass:l="is-dragging",placeholderClass:r="drag-placeholder",placeholderExtraClasses:o=[],shouldIgnorePointerDown:c,getAfterElement:d,getSortableItems:u,insertPlaceholder:p,onDragStart:m,onDrop:h,onCancel:f,dragContainer:g,minSortableItems:y=2}=e;if(!t||!i||!n)return null;if("1"===t.getAttribute(a))return null;t.setAttribute(a,"1");let b,v=!1,S=null,C=!1,x=0,T=0,k=null,A=null,F=[],w=null,$=null,D=null;const E=()=>{S&&(clearTimeout(S),S=null)},_=()=>{Object.assign(i.style,{position:"",left:"",top:"",width:"",zIndex:"",pointerEvents:"",boxSizing:"",backgroundColor:""})},z=e=>{if(v)return;if(e.preventDefault?.(),Number(y)>1){if((()=>{if("function"==typeof u){const e=u(n,i);return Array.isArray(e)?e:Array.from(e||[])}return $t(n,{accept:"function"==typeof d?()=>!0:void 0}).map(e=>e.item)})().filter(e=>e instanceof HTMLElement&&!e.classList.contains(l)&&!e.classList.contains(r)).length<Number(y))return}v=!0,C=!0,wt(!0),k=i.getBoundingClientRect(),A=n.getBoundingClientRect(),x=e.clientX-k.left,T=e.clientY-k.top,w=document.createElement(i.nodeName.toLowerCase()),w.className=r,w.style.width=`${k.width}px`,w.style.minHeight=`${k.height}px`,w.classList.add(...o,...i.classList),$=i.parentNode,D=i.nextSibling,i.before(w),(g||document.body).appendChild(i),i.classList.add(l);const s={position:"fixed",left:`${k.left}px`,top:`${k.top}px`,width:`${k.width}px`,zIndex:"9999",pointerEvents:"none",boxSizing:"border-box"};i.style.backgroundColor||(s.backgroundColor="var(--sf-primary-container)"),Object.assign(i.style,s),F=$t(n,{accept:"function"==typeof d?()=>!0:void 0}),b=void 0,t.setPointerCapture?.(e.pointerId),m?.({event:e,item:i,container:n,placeholder:w}),document.addEventListener("pointermove",M)},M=e=>{if(!v)return;let t=e.clientX-x,s=e.clientY-T;t=Math.max(A.left,t),s=Math.max(A.top,s),t=Math.min(A.right-k.width,t),s=Math.min(A.bottom-k.height,s),i.style.left=`${t}px`,i.style.top=`${s}px`,(e=>{const t="function"==typeof d?d(n,e.clientY,e,F):Dt(n,e.clientY,{itemsLayout:F});if(t!==b)if(b=t,"function"!=typeof p)if(t){if(w.nextSibling===t)return;n.insertBefore(w,t)}else{if(w.parentNode===n&&!w.nextSibling)return;n.appendChild(w)}else p(n,w,t,e)})(e)},R=e=>{if(E(),document.removeEventListener("pointermove",M),document.removeEventListener("pointercancel",L),!v)return;v=!1,wt(!1),t.releasePointerCapture?.(e.pointerId),w?.parentNode&&w.replaceWith(i),i.classList.remove(l),_();const s=w;w=null,k=null,A=null,F=[],b=void 0,$=null,D=null,h?.({event:e,item:i,container:n,placeholder:s})},L=()=>{if(E(),document.removeEventListener("pointermove",M),document.removeEventListener("pointerup",R),!v)return;v=!1,wt(!1),$&&$.insertBefore(i,D),w?.remove(),i.classList.remove(l),_();const e=w;w=null,k=null,A=null,F=[],b=void 0,$=null,D=null,f?.({item:i,container:n,placeholder:e})},O=e=>{0===e.button&&(c?.(e)||(E(),s>0?S=setTimeout(()=>{S=null,z(e)},s):z(e),document.addEventListener("pointerup",R,{once:!0}),document.addEventListener("pointercancel",L,{once:!0})))},P=e=>{C&&(C=!1,e.preventDefault(),e.stopImmediatePropagation())};return t.addEventListener("pointerdown",O),t.addEventListener("click",P,!0),()=>{E(),document.removeEventListener("pointermove",M),document.removeEventListener("pointerup",R),document.removeEventListener("pointercancel",L),t.removeEventListener("pointerdown",O),t.removeEventListener("click",P,!0),t.removeAttribute(a),wt(!1)}}const _t=["p","br","strong","b","em","i","u","s","ul","ol","li"];(class extends l{static get props(){return{templateName:{attribute:"template",default:"default"},ariaLabel:{attribute:"aria-label",default:"Data table"},selectable:{type:Boolean,default:!0},settings:{type:Boolean,default:!0},pagin:{type:Boolean,default:!1},actions:{type:Boolean,default:!0},filterText:{attribute:"filter-text",default:"Фильтр"},clearText:{attribute:"clear-text",default:"Очистить"},searchPlaceholder:{attribute:"search-placeholder",default:"Поиск"},createText:{attribute:"create-text",default:"Создать"},paginationTotal:{attribute:"pagination-total",type:Number,default:10},paginationPageSize:{attribute:"pagination-page-size",type:Number,default:10},pageSizes:{attribute:"page-sizes",default:"10,20,30,40"},contextMenuColumns:{attribute:"context-menu-columns",type:Number,default:2},tableSettingsKey:{attribute:"table-settings-key",default:"users"}}}constructor(){super(),this.ACTIONS_SETTINGS_ROW=[{name:"Редактировать",id:"edit",component:{type:"icon-button",props:{variant:"icon",size:"1",type:"link",scheme:"on-surface",icon:"edit",ariaLabel:"Редактировать",value:"edit"}}},{name:"Посмотреть",id:"view",component:{type:"icon-button",props:{variant:"icon",size:"1",type:"link",scheme:"on-surface",icon:"visibility",ariaLabel:"Посмотреть",value:"view"}}},{name:"Удалить",id:"delete",component:{type:"icon-button",props:{variant:"icon",size:"1",type:"link",scheme:"on-surface",icon:"delete",ariaLabel:"Удалить",value:"delete"}}}],this.TABLE_ACTIONS_COLUMN={key:"actions",system:!0,width:"var(--sf-table--actions-column-width, var(--sf-f0))",label:"Действия"},this.TABLE_SETTINGS_COLUMN={key:"settings",label:"settings",system:!0,width:"calc(var(--sf-text-height-1) + calc(var(--sf-ui-1--space-y-tightness-default) * 2) + 1rem)",component:{type:"icon-button",props:{size:"1",type:"link",scheme:"on-surface",icon:"settings",ariaLabel:"Настройки",value:"settings","@click":e=>{this.openContextMenu(e,{menu:"table-settings"})}}}},this.contextEvent=this.contextEvent.bind(this),this.hoverEvents=this.hoverEvents.bind(this),this.outEvent=this.outEvent.bind(this),this.onColumnResizePointerDown=this.onColumnResizePointerDown.bind(this),this.onColumnResizePointerMove=this.onColumnResizePointerMove.bind(this),this.onColumnResizePointerUp=this.onColumnResizePointerUp.bind(this),this.onColumnDragPointerDown=this.onColumnDragPointerDown.bind(this),this.onColumnDragPointerMove=this.onColumnDragPointerMove.bind(this),this.onColumnDragPointerUp=this.onColumnDragPointerUp.bind(this),this.onColumnDragPointerCancel=this.onColumnDragPointerCancel.bind(this),this._contextEventBound=!1,this._hoverEventBound=!1,this._columnResizeEventBound=!1,this._columnDragEventBound=!1,this._columnResizeState=null,this._columnDragState=null,this._columnAnimationToken=0,this.searchChange=this.scheduleSearchChange.bind(this),this._searchDebounceTimer=null,this._searchPendingProps=null,this._searchHoldKey="",this.refs={contextMenu:this.createRef(),detailModal:this.createRef(),fieldCreateModal:this.createRef(),fieldList:this.createRef(),items:new Map,pagination:this.createRef(),templateForm:this.createRef(),renameInput:this.createRef(),table:this.createRef()},this._detailModalBound=null,this._fieldCreateModalBound=null,this._checkboxMeasureToken=0,this._filterTemplatesLoaded=!1,this.tempSettings=null,this.state={settingsChecked:!1,modalOpen:!1,detail:{loading:!1,row:null,fields:[],viewSettings:null,editedFields:{},tempFields:{}},saveInputValue:"",search:{searchActive:!1,value:""},pagination:{},contextMenu:{open:!1},fieldCreate:{open:!1,mode:"create",step:"type",entity:"task",fieldKey:null,selectedType:null,settings:{label:"",key:"",required:!1,multiple:!1,options:[{id:1,label:"Option 1"},{id:2,label:"Option 2"}]}},actions:this.getActions().map(e=>Object.assign(e,{visible:!0})),actionActive:this.getProp("actions"),columnSettings:{},selectIndeterminate:!1,filterDataDirty:!1,filter:{selectedTemplateKey:"default",fieldTypes:[],fields:[],templates:[],edit:{rename:""}}},this.TABLE_SELECT_COLUMN={key:"select",label:"select",system:!0,width:"calc(var(--sf-text-height-1) + 1rem + 2px);",component:{type:"checkbox",props:{position:"end",rootClass:"content-main-between",size:1,"@change":e=>{const{checked:t}=e.target;this.set({selectIndeterminate:!1,settingsChecked:t}),this.updateRows(e=>({...e,select:this.createRowComponentCell(this.TABLE_SELECT_COLUMN.rowComponent,{checked:t,value:e.id??e.value??""})}),"select-all")},indeterminate:this.state.selectIndeterminate,checked:this.state.settingsChecked}},rowComponent:{type:"checkbox",props:{position:"end",rootClass:"content-main-between",size:1,"@change":e=>{const{checked:t}=e.target;let i=e.target.closest("td").dataset.item;i=i.split("_"),this.updateRowCellProps("id",+i[0],i[1],{checked:t});const n=this.setIndeterminate();this.set({settingsChecked:!(!n&&this.state.settingsChecked)&&this.state.settingsChecked,selectIndeterminate:n})}}}}}getActions(){return this.getProp("actions")?this.ACTIONS_SETTINGS_ROW.map(e=>{const{name:t,id:i}=e;return{name:t,id:i}}):[]}normalizePageSizes(e=this.getProp("pageSizes")){if(Array.isArray(e))return e.map(e=>Math.trunc(Number(e))).filter(e=>Number.isFinite(e)&&e>0);if("string"==typeof e){const t=e.split(",").map(e=>Math.trunc(Number(e.trim()))).filter(e=>Number.isFinite(e)&&e>0);return t.length?t:[10,20,30,40]}const t=Math.trunc(Number(e));return Number.isFinite(t)&&t>0?[t]:[10,20,30,40]}getPaginationPageSizesString(e){return this.normalizePageSizes(e).join(",")}normalizePaginationData(e={},t={}){const i=e&&"object"==typeof e?e:{},n=t&&"object"==typeof t?t:{},s=Math.trunc(Number(this.getProp("paginationPageSize")))||10,a=i.pageSizes||(Array.isArray(i.pageSize)?i.pageSize:null)||n.pageSizes||(Array.isArray(n.pageSize)?n.pageSize:null)||this.getProp("pageSizes"),l=this.normalizePageSizes(a),r=Math.max(1,Math.trunc(Number(i.limit??i.perPage??i.pageSizeValue??(Array.isArray(i.pageSize)?null:i.pageSize)??n.limit??n.perPage??n.pageSizeValue??(Array.isArray(n.pageSize)?null:n.pageSize)??s))||s),o=Math.max(0,Math.trunc(Number(i.total??n.total??this.getProp("paginationTotal")??0))||0),c=Math.max(1,Math.trunc(Number(i.pageCount??i.totalPages??n.pageCount??n.totalPages??Math.ceil(o/r)))||1),d=Math.min(c,Math.max(1,Math.trunc(Number(i.current??i.page??n.current??n.page??1))||1)),u=Math.max(0,Math.trunc(Number(i.offset??n.offset??(d-1)*r))||0),p=Math.max(u,Math.trunc(Number(i.nextOffset??n.nextOffset??Math.min(u+r,o)))||u);return{...n,...i,current:d,page:d,pageSize:r,limit:r,pageSizes:l,total:o,pageCount:c,totalPages:c,offset:u,nextOffset:p,hasMore:"boolean"==typeof i.hasMore?i.hasMore:"boolean"==typeof n.hasMore?n.hasMore:d<c}}getPaginationData(e={}){const t=this.getTableData()?.pagination||{},i=this.state?.pagination||{};return this.normalizePaginationData({...t,...i,...e||{}},t)}setPaginationData(e={},t="pagination"){const i=this.getPaginationData(e);return this.set(e=>({pagination:{...e.pagination||{},...i}}),t)}getPaginationRequestParams(e={},t="replace"){const i=this.getPaginationData(e);return{mode:t,tableSettingsKey:this.getTableSettingsKey(),page:i.current,current:i.current,limit:i.pageSize,pageSize:i.pageSize,offset:(i.current-1)*i.pageSize,total:i.total,pageCount:i.pageCount,hasMore:i.hasMore,search:this.state?.search?.value||"",filterValues:this.getCurrentFilterValues?.()||{},filterTags:this.getCurrentFilterTags?.()||{}}}emitPaginationRequest(e={},t="replace",i=null){const n={...this.getPaginationRequestParams(e,t),...e||{},mode:t,source:"string"==typeof i?i:i?.type||""};return this.dispatchEvent(new CustomEvent("sf-table:page-request",{bubbles:!0,composed:!0,detail:n})),this.dispatchEvent(new CustomEvent("onPageRequest",{bubbles:!0,composed:!0,detail:n})),n}handlePaginationPageChange(e){const t=e?.detail||{},i=Math.trunc(Number(t.pageSize))||this.getPaginationData().pageSize,n=Math.trunc(Number(t.current))||1;this.setPaginationData({current:n,page:n,pageSize:i,limit:i},"pagination-page"),this.emitPaginationRequest({current:n,page:n,pageSize:i,limit:i},"replace",e)}handlePaginationPageSizeChange(e){const t=e?.detail||{},i=Math.trunc(Number(t.pageSize))||this.getPaginationData().pageSize;this.setPaginationData({current:1,page:1,pageSize:i,limit:i,offset:0},"pagination-page-size"),this.emitPaginationRequest({current:1,page:1,pageSize:i,limit:i,offset:0},"replace",e)}handlePaginationShowMore(e){const t=this.getPaginationData(),i=Math.min(t.current+1,t.pageCount);i<=t.current||(this.setPaginationData({current:i,page:i},"pagination-show-more"),this.emitPaginationRequest({current:i,page:i,pageSize:t.pageSize,limit:t.pageSize,offset:t.nextOffset},"append",e))}isSearchHoldKey(e=""){return"Backspace"===e||"Delete"===e}clearSearchDebounce(){this._searchDebounceTimer&&(clearTimeout(this._searchDebounceTimer),this._searchDebounceTimer=null)}scheduleSearchChange(e={}){return this._searchPendingProps=e,this.clearSearchDebounce(),this._searchHoldKey||(this._searchDebounceTimer=setTimeout(()=>{const e=this._searchPendingProps||{};this._searchPendingProps=null,this._searchDebounceTimer=null,this.updateSearchState(e)},500)),this}handleSearchKeyDown(e){return this.isSearchHoldKey(e?.key)?(this._searchHoldKey=e.key,this.clearSearchDebounce(),this):this}handleSearchKeyUp(e){return this._searchHoldKey&&e?.key===this._searchHoldKey?(this._searchHoldKey="",this._searchPendingProps&&this.scheduleSearchChange(this._searchPendingProps),this):this}updateSearchState(e={},t=!0){const i=this.state.search||{};let n=!1;for(const[t,s]of Object.entries(e))if(!Object.is(i[t],s)){n=!0;break}if(!n)return this;this.set(t=>({search:{...t.search,...e}}),()=>{if(!t)return!1;this.dispatchEvent(new CustomEvent("onSearchEnd",{bubbles:!0,composed:!0,detail:this.state.search.value}))})}getItemRef(e){return this.refs.items.has(e)||this.refs.items.set(e,this.createRef()),this.refs.items.get(e)}setIndeterminate(){return this.state.data.rows.filter(e=>e.select.component.props.checked).length}getTableData(){const e=this.state?.data;return e&&"object"==typeof e?e:{columns:[],rows:[]}}isContextMenuEvent(e){const t=this.refs?.contextMenu?.value;if(!(t instanceof Node))return!1;const i=e?.target;return i instanceof Node&&(!(t!==i&&!t.contains(i))||(e.composedPath?.().includes(t)||!1))}contextEvent(e){this.isContextMenuEvent(e)||this.closeContextMenu()}getPendingFilterState(e=this.state?.filter||{}){const t=this.tempSettings?.filter||{},i=Object.prototype.hasOwnProperty.call(t,"selectedTemplateKey");return{...e,...t,selectedTemplateKey:i?t.selectedTemplateKey:e.selectedTemplateKey,templates:t.templates||e.templates||[]}}getSortedFilterTemplates(e=this.state?.filter||{}){return this.getFilterTemplates(e).map((e,t)=>({...e,sourceIndex:t,order:"number"==typeof e.order?e.order:t})).sort((e,t)=>Boolean(e.pinned)!==Boolean(t.pinned)?e.pinned?-1:1:e.order!==t.order?e.order-t.order:e.sourceIndex-t.sourceIndex)}changeTempFilterTemplateSettings(e,t={}){if(!e)return;const i=this.getPendingFilterState(),n=this.getFilterTemplates(i).map(i=>{for(const[n,s]of Object.entries(t))i[n]=e===i.key?s:!s;return i});this.tempSettings={...this.tempSettings||{},filter:{...this.tempSettings?.filter||{},selectedTemplateKey:i.selectedTemplateKey,templates:n}},this.requestComponentUpdate("temp-filter-template")}patchTempFilterTemplateSettings(e,t={}){if(!e)return;const i=this.getPendingFilterState(),n=this.getFilterTemplates(i).map(i=>i.key===e?{...i,..."function"==typeof t?t(i):t}:i);this.tempSettings={...this.tempSettings||{},filter:{...this.tempSettings?.filter||{},selectedTemplateKey:i.selectedTemplateKey,templates:n}},this.requestComponentUpdate("temp-filter-template")}selectTempFilterTemplate(e){if(!e)return;const t=this.getPendingFilterState(),i=this.getFilterTemplates(t).map(t=>({...t,selected:t.key===e}));this.tempSettings={...this.tempSettings||{},filter:{...this.tempSettings?.filter||{},selectedTemplateKey:e,templates:i}},this.requestComponentUpdate("temp-filter-template")}normalizeFilterTemplate(e={},t=0){const i=e.key||`filter_template_${t+1}`,n=e.data&&"object"==typeof e.data?e.data:{};return{...e,key:i,label:e.label||n.template_name||i,data:{...n,values:{...n.values||{}},tags:{...n.tags||{}}}}}getFilterTemplates(e=this.state?.filter||{}){const t=(e.templates||[]).map((e,t)=>this.normalizeFilterTemplate(e,t));return t.length?t:[this.normalizeFilterTemplate({key:e.selectedTemplateKey||"default",label:"По умолчанию",selected:!0,order:0,data:{}})]}getFilterTemplateByKey(e,t=this.state?.filter||{}){return e&&t&&this.getFilterTemplates(t).find(t=>t.key===e)||null}getSelectedFilterTemplate(e=this.state?.filter||{}){const t=this.getFilterTemplates(e);if(Object.prototype.hasOwnProperty.call(e,"selectedTemplateKey")&&""===e.selectedTemplateKey)return null;const i=e.selectedTemplateKey||t.find(e=>e.selected)?.key||t[0]?.key||"";return this.getFilterTemplateByKey(i,{...e,templates:t})||t[0]||null}getCurrentFilterValues(e=this.state?.filter||{}){const t=this.getSelectedFilterTemplate(e);return{...t?.data?.values||{}}}getCurrentFilterTags(e=this.state?.filter||{}){const t=this.getSelectedFilterTemplate(e);return{...t?.data?.tags||{}}}normalizeFilterDataForCompare(e){return Array.isArray(e)?e.map(e=>this.normalizeFilterDataForCompare(e)):e&&"object"==typeof e?Object.keys(e).sort().reduce((t,i)=>({...t,[i]:this.normalizeFilterDataForCompare(e[i])}),{}):e}isSameFilterData(e,t){return JSON.stringify(this.normalizeFilterDataForCompare(e||{}))===JSON.stringify(this.normalizeFilterDataForCompare(t||{}))}getMergedFilterDraftData(e=this.state?.filter||{},t=this.tempSettings?.filter||{}){const i=this.getPendingFilterState({...e,selectedTemplateKey:Object.prototype.hasOwnProperty.call(t,"selectedTemplateKey")?t.selectedTemplateKey:e.selectedTemplateKey,templates:t.templates||e.templates||[]}),n=this.getCurrentFilterTags(i),s=this.getCurrentFilterValues(i),a=t.replaceTags?{...t.tags||{}}:{...n,...t.tags||{}},l=t.replaceValues?{...t.values||{}}:{...s,...t.values||{}};return Object.entries(t.values||{}).forEach(([e,t])=>{this.isEmptyFilterEntry(t)&&(delete l[e],delete a[e])}),{filter:i,tags:a,values:l}}hasPendingFilterDataChanges(e=this.state?.filter||{}){const t=this.tempSettings?.filter;if(!t||!Object.prototype.hasOwnProperty.call(t,"tags")&&!Object.prototype.hasOwnProperty.call(t,"values")&&!t.replaceTags&&!t.replaceValues)return!1;const i=this.getMergedFilterDraftData(e,t);return!this.isSameFilterData(this.getCurrentFilterTags(i.filter),i.tags)||!this.isSameFilterData(this.getCurrentFilterValues(i.filter),i.values)}hasUnsavedFilterDataChanges(){return Boolean(this.state?.filterDataDirty&&this.getSelectedFilterTemplate(this.state?.filter||{}))}saveCurrentFilterTemplateData(){const e=this.getSelectedFilterTemplate(this.state?.filter||{});return e?this.set({filterDataDirty:!1},()=>{this.dispatchFilterTemplateSave(e.key,this.state.filter,this.getFilterTemplateByKey(e.key))}):this}mergeObjectDeep(e={},t={}){return Object.entries(t||{}).reduce((e,[t,i])=>{const n=e[t],s=i&&"object"==typeof i&&!Array.isArray(i)&&n&&"object"==typeof n&&!Array.isArray(n);return{...e,[t]:s?this.mergeObjectDeep(n,i):i}},{...e||{}})}patchFilterTemplateByKey(e,t=this.state.filter,i={}){if(!e||!t)return{filter:t,template:null};let n=null;return{filter:{...t,templates:this.getFilterTemplates(t).map(t=>{if(e!==t.key)return t;const s="function"==typeof i?i(t):i;return n=this.mergeObjectDeep(t,s),n})},template:n}}createFilterTemplatePatchState(e,t={}){const i={filter:e};return Object.prototype.hasOwnProperty.call(t,"saveInputValue")&&(i.saveInputValue=t.saveInputValue),i}dispatchFilterTemplateSave(e,t,i=null){return this.dispatchEvent(new CustomEvent("onTemplateSave",{bubbles:!0,composed:!0,detail:i||this.getFilterTemplateByKey(e,t)})),this}getChangedFilterTemplates(e={},t={},i=[]){const n=new Map(this.getFilterTemplates(e).map(e=>[e.key,e]));return this.getFilterTemplates(t).filter(e=>{const t=n.get(e.key);return!t||i.some(i=>!Object.is(t[i],e[i]))})}dispatchFilterTemplatesSave(e=[]){const t=e.filter(e=>e?.key);return t.length?(this.dispatchEvent(new CustomEvent("onTemplateSave",{bubbles:!0,composed:!0,detail:1===t.length?t[0]:t})),this):this}saveFilterTemplatePatch(e,t={},i={},n=this.state.filter){if(!e||!n)return this;const s=this.patchFilterTemplateByKey(e,n,t),a={...s.filter,...i.filterPatch||{}};return this.set(()=>this.createFilterTemplatePatchState(a,i),()=>{!1!==i.dispatch&&this.dispatchFilterTemplateSave(e,a,s.template)})}setDefaultFilterTemplate(e){return e?this.set(t=>{const i=t.filter||{};return{filter:{...i,templates:this.getFilterTemplates(i).map(t=>({...t,default:t.key===e}))}}}):this}patchFilterTemplateData(e={},t={}){const i={...e};delete i.tags,delete i.values;const n=this.getFilterTemplates(i),s=this.getSelectedFilterTemplate({...i,templates:n});if(!s)return{...i,templates:n};const a=Object.prototype.hasOwnProperty.call(t,"values")?t.values||{}:s.data?.values||{},l=Object.prototype.hasOwnProperty.call(t,"tags")?t.tags||{}:s.data?.tags||{},r=n.map(e=>e.key===s.key?{...e,data:{...e.data||{},...t.data||{},values:a,tags:l}}:e);return{...i,selectedTemplateKey:s.key,templates:r}}getFilterPayload(e=this.state?.filter||{}){const t=this.getSelectedFilterTemplate(e);return{...t?.data||{},templateKey:t?.key||"",templateLabel:t?.label||"",values:this.getCurrentFilterValues(e),tags:this.getCurrentFilterTags(e)}}selectFilterTemplate(e){return e&&this.state?.filter?.selectedTemplateKey!==e?(this.set(t=>{const i={...t.filter||{},selectedTemplateKey:e,templates:(t.filter?.templates||[]).map(t=>({...t,selected:t.key===e}))},n=this.getFilterTemplateByKey(e,i)||i.templates[0]||null;return{filter:i,saveInputValue:n?.label||""}}),this):this}bindFilterTemplateDrag(){const e=this.refs?.contextMenu?.value,t=e?.querySelector?.("[data-filter-template-list]"),i=t?.querySelector?.(".sf-list-container")||t;i&&i.querySelectorAll("[data-filter-template-key]").forEach(e=>{Et({handle:e.querySelector("[data-move]"),item:e,container:i,boundAttr:"data-sf-table-template-drag-bound",getSortableItems:(e,t)=>this.getFilterTemplateSortableItems(e,"1"===t?.dataset?.pinned),getAfterElement:(t,i)=>this.getFilterTemplateDragAfterElement(t,i,"1"===e.dataset.pinned),insertPlaceholder:(t,i,n)=>{this.insertFilterTemplatePlaceholder(t,i,n,"1"===e.dataset.pinned)},onDrop:()=>{this.syncFilterTemplateOrderFromContainer(i)}})})}getFilterTemplateSortableItems(e,t=!1){return Array.from(e?.children||[]).filter(e=>e instanceof HTMLElement&&e.dataset.filterTemplateKey&&e.dataset.pinned===(t?"1":"0")&&!e.classList.contains("hidden")&&!e.classList.contains("is-dragging")&&!e.classList.contains("drag-placeholder"))}getFilterTemplateDragAfterElement(e,t,i=!1,n=null){return Dt(e,t,{itemsLayout:Array.isArray(n)?n.filter(e=>e.item?.dataset?.filterTemplateKey&&e.item?.dataset?.pinned===(i?"1":"0")&&!e.item.classList.contains("hidden")):null,accept:e=>e.dataset.filterTemplateKey&&e.dataset.pinned===(i?"1":"0")&&!e.classList.contains("hidden")})}insertFilterTemplatePlaceholder(e,t,i,n=!1){if(i)return void e.insertBefore(t,i);const s=n?"1":"0",a=Array.from(e?.children||[]).filter(e=>e instanceof HTMLElement&&e.dataset.filterTemplateKey&&e.dataset.pinned===s&&!e.classList.contains("is-dragging")&&!e.classList.contains("drag-placeholder")).at(-1);if(a?.nextSibling)e.insertBefore(t,a.nextSibling);else{if(n){const i=Array.from(e?.children||[]).find(e=>e instanceof HTMLElement&&e.dataset.filterTemplateKey&&"0"===e.dataset.pinned&&!e.classList.contains("is-dragging")&&!e.classList.contains("drag-placeholder"));if(i)return void e.insertBefore(t,i)}e.appendChild(t)}}syncFilterTemplateOrderFromContainer(e){const t={pinned:new Map,normal:new Map};Array.from(e?.children||[]).filter(e=>e instanceof HTMLElement&&e.dataset.filterTemplateKey&&!e.classList.contains("drag-placeholder")).forEach(e=>{const i="1"===e.dataset.pinned?"pinned":"normal";t[i].set(e.dataset.filterTemplateKey,t[i].size)});const i=this.getPendingFilterState(),n=this.getFilterTemplates(i).map((e,i)=>{const n=e.pinned?"pinned":"normal",s=t[n].get(e.key);return"number"!=typeof s?e:{...e,order:s,sourceIndex:i}});this.tempSettings={...this.tempSettings||{},filter:{...this.tempSettings?.filter||{},selectedTemplateKey:i.selectedTemplateKey,templates:n.sort((e,t)=>Boolean(e.pinned)!==Boolean(t.pinned)?e.pinned?-1:1:e.order!==t.order?e.order-t.order:e.sourceIndex-t.sourceIndex)}},this.requestComponentUpdate("temp-filter-template-order")}getSystemColumns(){const e=[],t=this.getPropsContext();return t.selectable&&e.push(this.getSelectColumn()),t.settings&&e.push(this.TABLE_SETTINGS_COLUMN),t.actions&&this.state.actionActive&&e.push(this.TABLE_ACTIONS_COLUMN),e}setTemplates(e){const t=Object.values(e||{}).map((e,t)=>this.normalizeFilterTemplate(e,t));return this.set(e=>{const i=e.filter||{},n=new Map;this.getFilterTemplates(i).forEach(e=>{n.set(e.key,e)}),t.forEach(e=>{n.set(e.key,{...n.get(e.key)||{},...e})});const s=Array.from(n.values()),a=Object.prototype.hasOwnProperty.call(i,"selectedTemplateKey"),l=s.find(e=>!0===e.default),r=t.find(e=>e?.selected)?.key,o=l?.key||s[0]?.key||"",c=this._filterTemplatesLoaded?r??(a?i.selectedTemplateKey:o):r??o,d={...i,selectedTemplateKey:c,templates:s.map(e=>({...e,selected:e.key===c}))},u=""===c?null:this.getFilterTemplateByKey(c,{...d,templates:s})||s[0]||null;return this._filterTemplatesLoaded=!0,{filter:d,saveInputValue:u?.label||""}})}getTableSettingsKey(){return this.tableSettingsKey||this.getAttribute?.("table-settings-key")||this.id||"users"}normalizeTableSettings(e={},t=this.getTableSettingsKey()){const i=!e?.tableSettings||"object"!=typeof e.tableSettings||Array.isArray(e.tableSettings)||e.tableSettings.columnSettings?null:e.tableSettings,n=e?.item||i?.[t]||e?.tableSettings||e?.settings||e||{},s=n?.columnSettings||e?.columnSettings||{};return{...n,columnSettings:s&&"object"==typeof s&&!Array.isArray(s)?s:{}}}setTableSettings(e={},t="table-settings-load",i=this.getTableSettingsKey()){const n=this.normalizeTableSettings(e,i);return this.setColumnSettings(n.columnSettings,t,!1)}renderFilterFavoritesContextMenu(e){const{x:t,y:i,position:s}=e,a=this.getSelectedFilterTemplate();return n`
            <sf-context-menu
                    :key=${t+i+this._renderToken}
                    style="
            position: fixed;
            inset-inline-start: ${t}px;
            inset-block-start: calc(${i}px + calc(var(--sf-focus-outline-width) * 2));
            z-index: 9998;
          "
                    root-class="sf-table-context-menu flex flex-col"
                    data-context-main-menu
                    position="${s||""}"
            >
                <div class="flex flex-col flex-1 gap-2" slot="content">
                    <div class="sf-table-context-top"><span class="sf-text-2 bold">Сохранение шаблона</span></div>
                    <div class="sf-table-context-main">
                        <form :ref=${this.refs.templateForm} id="save_template" class="flex flex-col gap-1/2">
                            <sf-input
                                    size="1"
                                    type="filled"
                                    placeholder="Название"
                                    value="${this.state.saveInputValue}"
                                    name="template_name"
                                    @change=${e=>{this.set({saveInputValue:e.target.value})}}
                                    @input=${e=>{this.set({saveInputValue:e.target.value})}}
                            ></sf-input>
                            <div class="flex flex-col gap-1/2">
                                <sf-checkbox
                                        name="template_default"
                                        position="end"
                                        root-class="content-main-between"
                                        value="1"
                                        ?checked=${a.data.template_default}
                                        label="Сделать по умолчанию"
                                ></sf-checkbox>
                                <sf-checkbox
                                        name="template_save_for_all"
                                        position="end"
                                        root-class="content-main-between"
                                        value="1"
                                        ?checked=${a.data.template_save_for_all}
                                        label="Сохранить для всех"
                                ></sf-checkbox>
                        </form>
                    </div>
                </div>
                <div class="sf-table-context-bottom flex gap-1/3">
                    <sf-button @click="${()=>{this.tempSettings=null,this.requestComponentUpdate("table")}}" type="outline" scheme="on-surface" root-class="flex-1"
                               text="Сбросить"></sf-button>
                    <sf-button
                            ?disabled=${0===this.state.saveInputValue.length}
                            @click="${()=>{this.saveFilterTemplate()}}" root-class="flex-1" text="Применить"></sf-button>
                </div>
                </div>
            </sf-context-menu>
        `}saveFilterTemplate(){const e=this.refs.templateForm.value;if(!e)return!1;const t=Object.fromEntries(new FormData(e)),{templates:i}=this.state.filter,n=i.filter(e=>e.label===t.template_name)?.[0],s=this.getCurrentFilterValues(),a=this.getCurrentFilterTags();let l={key:n?n.key:`filter_template_${i.length+1}`,label:t.template_name,selected:!0,data:{...t,values:s,tags:a}};this.dispatchEvent(new CustomEvent("onTemplateSave",{bubbles:!0,composed:!0,detail:l})),this.tempSettings=null,this.closeContextMenu()}renderRowSettingsContextMenu(e){const{x:t,y:i,position:s,tempVisible:a,transform:l,items:r=[{component:"sf-button",props:{type:"link",scheme:"on-surface",iconLeft:"save",text:"Сохранить","@click":()=>{}}},{component:"sf-button",props:{type:"link",scheme:"on-surface",iconLeft:"edit",text:"Изменить"}},{component:"sf-button",props:{type:"link",scheme:"on-surface",iconLeft:"visibility"+(a?"":"_off"),text:""+(a?"Показать":"Скрыть"),"@click":()=>{}}},{component:"sf-button",props:{type:"link",scheme:"on-surface",iconLeft:"delete",text:"Удалить","@click":()=>{}}}]}=e;let o=`translateY(calc(${void 0!==l?l:-50}%))`;if(s)switch(s){case"left-bottom":case"right-bottom":o=`translateY(calc(${void 0!==l?l:-100}% + var(--sf-context-menu-tail-corner-offset)))`}return n`
            <sf-context-menu
                    :key=${t+i}
                    style="
            position: fixed;
            inset-inline-start: calc(${t}px + var(--sf-context-menu-tail-corner-offset));
            inset-block-start: ${i}px;
            transform: ${o};
            z-index: 9998;
          "
                    .items=${r}
                    position="${s||"left"}"
            >
            </sf-context-menu>
        `}getColumnItems(){const e=new Set(this.getSystemColumns().map(e=>String(e.key)));return this.getColumns().filter(t=>t?.key&&!e.has(String(t.key)))}getColumnSettings(){const e=this.getTableData().columnSettings,t=this.state?.columnSettings;return{...e&&"object"==typeof e&&!Array.isArray(e)?e:{},...t&&"object"==typeof t&&!Array.isArray(t)?t:{}}}getColumnSetting(e){if(!e)return{};const t=this.getColumnSettings()?.[e];return t&&"object"==typeof t&&!Array.isArray(t)?t:{}}normalizeColumnSetting(e={}){const t={};return Object.entries(e||{}).forEach(([e,i])=>{void 0!==i&&("colWidth"!==e?t[e]=i:t.width=i)}),void 0!==t.order&&null!==t.order&&""!==t.order&&(t.order=Number(t.order)),t}mergeColumnSettings(e={},t={}){const i={...e||{}},n=new Set(this.getSystemColumns().map(e=>String(e.key)));return Object.entries(t||{}).forEach(([e,t])=>{e&&t&&"object"==typeof t&&(n.has(String(e))||(i[e]=this.normalizeColumnSetting({...i[e]||{},...t})))}),i}emitColumnSettingsChange(e="column-settings"){const t={reason:e,columnSettings:this.getColumnSettings(),tableSettingsKey:this.getTableSettingsKey()};return this.dispatchEvent(new CustomEvent("sf-table:column-settings-change",{bubbles:!0,composed:!0,detail:t})),this.dispatchEvent(new CustomEvent("onColumnSettingsChange",{bubbles:!0,composed:!0,detail:t})),this}setColumnSettings(e={},t="column-settings",i=!0){const n="function"==typeof e?e(this.getColumnSettings()):e,s=new Set(this.getSystemColumns().map(e=>String(e.key))),a=n&&"object"==typeof n?Object.fromEntries(Object.entries(n).filter(([e])=>!s.has(String(e)))):{};return this.set({columnSettings:a},t,()=>!!i&&this.emitColumnSettingsChange(t))}patchColumnSettings(e,t={},i="column-settings"){if(!e)return this;const n=this.getColumnSetting(e),s="function"==typeof t?t(n):t;return this.patchColumnSettingsBatch({[e]:s||{}},i)}patchColumnSettingsBatch(e={},t="column-settings"){const i=this.getColumnSettings(),n=this.mergeColumnSettings(i,e);return JSON.stringify(i)===JSON.stringify(n)?this:this.setColumnSettings(n,t)}getFilterFields(){const e=this.state?.filter?.fields,t=this.getTableData().fields;return Array.isArray(e)&&e.length?e:Array.isArray(t)?t:[]}getFilterField(e){return e&&this.getFilterFields().find(t=>t?.key===e)||null}getTableFields(){const e=this.getFilterFields(),t=this.getTableData().fields;return Array.isArray(e)&&e.length?e:Array.isArray(t)?t:[]}getTableField(e){return e&&this.getTableFields().find(t=>t?.key===e)||null}getObjectDisplayValue(e,t=null){if(null==e)return"";if(Array.isArray(e))return e.map(e=>this.getObjectDisplayValue(e,t)).filter(e=>""!==e).join(", ");if("object"!=typeof e)return e;const i=[t,"displayValue","label","title","name","fullName","text","value","id"].filter(Boolean);for(const t of i){const i=e[t];if(null!=i&&""!==i)return i}return""}getCellDisplayValue(e,t={}){const i=this.getTableField(t?.key),n=t?.displayField||t?.column?.displayField||i?.column?.displayField||i?.displayField||i?.labelField||i?.textField||null;return this.getObjectDisplayValue(e,n)}getFieldType(e={}){if(!e||"object"!=typeof e)return"text";const t=e.fieldType||e.schema?.fieldType||e.typeConfig?.id;if(t)return String(t);const i=e.editor?.component?.type;return"avatar"===e.type||"image"===e.dataType?"avatar":"phone"===e.type||"phone"===e.dataType||"country-code"===i?"phone":"email"===e.type||"email"===e.dataType?"email":"link"===e.type||"url"===e.dataType?"link":"users"===e.type||"user"===e.type?"user":"progress"===e.type||"progress-scale"===e.column?.renderer?"number":"enum"===e.type||"enum"===e.dataType||"dropdown"===i?"dropdown":"date"===e.type||"date"===e.dataType||"datepicker"===i?"date":"file-upload"===i||"file"===e.dataType?"file":"editor"===i||"textarea"===e.editor?.control?"textarea":"number"===e.dataType||"integer"===e.dataType?"number":"boolean"===e.dataType?"checkbox":"text"}getFieldEditorComponentType(e={}){const t=e.editor?.component?.type;if(t)return t;return{avatar:"file-upload",checkbox:"checkbox",date:"datepicker",dropdown:"dropdown",email:"input",file:"file-upload",number:"input",phone:"country-code",textarea:"editor",text:"input",user:"dropdown",link:"input"}[this.getFieldType(e)]||"input"}getFieldFilterControl(e={}){if(e.filter?.control)return e.filter.control;const t=this.getFieldType(e),i=Boolean(e.multiple||e.schema?.multiple);switch(t){case"date":return"date";case"dropdown":return i?"multi-select":"single-select";case"number":return"number";case"user":return i?"entity-multi-select":"entity-single-select";default:return"text"}}getFieldDetailRenderer(e={}){return e.detail?.renderer||e.renderer||e.column?.renderer||this.getFieldType(e)}isRichTextField(e={}){return"editor"===this.getFieldEditorComponentType(e)||"textarea"===this.getFieldType(e)}setFilterFields(e=[],t="filter-fields"){return this.set(t=>({filter:{...t.filter||{},fields:Array.isArray(e)?e:[]}}),t)}setFieldTypes(e=[],t="field-types"){return this.set(t=>({filter:{...t.filter||{},fieldTypes:Array.isArray(e)?e:[]}}),t)}getFieldTypes(){return Array.isArray(this.state.filter?.fieldTypes)?this.state.filter.fieldTypes:[]}getFieldCreateState(){return{open:!1,step:"type",entity:"task",selectedType:null,settings:{label:"",key:"",required:!1,multiple:!1,options:[{id:1,label:"Option 1"},{id:2,label:"Option 2"}]},...this.state.fieldCreate||{}}}getSelectedFieldType(){const e=this.getFieldCreateState();return this.getFieldTypes().find(t=>t?.id===e.selectedType)||null}getFieldTypeDefaultSettings(e){const t={};return Array.isArray(e?.settings)?(e.settings.forEach(e=>{e?.key&&void 0!==e.defaultValue&&(t[e.key]=e.defaultValue)}),t):t}getFieldSettingsPayload(e={}){const t=this.getFieldType(e),i=e.editor?.component?.props||{},n=Array.isArray(e.schema?.options)&&e.schema.options.length?e.schema.options:Array.isArray(e.filter?.options)&&e.filter.options.length?e.filter.options:Array.isArray(e.editor?.options)?e.editor.options:[];return{...e.settings||{},...e.schema?.settings||{},fieldType:t,label:e.label||e.schema?.label||e.key||"",key:e.key||e.schema?.key||"",required:Boolean(e.required||e.schema?.required),multiple:Boolean(e.multiple||e.schema?.multiple||e.editor?.component?.props?.multiple),defaultValue:e.defaultValue??e.schema?.defaultValue??null,placeholder:e.settings?.placeholder??e.schema?.settings?.placeholder??i.placeholder??"",accept:e.settings?.accept??e.schema?.settings?.accept??i.accept??"",format:e.settings?.format??e.schema?.settings?.format??i.format??"",min:e.settings?.min??e.schema?.settings?.min??i.min??"",max:e.settings?.max??e.schema?.settings?.max??i.max??"",options:n}}getFieldEditorPropsFromSettings(e={}){const t={};return["placeholder","accept","format","min","max"].forEach(i=>{""!==e[i]&&null!==e[i]&&void 0!==e[i]&&(t[i]=e[i])}),void 0!==e.multiple&&(t.multiple=Boolean(e.multiple)),t}getConfigurableField(e){if(!e)return null;return[...Array.isArray(this.state.detail?.fields)?this.state.detail.fields:[],...Array.isArray(this.state.filter?.fields)?this.state.filter.fields:[]].find(t=>t?.key===e)||null}canDeleteField(e){const t="string"==typeof e?this.getConfigurableField(e):e;return Boolean(t?.custom&&!1!==t?.permissions?.delete)}openFieldCreateModal(e={},t="field-create-open"){const i=e.entity||this.state.detail?.entity||"task";return this.set(t=>({fieldCreate:{...this.getFieldCreateState(),...t.fieldCreate||{},open:!0,mode:"create",step:"type",entity:i,fieldKey:null,selectedType:null,settings:{label:"",key:"",required:!1,multiple:!1,options:[{id:1,label:"Option 1"},{id:2,label:"Option 2"}]},...e||{}}}),t)}openFieldSettingsModal(e={},t="field-settings-open"){if(!e?.key)return this;const i=this.getFieldType(e);return this.set(t=>({fieldCreate:{...this.getFieldCreateState(),...t.fieldCreate||{},open:!0,mode:"edit",step:"settings",entity:this.state.detail?.entity||"task",fieldKey:e.key,selectedType:i,settings:this.getFieldSettingsPayload(e)}}),t)}closeFieldCreateModal(e="field-create-close"){return this.set(e=>({fieldCreate:{...e.fieldCreate||{},open:!1}}),e)}bindDetailModalEvents(){const e=this.refs.detailModal?.value;if(!e||this._detailModalBound?.modal===e)return;this.unbindDetailModalEvents();const t=()=>{this.set({modalOpen:!1,detail:{...this.state.detail||{},loading:!1}})};e.addEventListener("modal:after-close",t),this._detailModalBound={modal:e,afterClose:t}}unbindDetailModalEvents(){const e=this._detailModalBound;e?.modal?(e.modal.removeEventListener("modal:after-close",e.afterClose),this._detailModalBound=null):this._detailModalBound=null}bindFieldCreateModalEvents(){const e=this.refs.fieldCreateModal?.value;if(!e||this._fieldCreateModalBound?.modal===e)return;this.unbindFieldCreateModalEvents();const t=()=>{this.state.fieldCreate?.open&&this.closeFieldCreateModal("field-create-modal-after-close")};e.addEventListener("modal:after-close",t),this._fieldCreateModalBound={modal:e,afterClose:t}}unbindFieldCreateModalEvents(){const e=this._fieldCreateModalBound;e?.modal?(e.modal.removeEventListener("modal:after-close",e.afterClose),this._fieldCreateModalBound=null):this._fieldCreateModalBound=null}selectFieldCreateType(e,t="field-create-type"){const i=this.getFieldTypes().find(t=>t?.id===e)||null;return this.set(t=>({fieldCreate:{...t.fieldCreate||{},selectedType:e,step:"settings",settings:{...this.getFieldTypeDefaultSettings(i),...t.fieldCreate?.settings||{}}}}),t)}updateFieldCreateSetting(e,t,i="field-create-setting"){return e?this.set(i=>({fieldCreate:{...i.fieldCreate||{},settings:{...i.fieldCreate?.settings||{},[e]:t}}}),i):this}updateFieldCreateOption(e,t={},i="field-create-option"){return this.set(i=>{const n=Array.isArray(i.fieldCreate?.settings?.options)?[...i.fieldCreate.settings.options]:[],s=n[e]||{};return n[e]={...s,...t},{fieldCreate:{...i.fieldCreate||{},settings:{...i.fieldCreate?.settings||{},options:n}}}},i)}addFieldCreateOption(e="field-create-option-add"){return this.set(e=>{const t=Array.isArray(e.fieldCreate?.settings?.options)?[...e.fieldCreate.settings.options]:[],i=t.length+1;return{fieldCreate:{...e.fieldCreate||{},settings:{...e.fieldCreate?.settings||{},options:[...t,{id:i,label:`Option ${i}`}]}}}},e)}removeFieldCreateOption(e,t="field-create-option-remove"){return this.set(t=>{const i=Array.isArray(t.fieldCreate?.settings?.options)?t.fieldCreate.settings.options.filter((t,i)=>i!==e):[];return{fieldCreate:{...t.fieldCreate||{},settings:{...t.fieldCreate?.settings||{},options:i}}}},t)}emitFieldCreateRequest(e={},t="field-create-request"){const i={entity:this.state.detail?.entity||"task",tableSettingsKey:this.getTableSettingsKey(),fieldTypes:this.getFieldTypes(),fields:this.getDetailFields?.()||this.getFilterFields(),row:this.getDetailRow?.()||null,reason:t,...e||{}};return this.dispatchEvent(new CustomEvent("sf-table:field-create-request",{bubbles:!0,composed:!0,detail:i})),this.dispatchEvent(new CustomEvent("onFieldCreateRequest",{bubbles:!0,composed:!0,detail:i})),this.openFieldCreateModal(i),i}submitFieldCreate(e="field-create-submit"){const t=this.getFieldCreateState(),i=this.getSelectedFieldType(),n=t.settings||{},s=String(n.label||"").trim();if(!t.selectedType||!s)return null;if("edit"===t.mode)return this.submitFieldSettings(e);const a={entity:t.entity||this.state.detail?.entity||"task",tableSettingsKey:this.getTableSettingsKey(),fieldType:t.selectedType,typeConfig:i,settings:{...n,fieldType:t.selectedType,label:s},reason:e};return this.dispatchEvent(new CustomEvent("sf-table:field-create-submit",{bubbles:!0,composed:!0,detail:a})),this.dispatchEvent(new CustomEvent("onFieldCreateSubmit",{bubbles:!0,composed:!0,detail:a})),a}submitFieldSettings(e="field-settings-submit"){const t=this.getFieldCreateState(),i=this.getSelectedFieldType(),n=t.settings||{},s=String(n.label||"").trim();if(!t.fieldKey||!t.selectedType||!s)return null;const a={entity:t.entity||this.state.detail?.entity||"task",tableSettingsKey:this.getTableSettingsKey(),fieldKey:t.fieldKey,fieldType:t.selectedType,typeConfig:i,settings:{...n,fieldType:t.selectedType,key:t.fieldKey,label:s},reason:e};return this.applyFieldSettingsUpdate(a),this.dispatchEvent(new CustomEvent("sf-table:field-settings-submit",{bubbles:!0,composed:!0,detail:a})),this.dispatchEvent(new CustomEvent("onFieldSettingsSubmit",{bubbles:!0,composed:!0,detail:a})),a}submitFieldDelete(e="field-delete-submit"){const t=this.getFieldCreateState(),i=t.fieldKey||t.settings?.key;if(!i||!this.canDeleteField(i))return null;const n={entity:t.entity||this.state.detail?.entity||"task",tableSettingsKey:this.getTableSettingsKey(),fieldKey:i,field:this.getConfigurableField(i),reason:e};return this.dispatchEvent(new CustomEvent("sf-table:field-delete-submit",{bubbles:!0,composed:!0,detail:n})),this.dispatchEvent(new CustomEvent("onFieldDeleteSubmit",{bubbles:!0,composed:!0,detail:n})),n}applyFieldSettingsUpdate(e={},t="field-settings-applied"){const i=e.fieldKey||e.settings?.key,n=e.settings||{};if(!i)return this;const s=e=>{if(e?.key!==i)return e;const t=this.getFieldEditorPropsFromSettings(n);return{...e,label:n.label||e.label,required:Boolean(n.required),multiple:Boolean(n.multiple),settings:{...e.settings||{},...n},schema:{...e.schema||{},label:n.label||e.schema?.label||e.label,required:Boolean(n.required),multiple:Boolean(n.multiple),options:Array.isArray(n.options)?n.options:e.schema?.options,settings:{...e.schema?.settings||{},...n}},filter:{...e.filter||{},...Array.isArray(n.options)?{options:n.options}:{}},editor:{...e.editor||{},...Array.isArray(n.options)?{options:n.options}:{},component:e.editor?.component?{...e.editor.component||{},props:{...e.editor.component?.props||{},...Array.isArray(n.options)?{items:n.options}:{},...t}}:e.editor?.component}}};return this.set(e=>({detail:{...e.detail||{},fields:Array.isArray(e.detail?.fields)?e.detail.fields.map(s):[]},filter:{...e.filter||{},fields:Array.isArray(e.filter?.fields)?e.filter.fields.map(s):[]}}),t),this.closeFieldCreateModal(t),this}applyCreatedFieldResponse(e={},t="field-create-applied"){if(Array.isArray(e.fieldTypes)&&this.setFieldTypes(e.fieldTypes,t),Array.isArray(e.fields)){const i=e.entity||this.state.detail?.entity||"task";"task"===i&&this.setFilterFields(e.fields,t),this.state.modalOpen&&this.state.detail?.entity===i&&this.setDetailData({...this.state.detail||{},row:this.getDetailRow(),fields:e.fields,viewSettings:e.viewSettings||this.state.detail?.viewSettings},t)}return Array.isArray(e.columns)&&this.setColumns(e.columns,t),this.closeFieldCreateModal(t),this}applyDeletedFieldResponse(e={},t="field-delete-applied"){if(Array.isArray(e.fieldTypes)&&this.setFieldTypes(e.fieldTypes,t),Array.isArray(e.fields)){const i=e.entity||this.state.detail?.entity||"task";if("task"===i&&this.setFilterFields(e.fields,t),this.state.modalOpen&&this.state.detail?.entity===i){const i=e.item||this.getDetailRow();this.setDetailData({...this.state.detail||{},row:i,fields:e.fields,viewSettings:e.viewSettings||this.state.detail?.viewSettings},t)}}return Array.isArray(e.columns)&&this.setColumns(e.columns,t),this.closeFieldCreateModal(t),this}patchTempColumnSettings(e,t={}){e&&(this.tempSettings={...this.tempSettings||{},cols:{...this.tempSettings?.cols||{},[e]:{...this.tempSettings?.cols?.[e]||{},..."function"==typeof t?t():t}}})}patchTempFilterTagSettings(e,t={}){e&&(this.tempSettings={...this.tempSettings||{},filter:{...this.tempSettings?.filter||{},tags:{...this.tempSettings?.filter?.tags||{},[e]:{...this.tempSettings?.filter?.tags?.[e]||{},..."function"==typeof t?t():t}}}})}patchTempFilterFieldSettings(e,t={}){e&&(this.tempSettings={...this.tempSettings||{},filterFields:{...this.tempSettings?.filterFields||{},[e]:{...this.tempSettings?.filterFields?.[e]||{},..."function"==typeof t?t():t}}})}patchTempFilterValue(e,t={}){if(!e)return;const i=this.getCurrentFilterValues(this.getPendingFilterState()),n=this.tempSettings?.filter?.values?.[e]||i[e]||{},s="function"==typeof t?t(n):t,a={...n,...s||{}};Object.keys(a).some(e=>{return t=n[e],i=a[e],!(Array.isArray(t)&&Array.isArray(i)?t.length===i.length&&t.every((e,t)=>Object.is(e,i[t])):Object.is(t,i));var t,i})&&(this.tempSettings={...this.tempSettings||{},filter:{...this.tempSettings?.filter||{},values:{...this.tempSettings?.filter?.values||{},[e]:a}}},this.requestComponentUpdate("temp-filter-value"))}isEmptyFilterValue(e){return null==e||(Array.isArray(e)?e.every(e=>this.isEmptyFilterValue(e)):"string"==typeof e?""===e.trim():!(!e||"object"!=typeof e)&&Object.values(e).every(e=>this.isEmptyFilterValue(e)))}isEmptyFilterEntry(e){return e&&"object"==typeof e?Object.prototype.hasOwnProperty.call(e,"values")?this.isEmptyFilterValue(e.values):Object.prototype.hasOwnProperty.call(e,"value")?this.isEmptyFilterValue(e.value):Object.entries(e).filter(([e])=>!["operator","control","type"].includes(e)).every(([,e])=>this.isEmptyFilterValue(e)):this.isEmptyFilterValue(e)}mergeFilterState(e={},t={}){const{filter:i,tags:n,values:s}=this.getMergedFilterDraftData(e,t);return this.patchFilterTemplateData(i,{tags:n,values:s})}getColumnCheckboxItems(e={}){const{checked:t,onChange:i,refPrefix:n="column"}=e;return this.getColumnItems().map(e=>{const s={type:"checkbox",props:{size:1,label:e.label,position:"end",rootClass:"content-main-between",checked:"function"==typeof t?Boolean(t(e)):Boolean(t),":ref":this.getItemRef(`${n}:${e.key}`)||!1,"@change":t=>{i?.(e,t)}}};return SF.litHtml(s.type,s.props)})}getTableColsData(){return this.getColumnCheckboxItems({refPrefix:"table-column",checked:e=>{const t=this.tempSettings?.cols?.[e.key],i=this.getColumnSetting(e.key);return t?.visible??i.visible??!1!==e.visible},onChange:(e,t)=>{this.patchTempColumnSettings(e.key,{visible:Boolean(t.target?.checked)})}})}getFilterTagColsData(){const e=this.getFilterFields().filter(e=>!1!==e?.filter?.enabled);return(e.length?e:this.getColumnItems()).map(e=>{const t=this.tempSettings?.filter?.tags?.[e.key],i=this.getCurrentFilterTags(this.getPendingFilterState())?.[e.key],n={type:"checkbox",props:{size:1,label:e.label,position:"end",rootClass:"content-main-between",checked:t?.active??i?.active??!1,":ref":this.getItemRef(`filter-tag-column:${e.key}`)||!1,"@change":t=>{this.patchTempFilterTagSettings(e.key,{active:Boolean(t.target?.checked),label:e.label,control:this.getFieldFilterControl(e)})}}};return SF.litHtml(n.type,n.props)})}getFilterFieldSettings(){return this.getFilterFields().reduce((e,t,i)=>t?.key?(e[t.key]=this.normalizeFilterFieldSetting(t,i),e):e,{})}normalizeFilterFieldSetting(e={},t=0,i={}){return{visible:!1!==e.visible,order:"number"==typeof e.order?e.order:10*(t+1),control:this.getFieldFilterControl(e),...i||{}}}applyFilterFieldSettingsToFields(e=[],t={}){return e.map((e,i)=>{if(!e?.key)return e;const n=this.normalizeFilterFieldSetting(e,i,t[e.key]||{});return{...e,...n,filter:{...e.filter||{},control:n.control}}}).sort((e,t)=>("number"==typeof e?.order?e.order:0)-("number"==typeof t?.order?t.order:0))}emitFilterFieldSettingsChange(e="filter-field-settings"){const t={reason:e,filterFieldSettings:this.getFilterFieldSettings(),tableSettingsKey:this.getTableSettingsKey()};return this.dispatchEvent(new CustomEvent("sf-table:filter-field-settings-change",{bubbles:!0,composed:!0,detail:t})),this.dispatchEvent(new CustomEvent("onFilterFieldSettingsChange",{bubbles:!0,composed:!0,detail:t})),this}getFilterFieldSettingsData(){return this.getFilterFields().filter(e=>!1!==e?.filter?.enabled).map((e,t)=>{const i=this.tempSettings?.filterFields?.[e.key],n=this.normalizeFilterFieldSetting(e,t),s={type:"checkbox",props:{size:1,label:e.label,position:"end",rootClass:"content-main-between",checked:i?.visible??n.visible,":ref":this.getItemRef(`filter-field:${e.key}`)||!1,"@change":t=>{this.patchTempFilterFieldSettings(e.key,{...n,visible:Boolean(t.target?.checked)})}}};return SF.litHtml(s.type,s.props)})}getFilterControlValue(e){return{...this.getCurrentFilterValues()?.[e]||{},...this.tempSettings?.filter?.values?.[e]||{}}}getFilterOptions(e={}){const t=e.filter||{},i=t.optionsSource||{};return Array.isArray(t.options)?t.options:Array.isArray(i.items)?i.items:[]}getFilterOptionSearch(e){return e&&this.tempSettings?.filterSearch?.[e]||""}patchTempFilterOptionSearch(e,t=""){e&&(this.tempSettings={...this.tempSettings||{},filterSearch:{...this.tempSettings?.filterSearch||{},[e]:String(t||"")}},this.requestComponentUpdate("filter-option-search"))}filterUpdate(){return this.getFilterPayload()}getFilterOptionSearchKeys(e={}){const t=e.filter?.searchKeys||e.filter?.optionSearchKeys;return Array.isArray(t)&&t.length?t:["label","title","name","text","value","id"]}getObjectPathValue(e={},t=""){return String(t||"").split(".").filter(Boolean).reduce((e,t)=>null==e?"":e[t],e)}normalizeFilterSearchValue(e=""){return String(e||"").trim().toLowerCase()}optionMatchesSearch(e={},t="",i=[]){const n=this.normalizeFilterSearchValue(t);return!n||i.some(t=>{const i=this.getObjectPathValue(e,t);return this.normalizeFilterSearchValue(i).includes(n)})}getVisibleFilterOptions(e={}){const t=this.getFilterOptions(e),i=this.getFilterOptionSearch(e.key);if(!i)return t;const n=this.getFilterOptionSearchKeys(e);return t.filter(e=>this.optionMatchesSearch(e,i,n))}renderFilterControl(e={}){const t={text:()=>this.renderTextFilterControl(e),number:()=>this.renderNumberFilterControl(e),date:()=>this.renderDateFilterControl(e),range:()=>this.renderRangeFilterControl(e),"date-range":()=>this.renderDateFilterControl(e),"multi-select":()=>this.renderMultiSelectFilterControl(e),"single-select":()=>this.renderMultiSelectFilterControl(e),"entity-multi-select":()=>this.renderEntityMultiSelectFilterControl(e),"entity-single-select":()=>this.renderEntityMultiSelectFilterControl(e)};return(t[this.getFieldFilterControl(e)]||t.text)()}renderTextFilterControl(e={}){const t=this.getFilterControlValue(e.key);return n`
            <sf-input
                    size="1"
                    type="filled"
                    placeholder="Найти в списке"
                    value="${t.value||""}"
                    name="sf_filter_${e.key||"text"}"
                    @change=${i=>{this.patchTempFilterValue(e.key,{value:i.target?.value||"",operator:t.operator||e.filter?.defaultOperator||"contains"})}}
            ></sf-input>
        `}renderRangeFilterControl(e={}){const t=this.getFilterControlValue(e.key),i=e.filter?.operators||["eq"],s=t.operator||e.filter?.defaultOperator||i[0],a="between"===s,l=a?t.value:Array.isArray(t.value)?t.value[0]:t.value;return n`
            <div class="flex gap-1/3 flex-col">
                <div class="sf-filter-operator-range flex gap-1/3 items-cross-center">
                    <sf-range-slider
                            id="smart-range-slider-single"
                            min="0"
                            label="tooltip"
                            suffix="%"
                            max="100"
                            multiple=${String(a)}
                            .value=${l}
                            @onSliderEnd=${t=>{this.patchTempFilterValue(e.key,{value:a?t.detail.values||[]:t.detail.value,operator:s})}}
                    ></sf-range-slider>
                </div>
                <sf-dropdown
                        size="1"
                        type="outlined"
                        mode="select"
                        placeholder="Оператор"
                        root-class="flex-1"
                        search="false"
                        @sf-dropdown:change=${t=>{const i=t.detail?.values?.[0]||t.detail?.value||s;this.patchTempFilterValue(e.key,{operator:i})}}
                >
                    ${i.map(e=>n`
                        <sf-list-item
                                type="text"
                                size="1"
                                text="${this.getFilterOperatorLabel(e)}"
                                value="${e}"
                                ?selected=${e===s}
                        ></sf-list-item>
                    `)}
                </sf-dropdown>
            </div>
        `}renderNumberFilterControl(e={}){const t=this.getFilterControlValue(e.key),i=e.filter?.operators||["eq"],a=t.operator||e.filter?.defaultOperator||i[0],l="between"===a,r=t.value,o=Array.isArray(r)?r:[r||"",""],c=(t,i)=>{if(!l)return void this.patchTempFilterValue(e.key,{value:i||"",operator:a});const n=[...o];n[t]=i||"",this.patchTempFilterValue(e.key,{value:n,operator:a})};return n`
            <div class="flex gap-1/3 flex-col">
                <div class="sf-filter-operator-inputs flex gap-1/3 items-cross-center">
                    <sf-input
                            size="1"
                            type="bordered"
                            root-class="flex-1 min-w-0"
                            label="${l?"От":this.getFilterOperatorLabel(a)}"
                            value="${l?o[0]||"":r||""}"
                            name="sf_filter_${e.key||"number"}"
                            @change=${e=>{c(0,e.target?.value)}}
                    ></sf-input>
                    ${l?n`
                        <sf-input
                                size="1"
                                type="bordered"
                                label="До"
                                root-class="flex-1 min-w-0"
                                value="${o[1]||""}"
                                name="sf_filter_${e.key||"number"}_second"
                                @change=${e=>{c(1,e.target?.value)}}
                        ></sf-input>`:s}
                </div>
                <sf-dropdown
                        size="1"
                        type="outlined"
                        mode="select"
                        placeholder="Оператор"
                        root-class="flex-1"
                        search="false"
                        @sf-dropdown:change=${t=>{const i=t.detail?.values?.[0]||t.detail?.value||a;this.patchTempFilterValue(e.key,{operator:i})}}
                >
                    ${i.map(e=>n`
                        <sf-list-item
                                type="text"
                                size="1"
                                text="${this.getFilterOperatorLabel(e)}"
                                value="${e}"
                                ?selected=${e===a}
                        ></sf-list-item>
                    `)}
                </sf-dropdown>
            </div>
        `}renderDateFilterControl(e={}){const t=this.getFilterControlValue(e.key),i=e.filter?.operators||["eq"],s=t.operator||e.filter?.defaultOperator||i[0],a="between"===s,l=a&&Array.isArray(t.value)?t.value:a?["",""]:t.value||"";return n`
            <div class="flex flex-col gap-1/3">
                <sf-datepicker
                        .value=${l}
                        ?range=${a}
                        name="sf_filter_${e.key||"date"}"
                        locale="ru-Ru"
                        @change=${t=>{this.patchTempFilterValue(e.key,{value:t.detail.value,operator:s})}}
                ></sf-datepicker>
                <sf-dropdown
                        size="1"
                        type="outlined"
                        mode="select"
                        placeholder="Оператор"
                        root-class="flex-1"
                        search="false"
                        @sf-dropdown:change=${t=>{const i=t.detail?.values?.[0]||t.detail?.value||s;this.patchTempFilterValue(e.key,{operator:i})}}
                >
                    ${i.map(e=>n`
                        <sf-list-item
                                type="text"
                                size="1"
                                text="${this.getFilterOperatorLabel(e)}"
                                value="${e}"
                                ?selected=${e===s}
                        ></sf-list-item>
                    `)}
                </sf-dropdown>
            </div>
        `}renderMultiSelectFilterControl(e={}){const t=this.getVisibleFilterOptions(e),i=this.getFilterControlValue(e.key),s=this.getFilterOptionSearch(e.key),a=new Set(i.values||[]);return n`
            <div class="flex flex-col gap-1/2">
                ${e.filter?.searchable?n`
                    <sf-input
                            size="1"
                            type="filled"
                            placeholder="Найти в списке"
                            value="${s}"
                            name="sf_filter_${e.key||"list"}_search"
                            @input=${t=>{this.patchTempFilterOptionSearch(e.key,t.target?.value||"")}}
                            @change=${t=>{this.patchTempFilterOptionSearch(e.key,t.target?.value||"")}}
                    ></sf-input>
                `:""}
                <div class="flex flex-col gap-1/2 шеуьы" data-size="4.5">
                    ${t.map(t=>this.renderFilterOption(e,t,a))}
                </div>
            </div>
        `}renderEntityMultiSelectFilterControl(e={}){return this.renderMultiSelectFilterControl(e)}renderFilterOption(e={},t={},i=new Set){const s=t.value??t.id??t.key??t.label??t.title,a=t.label||t.title||String(s||"");return n`
            <div
                    :ref=${this.getItemRef(t.label)||!1}
                    class="flex items-cross-center gap-1/2 content-main-between">
                <div class="flex items-cross-center gap-1/2 min-w-0">
                    ${this.renderFilterOptionVisual(e,t)}
                    <span class="sf-text-1 truncate">${a}</span>
                </div>
                <sf-checkbox
                        size="1"
                        position="end"
                        root-class="content-main-between"
                        ?checked=${i.has(s)}
                        @change=${t=>{const n=new Set(i);t.target?.checked?n.add(s):n.delete(s),this.patchTempFilterValue(e.key,{values:Array.from(n),operator:e.filter?.defaultOperator||"in"})}}
                ></sf-checkbox>
            </div>
        `}renderFilterOptionVisual(e={},t={}){return"avatar-checkbox"!==e.filter?.optionRenderer?"":t.imageUrl?n`
                <sf-avatar
                        size="1"
                        image-url="${t.imageUrl}"
                        title="${t.title||t.label||""}"
                ></sf-avatar>
            `:n`
            <sf-avatar
                    size="1"
                    title="${t.avatarText||t.title||t.label||""}"
            ></sf-avatar>
        `}getFilterOperatorLabel(e){return{eq:"Точно",gt:"Больше чем",gte:"Больше или равно",lt:"Меньше чем",lte:"Меньше или равно",between:"Диапазон",contains:"Содержит",startsWith:"Начинается с",any:"Любая дата",today:"Сегодня",week:"Неделя",month:"Месяц",in:"В списке"}[e]||e}renderFilterSettingsContextMenu(e){const{x:t,y:i,position:a,transform:l}=e;let r=`translateX(${void 0!==l?l:0}%)`;const o=this.getPendingFilterState(),c=o.selectedTemplateKey,d=this.getSortedFilterTemplates(o).map(e=>{let t;const i=this.state.filter.rename===e.key;if(this.state.filter.rename!==e.key){const i={type:"radio",props:{size:1,label:e.label,name:"filter_templates",checked:c?c===e.key:e.selected||!1,"@change":()=>{this.selectTempFilterTemplate(e.key)}}};t=SF.litHtml(i.type,i.props)}else t=n`
                    <div class="flex items-cross-center gap-1/4 flex-1">
                        <sf-input :ref=${this.refs.renameInput} root-class="flex-1"
                                  default-value="${e.label}"></sf-input>
                        <div class="flex items-cross-center flex-none">
                            <sf-icon-button segment="start" type="outline" scheme="on-surface" @click="${()=>{this.set(e=>({filter:{...e.filter||{},rename:""}}))}}"
                                            icon="close"></sf-icon-button>
                            <sf-icon-button segment="end" icon="check" @click="${()=>{const t=this.refs.renameInput.value?.value;this.saveFilterTemplatePatch(e.key,{label:t},{filterPatch:{rename:""},saveInputValue:t})}}"></sf-icon-button>
                        </div>
                    </div>`;return n`
                <div
                        :key=${e.key}
                        :ref=${this.getItemRef(e.label)||!1}
                        class="sf-settings-context-menu-item flex items-cross-center flex-1 gap-1/3 ${e.deleted?"opacity-3":""}"
                        data-filter-template-key="${e.key}"
                        data-pinned="${e.pinned?"1":"0"}"
                >
                    ${i?s:n`
                        <sf-icon-button
                                id="${e.label}_move"
                                type="link"
                                data-move
                                scheme="on-surface"
                                aria-label="Set order"
                                icon="drag_indicator"
                                root-class="cursor-move"
                        ></sf-icon-button>`}
                    ${t}
                    ${i?s:n`
                        <div class="flex items-cross-center m-inline-start-auto gap-1/3">
                            <sf-icon-button
                                    type="link"
                                    data-keep
                                    size="1/3"
                                    scheme="on-surface"
                                    aria-label="Keep item"
                                    ?filled="${e.pinned}"
                                    root-class="${e.pinned?"sf-button-pinned":""}"
                                    icon="keep"
                                    @click=${()=>{this.patchTempFilterTemplateSettings(e.key,{pinned:!e.pinned})}}
                            ></sf-icon-button>
                            <sf-icon-button
                                    type="link"
                                    data-settings
                                    data-context-submenu-anchor="${e.key}"
                                    scheme="on-surface"
                                    aria-label="Item Settings"
                                    icon="more_vert"
                                    @click=${t=>{this.openContextSubmenu(t,{type:"filter-template-actions",template:e})}}
                            ></sf-icon-button>
                        </div>`}
                </div>`}),u=this.getFilterTagColsData();return n`
            <sf-context-menu
                    :key=${t+i+this._renderToken}
                    style="
            position: fixed;
            inset-inline-start: ${t}px;
            inset-block-start: calc(${i}px + calc(var(--sf-focus-outline-width) * 2));
            transform: ${r};
            z-index: 9998;
          "
                    root-class="sf-table-context-menu flex flex-col"
                    position="${a||""}"
            >
                <div class="flex flex-col flex-1" slot="content">
                    <sf-tabs items="${"Шаблоны|Поля"}" type="underline" lazy>
                        <div slot="panel-0" class="flex">
                            <sf-list
                                    root-class="sf-context-menu-columns flex-1"
                                    max-items="8"
                                    gap="1/4"
                                    data-filter-template-list
                            >
                                ${d.map(e=>n`<div slot="items">${e}</div>`)}
                            </sf-list>
                        </div>
                        <div slot="panel-1" class="flex">
                            <sf-list
                                    root-class="sf-context-menu-columns flex-1"
                                    max-items="8"
                                    gap="1"
                            >
                                ${u.map(e=>n`<div slot="items">${e}</div>`)}
                            </sf-list>
                        </div>

                    </sf-tabs>
                    <div class="sf-table-context-bottom flex gap-1/3">
                        <sf-button @click="${()=>{this.tempSettings=null,this.requestComponentUpdate("table")}}" type="outline" scheme="on-surface" root-class="flex-1"
                                   text="Сбросить"></sf-button>
                        <sf-button @click="${()=>{const e=this.tempSettings?.filter;if(e){let t=[];this.set(i=>{const n=this.hasPendingFilterDataChanges(i.filter||{}),s=this.mergeFilterState(i.filter||{},e),a=this.getSelectedFilterTemplate(s);return t=e.templates?this.getChangedFilterTemplates(i.filter||{},s,["order","pinned","deleted","selected","default"]):[],s.templates=s.templates.filter(e=>!e.deleted),{filter:s,filterDataDirty:i.filterDataDirty||n,saveInputValue:a?.label||""}},()=>{t.length&&this.dispatchFilterTemplatesSave(t)})}this.tempSettings=null,this.closeContextMenu()}}" root-class="flex-1" text="Применить"></sf-button>
                    </div>
                </div>
            </sf-context-menu>
        `}renderTagsSettingsContextMenu(e){const{x:t,y:i,position:s,fieldKey:a}=e,l=this.getFilterField(a)||{key:a,label:this.getCurrentFilterTags()?.[a]?.label||a||"",filter:{control:this.getCurrentFilterTags()?.[a]?.control||"text"}};return n`
            <sf-context-menu
                    :key=${t+i+this._renderToken}
                    style="
            position: fixed;
            inset-inline-start: ${t}px;
            inset-block-start: calc(${i}px + calc(var(--sf-focus-outline-width) * 2));
            z-index: 9998;
          "
                    root-class="sf-table-context-menu flex flex-col"
                    position="${s||""}"
            >
                <div class="flex flex-col flex-1 p-top-3" slot="content">
                    <div class="sf-table-context-main">
                        <div class="sf-table-tags-search flex flex-col">
                            <div class="flex flex-col p-bottom-3">
                                ${this.renderFilterControl(l)}
                            </div>
                        </div>
                    </div>
                    <div class="sf-table-context-bottom flex gap-1/3">
                        <sf-button @click="${()=>{this.tempSettings=null,this.requestComponentUpdate("table")}}" type="outline" scheme="on-surface" root-class="flex-1"
                                   text="Сбросить"></sf-button>
                        <sf-button @click="${()=>{const e=this.tempSettings?.filter;e&&this.set(t=>{const i=this.hasPendingFilterDataChanges(t.filter||{});return{filter:this.mergeFilterState(t.filter||{},e),filterDataDirty:t.filterDataDirty||i}},()=>{this.dispatchEvent(new CustomEvent("onFilterUpdate",{bubbles:!0,composed:!0,detail:this.filterUpdate()}))}),this.tempSettings=null,this.closeContextMenu()}}" root-class="flex-1" text="Применить"></sf-button>
                    </div>
                </div>
            </sf-context-menu>
        `}removeFilterTag(e=null){return e?(this.tempSettings=null,this.set(t=>{const i=t.filter||{},n={...this.getCurrentFilterTags(i)},s={...this.getCurrentFilterValues(i)};return delete n[e],delete s[e],{filter:this.patchFilterTemplateData(i,{tags:n,values:s}),filterDataDirty:!0}},()=>{this.dispatchEvent(new CustomEvent("onFilterUpdate",{bubbles:!0,composed:!0,detail:this.filterUpdate()}))}),this):(this.tempSettings=null,this.set(e=>{const t=e.filter||{};return{filter:{...t,selectedTemplateKey:"",templates:this.getFilterTemplates(t).map(e=>({...e,selected:!1}))},saveInputValue:"",filterDataDirty:!1}},()=>{this.dispatchEvent(new CustomEvent("onFilterUpdate",{bubbles:!0,composed:!0,detail:this.filterUpdate()}))}),this)}renderTableSettingsContextMenu(e){const{x:t,y:i,position:s,transform:a}=e;let l=`translateX(${void 0!==a?a:0}%)`;const r=this.getTableColsData(),o=this.state.actions.length>0;let c="Поля",d=[];return o&&(c+="|Действия",d=this.getActionItems()),n`
            <sf-context-menu
                    :key=${t+i+this._renderToken}
                    style="
            position: fixed;
            inset-inline-start: ${t}px;
            inset-block-start: calc(${i}px + calc(var(--sf-focus-outline-width) * 2));
            transform: ${l};
            z-index: 9998;
          "
                    root-class="sf-table-context-menu flex flex-col"
                    position="${s||""}"
            >
                <div class="flex flex-col flex-1" slot="content">
                    <sf-tabs items="${c}" type="underline" lazy>
                        <div slot="panel-0" class="flex gap-1">
                            <sf-list
                                    root-class="sf-context-menu-columns flex-1"
                                    max-items="8"
                                    gap="1"
                            >
                                ${r.map(e=>n`<div slot="items">${e}</div>`)}
                            </sf-list>
                        </div>
                        ${o?n`
                                    <div slot="panel-1">
                                        <sf-list
                                                root-class="sf-context-menu-columns flex-1"
                                                max-items="8"
                                                gap="1"
                                        >
                                            ${d.map(e=>n`<div slot="items">${e}</div>`)}
                                        </sf-list>
                                    </div>`:""}
                    </sf-tabs>
                    <div class="sf-table-context-bottom flex gap-1/3">
                        <sf-button @click="${()=>{this.tempSettings=null,this.requestComponentUpdate("table")}}" type="outline" scheme="on-surface" root-class="flex-1"
                                   text="Сбросить"></sf-button>
                        <sf-button @click="${()=>{const e=this.tempSettings||{},{cols:t,...i}=e,n={...i};t&&(n.columnSettings=this.mergeColumnSettings(this.getColumnSettings(),t)),this.set(e=>({...e,...n}),"table-settings",()=>{t&&this.emitColumnSettingsChange("table-settings")}),this.tempSettings=null}}" root-class="flex-1" text="Применить"></sf-button>
                    </div>
                </div>
            </sf-context-menu>
        `}renderMainContextMenu(e){switch(e.menu||e.menuType||e.contextMenu){case"row-settings":return this.renderRowSettingsContextMenu(e);case"filter-favorites":return this.renderFilterFavoritesContextMenu(e);case"filter-settings":return this.renderFilterSettingsContextMenu(e);case"table-settings":return this.renderTableSettingsContextMenu(e);case"tag-settings":return this.renderTagsSettingsContextMenu(e);default:return"left"===e.type?this.renderRowSettingsContextMenu(e):this.renderTableSettingsContextMenu(e)}}renderTemplateActionsContextSubmenu(e){const{x:t,y:i,position:s,transform:a,template:l={}}=e;let r=`translateY(${void 0!==a?a:0}%)`;const o=this.getFilterTemplateByKey(l.key,this.tempSettings?.filter||null);let c=(o||l).deleted;const d=!0===(o||l).default;return n`
            <sf-context-menu
                    :key=${`${l.key||""}-${t}-${i}`}
                    style="
          position: fixed;
        inset-inline-start: calc(${t}px + var(--sf-context-menu-tail-corner-offset));
            inset-block-start: ${i}px;
          z-index: 9999;
          transform: ${r}
        "
                    data-context-submenu
                    root-class="sf-table-context-submenu flex flex-col"
                    position="${s||"right"}"
            >
                <div class="flex flex-col flex-1" slot="content">
                    <sf-button type="link" scheme="on-surface" icon-left="edit" text="Переименовать" @click="${()=>{this.set(e=>({filter:{...e.filter||{},rename:l.key},contextMenu:{...e.contextMenu||{},submenu:null}}))}}"></sf-button>
                    <sf-button type="link" scheme="on-surface" icon-left="${d?"remove":"check"}"
                               text="${d?"По умолчанию":"Сделать по умолчанию"}" @click="${()=>{this.changeTempFilterTemplateSettings(l.key,{default:!l.default}),this.closeContextSubmenu()}}"></sf-button>
                    <sf-button type="link" scheme="on-surface" icon-left="delete" @click="${()=>{this.patchTempFilterTemplateSettings(l.key,{deleted:!c})}}" text="${c?"Восстановить":"Удалить"}"></sf-button>
                </div>
            </sf-context-menu>
        `}renderContextSubmenu(e){return"filter-template-actions"===e?.type?this.renderTemplateActionsContextSubmenu(e):s}renderContextMenu(e){return e?.open?(a(n`
                <div
                        class="sf-table-context-layer"
                        :ref=${this.refs.contextMenu}
                        @click=${e=>this.handleContextLayerClick(e)}
                >
                    ${this.renderMainContextMenu(e)}
                    ${e.submenu?.open?this.renderContextSubmenu(e.submenu):s}
                </div>
            `,this.getPortalContainer()),this.bindContextEvent(),requestAnimationFrame(()=>this.bindFilterTemplateDrag()),s):(a(null,this.getPortalContainer()),s)}openRowDetail(e={},t={}){const i=t.entity||e.detailEntity||e.entity||e.type||"task";return this.set({modalOpen:!0,detail:{...this.state.detail||{},loading:!0,row:e,entity:i}},"row-detail-open",()=>{const t={row:e,entity:i,detailEntity:i,tableSettingsKey:this.getTableSettingsKey()};this.dispatchEvent(new CustomEvent("sf-table:row-detail-request",{bubbles:!0,composed:!0,detail:t})),this.dispatchEvent(new CustomEvent("onRowDetailRequest",{bubbles:!0,composed:!0,detail:t}))}),this}openEntityDetail(e,t={}){return e&&t?this.openRowDetail(t,{entity:e}):this}setDetailData(e={},t="row-detail"){return this.set({detail:{...this.state.detail||{},loading:!1,entity:e.entity||e.detailEntity||this.state.detail?.entity||"task",title:e.title||e.detailTitle||e.headerTitle||null,heading:e.heading||e.detailHeading||e.title||e.detailTitle||null,row:e.row||null,fields:Array.isArray(e.fields)?e.fields:[],viewSettings:e.viewSettings||null,editedFields:{},tempFields:{}}},t)}setDetailFieldEdited(e,t=!0,i="detail-field-edited"){return e?this.set(i=>{const n=i.detail||{},s={...n.editedFields||{},[e]:Boolean(t)};return{detail:{...n,editedFields:s}}},i):this}setAllDetailFieldsEdited(e=!0,t="detail-fields-edited"){return this.set(t=>{const i=t.detail||{},n=(Array.isArray(i.fields)?i.fields:[]).reduce((t,i)=>i?.key&&!1!==i?.editor?.enabled?(t[i.key]=Boolean(e),t):t,{});return{detail:{...i,editedFields:n}}},t)}bindDetailFieldDrag(){const e=this.refs.fieldList.value;e&&requestAnimationFrame(()=>{e.querySelectorAll("[data-detail-field-key]").forEach(t=>{Et({handle:t.querySelector("[data-move]"),item:t,container:e,boundAttr:"data-sf-table-detail-field-drag-bound",placeholderExtraClasses:["sf-table-detail-field-drag-placeholder"],getSortableItems:e=>this.getDetailFieldSortableItems(e),getAfterElement:(e,t,i,n)=>Dt(e,t,{itemsLayout:Array.isArray(n)?n.filter(e=>this.isDetailFieldSortableItem(e.item)):null,accept:e=>this.isDetailFieldSortableItem(e)}),onDrop:()=>{this.syncDetailFieldOrderFromContainer(e)}})})})}isDetailFieldSortableItem(e){return e instanceof HTMLElement&&Boolean(e.dataset.detailFieldKey)&&"true"===e.dataset.detailFieldDraggable&&!e.classList.contains("is-dragging")&&!e.classList.contains("drag-placeholder")}getDetailFieldSortableItems(e){return Array.from(e?.children||[]).filter(e=>this.isDetailFieldSortableItem(e))}syncDetailFieldOrderFromContainer(e){const t=Array.from(e?.children||[]).filter(e=>e instanceof HTMLElement&&e.dataset.detailFieldKey&&!e.classList.contains("drag-placeholder")).map(e=>e.dataset.detailFieldKey).filter(Boolean);if(!t.length)return this;const i={...this.getDetailFieldSettings()};return t.forEach((e,t)=>{i[e]={...i[e]||{},order:10*(t+1)}}),this.set(e=>{const t=e.detail||{},n=t.viewSettings||{};return{detail:{...t,viewSettings:{...n,detail:{...n.detail||{},fields:i}}}}},"detail-field-order"),this.emitDetailFieldSettingsChange(i,"detail-field-order"),this}emitDetailFieldSettingsChange(e=this.getDetailFieldSettings(),t="detail-field-settings"){const i={reason:t,detailFieldSettings:e,tableSettingsKey:this.getTableSettingsKey(),entity:this.state.detail?.entity||"task"};return this.dispatchEvent(new CustomEvent("sf-table:detail-field-settings-change",{bubbles:!0,composed:!0,detail:i})),this.dispatchEvent(new CustomEvent("onDetailFieldSettingsChange",{bubbles:!0,composed:!0,detail:i})),this}async getFieldData(e){const t=e.editor?.optionsSource?.url;if(t){const e=new URL(t,window.location.origin),i=await fetch(e.toString());return!!i.ok&&await i.json()}return!1}normalizeDetailDropdownOptionType(e="text"){const t=String(e||"").toLowerCase();return["text","icon","checkbox","avatar","color"].includes(t)?t:"text"}getDetailDropdownOptionType(e={}){const t=e.editor||{},i=t.component?.props||{};return this.normalizeDetailDropdownOptionType(t.optionType||t.itemType||i.optionType||i.itemType||i.listItemType||"text")}getDetailDropdownOptionValue(e){return e&&"object"==typeof e?e.value??e.id??e.key??e.label??e.title??e.name??"":e??""}getDetailDropdownOptionText(e){return e&&"object"==typeof e?e.text??e.label??e.title??e.name??e.value??e.id??"":e??""}createDetailDropdownOptionItem(e,t,i=[]){const n=this.getDetailDropdownOptionType(e),s=this.getDetailDropdownOptionValue(t),a=this.getDetailDropdownOptionText(t),l=t&&"object"==typeof t?t:{};return{...l,text:a,label:l.label??a,selected:i.includes(String(s)),type:this.normalizeDetailDropdownOptionType(l.itemType||l.listItemType||n),value:s,avatarImageUrl:l.avatarImageUrl||l.imageUrl||l.avatar||l.image||"",avatarTitle:l.avatarTitle||l.label||l.title||l.name||a,template:l.template||("avatar"===n?"label":"default"),size:l.size||1}}getDetailDropdownSourceItems(e,t){return[t?.data?.items,Array.isArray(t?.data)?t.data:null,e.editor?.options,e.editor?.component?.props?.options,t?.items].find(e=>Array.isArray(e)&&e.length)||[]}getDetailDropdownOptions(e,t,i=[]){const n=this.getDetailDropdownSourceItems(e,t);return(Array.isArray(n)?n:[]).map(t=>this.createDetailDropdownOptionItem(e,t,i))}setEditorData(e,t){const i=this.getEditorData(e.key),s=this.getFieldEditorComponentType(e),a=e.editor?.component?.props?.name||`sf_detail_${e.key}`,l=this.getDetailTempFieldValue(e.key),r=void 0!==l?l:t;let o={...e.editor?.component?.props||{},name:a,"data-detail-field-key":e.key};if(i?.loading)return n`
                <sf-skeleton size="1"></sf-skeleton>`;const c=this.getDetailFieldSelectedValues(r);switch(s){case"dropdown":o={...o,value:c.join(","),portal:!0,"@change":t=>{this.setDetailTempFieldValue(e.key,this.createDetailDropdownTempField(e,t.detail?.values||[],this.getDetailDropdownSourceItems(e,i)))},items:this.getDetailDropdownOptions(e,i,c)};break;case"datepicker":o={...o,date:l||o.date,"@change":t=>{this.setDetailTempFieldValue(e.key,t.detail.formattedValue)}};break;case"editor":o={...o,"@sf-editor:value":t=>{this.setDetailTempFieldValue(e.key,t.detail.value)}};break;case"checkbox":o={...o,checked:Boolean(r),value:r??"","@change":t=>{this.setDetailTempFieldValue(e.key,Boolean(t.target?.checked),"detail-field-temp-checkbox")}};break;case"input":o={...o,defaultValue:r??"","@input":t=>{this.setDetailTempFieldValue(e.key,t.target.value,"detail-field-temp-input",{render:!1})}};break;case"country-code":o={...o,value:"object"==typeof r?r.displayValue||r.value||"":r??"",iso2:"object"==typeof r?r.iso2||o.iso2||"":o.iso2||"",dialCode:"object"==typeof r?r.dialCode||o.dialCode||"":o.dialCode||"",maskPattern:"object"==typeof r?r.maskPattern||o.maskPattern||"":o.maskPattern||"","@input":t=>{this.setDetailTempFieldValue(e.key,this.createDetailCountryCodeTempField(t),"detail-field-temp-country-code",{render:!1})},"@change":t=>{this.setDetailTempFieldValue(e.key,this.createDetailCountryCodeTempField(t),"detail-field-temp-country-code",{render:!1})}};break;case"file-upload":o={...o,items:this.createDetailFileUploadItems(r),"@sf-file-upload:change":t=>{this.setDetailTempFieldValue(e.key,this.createDetailFileUploadTempField(t),"detail-field-temp-file-upload",{render:!1})}}}return SF.litHtml(s,{...o})}async loadEditorData(e){if(!e?.key||this.state.editorData?.[e.key])return;this.set(t=>({editorData:{...t.editorData||{},[e.key]:{loading:!0,items:[]}}}));const t=await this.getFieldData(e);this.set(i=>({editorData:{...i.editorData||{},[e.key]:{loading:!1,data:t}}}))}getEditorData(e){const t=this.state.editorData?.[e];return{loading:!1,loaded:!1,error:null,items:[],...t||{}}}async toggleDetailFieldEdited(e,t="detail-field-edited"){if(!e?.key)return this;await this.loadEditorData(e);const i=(this.state.detail||{}).editedFields||{};return this.setDetailFieldEdited(e.key,!i[e.key],t)}getDetailFieldSettings(){return this.state.detail?.viewSettings?.detail?.fields||{}}getDetailFields(){const e=this.state.detail?.fields,t=this.getDetailFieldSettings();return(Array.isArray(e)?e:[]).map((e,i)=>{const n=t[e.key]||{},s=this.getDetailTempFieldValue(e.key);return{...e,...n,temp:s,edited:Boolean(this.state.detail?.editedFields?.[e.key]),__sfOrder:"number"==typeof n.order?n.order:10*(i+1)}}).filter(e=>!1!==e?.visible&&!1!==e?.detail?.enabled).sort((e,t)=>(e.__sfOrder||0)-(t.__sfOrder||0)||String(e.label||"").localeCompare(String(t.label||"")))}getDetailRow(){return this.state.detail?.row||null}getDetailTempFieldValue(e){if(e)return this.state.detail?.tempFields?.[e]}setDetailTempFieldValue(e,t,i="detail-field-temp",n={}){if(!e)return this;const s=Array.isArray(t)?[...t]:t;if(!1===n.render){const t=this.state.detail||{};return this.state={...this.state,detail:{...t,tempFields:{...t.tempFields||{},[e]:s}}},this}return this.set(t=>{const i=t.detail||{};return{detail:{...i,tempFields:{...i.tempFields||{},[e]:s}}}},i)}createDetailDropdownTempField(e,t=[],i=[]){const n=this.getDetailFieldSelectedValues(t),s=new Set(n);return{type:"dropdown",values:n,items:(Array.isArray(i)?i:[]).filter(e=>s.has(String(this.getDetailDropdownOptionValue(e)))),multiple:Boolean(e?.multiple)}}createDetailCountryCodeTempField(e){const t=e?.target,i=t?.closest?.(".sf-country-code")||e?.currentTarget,n=t?.value??e?.detail?.value??"";return{type:"phone",value:String(n||"").replace(/[^\d+]/g,"").replace(/(?!^)\+/g,""),displayValue:n,iso2:i?.dataset?.iso2||"",dialCode:i?.dataset?.dialCode||"",maskPattern:i?.dataset?.maskPattern||""}}createDetailFileUploadItems(e){const t=e=>{if(!e||"object"!=typeof e)return e;const t=e.displayValue||e.value||e.url||e.imageUrl||e.src||"";return t?{...e,id:e.id||String(t),name:e.name||e.fileName||String(t).split(/[\\/]/).pop()||String(t),value:t}:null};if(Array.isArray(e?.items))return e.items.map(t).filter(Boolean);if(Array.isArray(e))return e.map(t).filter(Boolean);const i=e&&"object"==typeof e?e.displayValue||e.value||e.url||e.imageUrl||e.src||"":e;if(!i)return[];const n=String(i).split(/[\\/]/).pop()||String(i);return[{id:String(i),name:n,fileSize:"",progress:100,state:"done",value:String(i)}]}createDetailFileUploadTempField(e){if(e?.detail?.value&&"object"==typeof e.detail.value)return e.detail.value;const t=e?.currentTarget,i=Array.isArray(e?.detail?.items)?e.detail.items:"function"==typeof t?.getItems?t.getItems():Array.isArray(e?.detail?.files)?e.detail.files:[],n=i.map(e=>{const t={...e||{}};return delete t.file,t}),s=i[0]||null,a=n[0]||null,l=a?.value||a?.url||a?.name||"",r=a?.name||a?.fileName||l;return{type:"file",action:n.length?"replace":"remove",value:l,displayValue:l,name:r,fileName:r,fileSize:a?.fileSize||a?.sizeText||"",mimeType:s?.file?.type||a?.mimeType||"",file:s?.file||null,items:n}}getDetailDisplayValue(e,t){if(!e||!t?.key)return;const i=e[t.key],n=this.getDetailTempFieldValue(t.key);return void 0===n?this.getFieldValueOrDefault(t,i):this.mergeDetailTempDisplayValue(i,n)}getFieldValueOrDefault(e={},t){if(null!=t&&""!==t)return t;const i=e.defaultValue??e.schema?.defaultValue??e.settings?.defaultValue??e.schema?.settings?.defaultValue;return null==i||""===i?this.getImplicitFieldDefaultValue(e,t):i}getImplicitFieldDefaultValue(e={},t){return"checkbox"!==this.getFieldType(e)&&"boolean"!==e.dataType&&(e.multiple||e.schema?.multiple?[]:t)}getDetailTextDisplayValue(e,t){return this.isRichTextField(e)?this.getPlainTextFromHtml(t):t}getDetailHtmlDisplayValue(e,t){return this.isRichTextField(e)?null==t?"":Ft.sanitize(String(t),{ALLOWED_TAGS:_t,ALLOWED_ATTR:[]}):null}getPlainTextFromHtml(e){if(null==e)return"";const t=String(e);if(!t)return"";const i=t.replace(/<br\s*\/?>/gi,"\n").replace(/<\/(p|div|li|h[1-6]|blockquote)>/gi,"\n");if("undefined"!=typeof document){const e=document.createElement("template");return e.innerHTML=i,(e.content.textContent||"").replace(/\u00a0/g," ").replace(/[ \t]+\n/g,"\n").replace(/\n[ \t]+/g,"\n").replace(/\n{3,}/g,"\n\n").trim()}return i.replace(/<[^>]*>/g,"").replace(/&nbsp;/gi," ").trim()}mergeDetailTempDisplayValue(e,t){if(!t||"object"!=typeof t)return t;if("phone"===t.type)return t;if("file-upload"===t.type||"file"===t.type)return this.mergeDetailFileDisplayValue(e,t);const i=e?.component?.type;return"avatars"===i?this.mergeDetailAvatarsDisplayValue(e,t):"avatar"===i?this.mergeDetailAvatarDisplayValue(e,t):"tag"===i?this.mergeDetailTagDisplayValue(e,t):{...e&&"object"==typeof e?e:{},value:t.values,items:t.items}}mergeDetailFileDisplayValue(e,t){if(!e||"object"!=typeof e)return t.displayValue||t.value||"";const i=e?.component?.type,n=t.displayValue||t.value||t.url||"",s=t.previewUrl||t.imageUrl||t.items?.[0]?.previewUrl||t.items?.[0]?.imageUrl||n;return"avatar"===i?{...e,type:"remove"===t.action?"avatar":"file",value:n,url:n,displayValue:n,name:"remove"===t.action?"":t.name||t.fileName||e.name||e.fileName||"",fileName:"remove"===t.action?"":t.fileName||t.name||e.fileName||e.name||"",fileSize:"remove"===t.action?"":t.fileSize||e.fileSize||"",mimeType:"remove"===t.action?"":t.mimeType||e.mimeType||"",imageUrl:"remove"===t.action?"":s,component:{...e.component||{},props:{...e.component?.props||{},imageUrl:"remove"===t.action?"":s}}}:{...e,...t}}mergeDetailTagDisplayValue(e,t){const i=t.items?.[0];if(!i)return e;const n=i.label||i.title||i.name||i.text||i.value||"",s=i.type||e?.type||e?.component?.props?.type||"default";return{...e||{},id:i.id??i.value,value:i.value??i.id,code:i.code,title:i.title||n,label:i.label||n,name:i.name||n,type:s,items:t.items,component:{...e?.component||{},props:{...e?.component?.props||{},text:n,type:s}}}}mergeDetailAvatarsDisplayValue(e,t){const i=this.createDetailAvatarProps(t.items);return{...e||{},value:t.values,items:t.items,component:{...e?.component||{},props:{...e?.component?.props||{},avatars:i}}}}mergeDetailAvatarDisplayValue(e,t){const i=t.items?.[0];return i?{...e||{},id:i.id??i.value,title:i.label||i.title||i.name||"",imageUrl:i.imageUrl||i.avatarImageUrl||i.avatar||"",component:{...e?.component||{},props:{...e?.component?.props||{},title:i.label||i.title||i.name||"",imageUrl:i.imageUrl||i.avatarImageUrl||i.avatar||"",inactive:!0}}}:e}createDetailAvatarProps(e=[]){return(Array.isArray(e)?e:[]).map(e=>({id:e.id??e.value,title:e.label||e.title||e.name||"",imageUrl:e.imageUrl||e.avatarImageUrl||e.avatar||""}))}getDetailFieldSelectedValues(e){if(Array.isArray(e?.values))return e.values.map(e=>String(e));if(Array.isArray(e))return e.map(e=>String(e));if(Array.isArray(e?.value))return e.value.map(e=>String(e));const t=e?.value??e?.id??e;return null==t||""===t?[]:[String(t)]}getDetailFieldEditorName(e){return e?.key?e.editor?.component?.props?.name||`sf_detail_${e.key}`:""}escapeDetailSelector(e){const t=String(e||"");return window.CSS?.escape?window.CSS.escape(t):t.replace(/["\\]/g,"\\$&")}getDetailEditorElement(e){const t=this.getDetailFieldEditorName(e),i=this.escapeDetailSelector(t),n=this.escapeDetailSelector(e?.key||"");return this.querySelector(`[name="${i}"]`)||this.querySelector(`[data-detail-field-key="${n}"]`)}getDetailEditorValue(e){const t=this.getDetailTempFieldValue(e.key);if(void 0!==t)return Array.isArray(t?.values)?t.values:t;const i=this.getDetailEditorElement(e);return i?"function"==typeof i.getValue?i.getValue():void 0!==i.value?i.value:void 0!==i.checked?i.checked:i.getAttribute?.("value")??this.getFieldValueOrDefault(e,this.getDetailRow()?.[e.key]):this.getFieldValueOrDefault(e,this.getDetailRow()?.[e.key])}getEditedDetailFieldsPayload(){const e=this.state.detail||{},t=this.getDetailRow(),i=e.editedFields||{},n=e.tempFields||{},s=this.getDetailFields().filter(e=>i[e.key]||Object.prototype.hasOwnProperty.call(n,e.key)),a={},l=s.map(e=>{const i=this.getDetailEditorValue(e),n=this.getDetailTempFieldValue(e.key),s=this.getDetailDisplayValue(t,e);return a[e.key]=i,{key:e.key,label:e.label||e.key,value:i,displayValue:s,tempField:n,previousValue:t?.[e.key],field:e}});return{row:t,rowId:t?.id??t?.value??null,values:a,fields:l,entity:e.entity||"task",detailEntity:e.entity||"task",tableSettingsKey:this.getTableSettingsKey()}}isDetailRequiredField(e={}){return Boolean(e.required||e.schema?.required||e.settings?.required||e.schema?.settings?.required)}isEmptyDetailFieldValue(e){return null==e||("string"==typeof e?""===e.trim():"number"!=typeof e&&"boolean"!=typeof e&&(Array.isArray(e)?!e.length||e.every(e=>this.isEmptyDetailFieldValue(e)):"object"==typeof e&&("phone"===e.type?this.isEmptyDetailFieldValue(e.value||e.displayValue):"file"===e.type||"file-upload"===e.type||"remove"===e.action?this.isEmptyDetailFieldValue(e.value||e.displayValue||e.url||e.imageUrl||e.file||e.items):(!Array.isArray(e.items)||!e.items.length)&&(Object.prototype.hasOwnProperty.call(e,"value")?this.isEmptyDetailFieldValue(e.value):["displayValue","label","title","name","id","url","imageUrl","file"].every(t=>this.isEmptyDetailFieldValue(e[t]))))))}validateDetailEditedFields(e=this.getEditedDetailFieldsPayload()){const t=(Array.isArray(e?.fields)?e.fields:[]).filter(e=>this.isDetailRequiredField(e.field)&&this.isEmptyDetailFieldValue(e.value));return{valid:0===t.length,invalidFields:t}}applyDetailEditedFields(e=this.getEditedDetailFieldsPayload()){const t=e?.row||this.getDetailRow(),i=Array.isArray(e?.fields)?e.fields:[];if(!t||!i.length)return this;const n=i.reduce((e,t)=>t?.key?(e[t.key]=void 0!==t.displayValue?t.displayValue:t.value,e):e,{}),s={...t,...n};return this.set(e=>({detail:{...e.detail||{},row:s,editedFields:{},tempFields:{}}}),"detail-field-apply"),void 0!==t.id&&null!==t.id?this.updateRowByKey("id",t.id,n,"detail-field-apply-row"):void 0!==t.value&&null!==t.value&&this.updateRowByKey("value",t.value,n,"detail-field-apply-row"),this}saveDetailEditedFields(){const e=this.getEditedDetailFieldsPayload();if(!e.fields.length)return this;const t=this.validateDetailEditedFields(e);if(!t.valid){const i={...e,invalidFields:t.invalidFields};return this.dispatchEvent(new CustomEvent("sf-table:field-edit-invalid",{bubbles:!0,composed:!0,detail:i})),this.dispatchEvent(new CustomEvent("onFieldEditInvalid",{bubbles:!0,composed:!0,detail:i})),this}return this.applyDetailEditedFields(e),this.dispatchEvent(new CustomEvent("sf-table:field-edit",{bubbles:!0,composed:!0,detail:e})),this.dispatchEvent(new CustomEvent("onFieldEdit",{bubbles:!0,composed:!0,detail:e})),this}cancelDetailEditedFields(e="detail-field-cancel"){return this.set(e=>({detail:{...e.detail||{},editedFields:{},tempFields:{}}}),e)}getActionItems(){return this.state.actions.map(e=>{const t={type:"checkbox",props:{size:1,label:e.name,position:"end",rootClass:"content-main-between",checked:e.visible,"@change":t=>{let i=!1;const n=(this.tempSettings&&this.tempSettings.actions?this.tempSettings.actions:this.state.actions).map(n=>{let s=n.id===e.id?t.target.checked:n.visible;return s&&(i=!0),{...n,visible:s}});this.tempSettings={...this.tempSettings||{},actionActive:i,actions:n}}}};return SF.litHtml(t.type,t.props)})}hoverEvents(e){if(this._columnResizeState||this._columnDragState?.started)return;const t=e.target.closest("th");if(!t)return;if(!t.querySelector(".sidebar-resizer"))return;const i=t.querySelector(`#column_resizer_${t.dataset.key}`);i&&i.setHidden(!1),t.classList.add("hover")}outEvent(e){if(this._columnResizeState||this._columnDragState?.started)return;const t=e.target.closest("th");if(!t)return;if(!t.querySelector(".sidebar-resizer"))return;const i=t.querySelector(`#column_resizer_${t.dataset.key}`);i&&i.setHidden(!0),t.classList.remove("hover")}bindHoverEvent(){if(this._hoverEventBound)return;this._hoverEventBound=!0;const e=this.refs.table?.value;e?.addEventListener("mouseover",this.hoverEvents),e?.addEventListener("mouseout",this.outEvent)}unBindHoverEvent(){if(!this._hoverEventBound)return;const e=this.refs.table?.value;e?.removeEventListener("mouseover",this.hoverEvents),e?.removeEventListener("mouseout",this.outEvent),this._hoverEventBound=!1}bindColumnResizeEvent(){if(this._columnResizeEventBound)return;const e=this.refs.table?.value;e&&(e.addEventListener("pointerdown",this.onColumnResizePointerDown),this._columnResizeEventBound=!0)}unbindColumnResizeEvent(){if(!this._columnResizeEventBound)return;const e=this.refs.table?.value;e?.removeEventListener("pointerdown",this.onColumnResizePointerDown),this._columnResizeEventBound=!1}bindColumnDragEvent(){if(this._columnDragEventBound)return;const e=this.refs.table?.value;e&&(e.addEventListener("pointerdown",this.onColumnDragPointerDown),this._columnDragEventBound=!0)}unbindColumnDragEvent(){if(!this._columnDragEventBound)return;const e=this.refs.table?.value;e?.removeEventListener("pointerdown",this.onColumnDragPointerDown),this._columnDragEventBound=!1}getColumnResizeHandle(e){return e instanceof Element?e.closest('[id^="column_resizer_"]'):null}getColumnDragHeader(e){return e instanceof Element?this.getColumnResizeHandle(e)?null:e.closest("th[data-key]"):null}parseColumnSize(e,t=null){if("number"==typeof e&&Number.isFinite(e))return e;if("string"==typeof e){const t=e.trim();if(/^-?\d+(\.\d+)?px$/.test(t))return parseFloat(t)}return t}getColumnResizeLimits(e={},t=0){const i=this.parseColumnSize(e.minWidth,null)??Math.min(Math.max(t,60),60),n=this.parseColumnSize(e.maxWidth,1/0);return{minWidth:i,maxWidth:Math.max(n,i)}}hasColumnSize(e={}){return[e.colWidth,e.width,e.size].some(e=>null!=e&&""!==String(e).trim())}escapeColumnKey(e){const t=String(e||"");return"undefined"!=typeof CSS&&"function"==typeof CSS.escape?CSS.escape(t):t.replace(/\\/g,"\\\\").replace(/"/g,'\\"')}freezeColumnsWidthForResize(e){const t={};return this.getColumns().forEach(i=>{if(!i?.key||i.system)return;const n=String(i.key),s=this.escapeColumnKey(n),a=e?.querySelector(`th[data-key="${s}"]`),l=e?.querySelector(`col[data-key="${s}"]`),r=a?.getBoundingClientRect?.().width||0;if(!r)return;const o=`${Math.round(r)}px`;l&&(l.style.width=o),this.hasColumnSize(i)||(t[n]=o)}),t}setColumnDomWidth(e,t,i=""){if(!e||!t)return this;const n=this.escapeColumnKey(t),s=null==i||""===i?"":"number"==typeof i?`${i}px`:String(i);return e.querySelectorAll(`th[data-key="${n}"], td[data-key="${n}"]`).forEach(e=>{e instanceof HTMLElement&&(e.style.width=s,e.style.minWidth=s,e.style.maxWidth=s)}),this}applyColumnResizeWidths(e,t,i={}){if(!e)return this;const n={...i||{},[e]:`${Math.round(t)}px`},s=Object.fromEntries(Object.entries(n).map(([e,t])=>[e,{width:t}]));return this.patchColumnSettingsBatch(s,"column-resize")}getColumnDragLayout(e){return this.getColumns().filter(e=>e?.key&&!e.system&&!1!==e.draggable).map(t=>{const i=String(t.key),n=this.escapeColumnKey(i),s=e?.querySelector(`th[data-key="${n}"]`),a=s?.getBoundingClientRect?.();return s&&a?{key:i,column:t,th:s,left:a.left,right:a.right,width:a.width,middle:a.left+a.width/2,cellIndex:s.cellIndex}:null}).sort((e,t)=>e.cellIndex-t.cellIndex).filter(Boolean)}getColumnDragDropIndex(e,t,i){const n=e.filter(e=>e.key!==i);for(let e=0;e<n.length;e+=1)if(t<n[e].middle)return e;return n.length}getVisibleUserColumnKeysFromDom(e){const t=new Set(this.getColumnItems().map(e=>String(e.key))),i=new Set;return Array.from(e?.tHead?.rows?.[0]?.cells||[]).reduce((e,n)=>{const s=String(n?.dataset?.key||"");return s&&t.has(s)&&!i.has(s)?(i.add(s),e.push(s),e):e},[])}reorderColumnDomByKeys(e,t=[]){if(!e||!Array.isArray(t)||!t.length)return;const i=(e,i)=>{if(!e)return;const n=new Set(t);let s=null;for(const t of Array.from(e.children||[])){const e=t?.dataset?.key;if(e&&n.has(e))break;e&&(s=t)}t.forEach(t=>{const n=this.escapeColumnKey(t),a=e.querySelector(`${i}[data-key="${n}"]`);a&&(e.insertBefore(a,s?.nextSibling||e.firstChild),s=a)})};i(e.querySelector("colgroup"),"col"),i(e.tHead?.rows?.[0],"th"),Array.from(e.tBodies||[]).forEach(e=>{Array.from(e.rows||[]).forEach(e=>{i(e,"td")})})}getColumnAnimationCells(e){return Array.from(e?.querySelectorAll("thead th[data-key], tbody td[data-key]")||[]).filter(e=>e instanceof HTMLElement)}snapshotColumnCellRects(e){const t=new Map;return this.getColumnAnimationCells(e).forEach(e=>{t.set(e,e.getBoundingClientRect())}),t}clearColumnAnimationStyles(e=this.refs.table?.value){this._columnAnimationToken+=1,this.getColumnAnimationCells(e).forEach(e=>{e.style.transition="",e.style.transform="",e.style.willChange=""})}clearColumnDragDom(e=this.refs.table?.value){e?.querySelectorAll([".is-column-dragging",".is-column-drag-placeholder-cell",".is-column-drag-shifted",".is-column-drag-before",".is-column-drag-after"].join(",")).forEach(e=>{e.classList.remove("is-column-dragging","is-column-drag-placeholder-cell","is-column-drag-shifted","is-column-drag-before","is-column-drag-after"),e.style.removeProperty("--sf-table-column-drag-shift")}),document.querySelectorAll(".sf-table-column-drag-ghost").forEach(e=>e.remove()),document.documentElement.classList.remove("sf-table-column-dragging")}animateColumnReorder(e,t){if(!(e&&t instanceof Map))return;const i=++this._columnAnimationToken,n=this.getColumnAnimationCells(e);n.forEach(e=>{const i=t.get(e);if(!i)return;const n=e.getBoundingClientRect(),s=i.left-n.left;Math.abs(s)<1||(e.style.transition="none",e.style.transform=`translate3d(${s}px, 0, 0)`,e.style.willChange="transform")}),requestAnimationFrame(()=>{i===this._columnAnimationToken&&(n.forEach(e=>{e.style.transform&&(e.style.transition="transform 140ms ease",e.style.transform="translate3d(0, 0, 0)")}),window.setTimeout(()=>{i===this._columnAnimationToken&&n.forEach(e=>{e.style.transition="",e.style.transform="",e.style.willChange=""})},160))})}applyColumnDragPreviewTransforms(e,t){if(!e?.table||!Array.isArray(e.layout))return;const i=e.startRect?.width||0;if(!i)return;const n=e.originalIndex,s=t>n,a=t<n,l=new Set,r=e.layout.filter(t=>t.key!==e.key);s?r.slice(n,t).forEach(e=>l.add(e.key)):a&&r.slice(t,n).forEach(e=>l.add(e.key)),this.getColumnAnimationCells(e.table).forEach(e=>{const t=e?.dataset?.key,n=l.has(t),r=s?-i:a?i:0;e.classList.toggle("is-column-drag-shifted",n),n?e.style.setProperty("--sf-table-column-drag-shift",`${r}px`):e.style.removeProperty("--sf-table-column-drag-shift")})}updateColumnDragPreview(e,t){if(!e||e.dropIndex===t)return;e.layout.forEach(e=>{e.th.classList.remove("is-column-drag-before","is-column-drag-after")}),e.dropIndex=t;const i=e.layout.filter(t=>t.key!==e.key),n=i.map(e=>e.key),s=Math.max(0,Math.min(t,n.length));if(n.splice(s,0,e.key),n.join("|")===e.currentKeys?.join("|"))return;e.currentKeys=n,this.setColumnDragPlaceholderClass(e.key,!0,e.table),this.applyColumnDragPreviewTransforms(e,s);const a=i[Math.min(s,i.length-1)]||e.layout.find(t=>t.key===e.key);a?.th&&a.th.classList.add(s>=i.length?"is-column-drag-after":"is-column-drag-before");const l=e.layout.find(t=>t.key===e.key);l?.th?.classList.add("is-column-dragging")}setColumnDragPlaceholderClass(e,t,i=this.refs.table?.value){if(!e||!i)return;const n=this.escapeColumnKey(e);i.querySelectorAll(`th[data-key="${n}"], td[data-key="${n}"]`).forEach(e=>{e.classList.toggle("is-column-dragging",Boolean(t)),e.classList.toggle("is-column-drag-placeholder-cell",Boolean(t))})}isSfElement(e){return e instanceof Element&&e.tagName.toLowerCase().startsWith("sf-")}findFirstSfElements(e){const t=e=>{for(const i of e.children){if(this.isSfElement(i)){const e=document.createElement("table-clone");e.className="sf-ghost-clone",e.style.display="contents",e.append(...i.childNodes),i.replaceWith(e);continue}i.children.length&&t(i)}};return t(e),[]}createColumnDragGhost(e){const t=this.refs.table?.value,i=e?.dataset?.key,n=document.createElement("div"),s=e.getBoundingClientRect(),a=this.escapeColumnKey(i),l=[e,...Array.from(t?.querySelectorAll(`tbody td[data-key="${a}"]`)||[])].filter(e=>e instanceof HTMLElement),r=t?.getBoundingClientRect?.();return n.className="sf-table-column-drag-ghost flex flex-col overflow-hidden bg-surface-0",Object.assign(n.style,{position:"fixed",left:`${s.left}px`,top:`${r?.top??s.top}px`,width:`${s.width}px`,zIndex:"9999",pointerEvents:"none",boxSizing:"border-box"}),n.setAttribute("aria-hidden","true"),l.forEach(e=>{const t=e.getBoundingClientRect(),i=document.createElement("div");i.className="sf-table-column-drag-ghost-cell min-w-0 flex overflow-hidden p-inline-start-1/3 p-inline-end-1/3 items-cross-center bg-surface-0";const s=e.children?.[0].cloneNode(!0),{borderBottom:a,borderTop:l,borderInlineStart:r,borderInlineEnd:o}=getComputedStyle(e);i.style.borderTop=l,i.style.borderBottom=a,i.style.borderInlineStart=r,i.style.borderInlineEnd=o,this.findFirstSfElements(s),i.append(s),Object.assign(i.style,{width:`${t.width}px`,height:`${t.height}px`}),"TH"===e.tagName&&i.classList.add("sf-table-column-drag-ghost-cell--head","relative"),n.append(i)}),document.body.append(n),n}clearColumnDragState(e=!1,t=null){const i=this._columnDragState;if(document.removeEventListener("pointermove",this.onColumnDragPointerMove),document.removeEventListener("pointerup",this.onColumnDragPointerUp),document.removeEventListener("pointercancel",this.onColumnDragPointerCancel),document.documentElement.classList.remove("sf-table-column-dragging"),!i)return this.clearColumnAnimationStyles(),this.clearColumnDragDom(),void wt(!1);i.frame&&cancelAnimationFrame(i.frame),i.handle?.releasePointerCapture?.(t?.pointerId),i.ghost?.remove(),this.clearColumnAnimationStyles(i.table),this.setColumnDragPlaceholderClass(i.key,!1,i.table),i.th?.classList.remove("is-column-dragging"),i.layout?.forEach(e=>{e.th.classList.remove("is-column-drag-before","is-column-drag-after")});const n=Array.isArray(i.currentKeys)&&i.currentKeys.length?i.currentKeys:this.getVisibleUserColumnKeysFromDom(i.table),s=e&&i.started&&n.length&&n.join("|")!==i.originalKeys?.join("|");this._columnDragState=null,this.clearColumnDragDom(i.table),wt(!1),s&&this.applyColumnOrder(n,i.frozenWidths)}applyColumnOrder(e=[],t={}){if(!Array.isArray(e)||!e.length)return this;const i=new Set(this.getColumnItems().map(e=>String(e.key))),n=new Set,s=e.filter(e=>{const t=String(e||"");return!(!t||!i.has(t)||n.has(t))&&(n.add(t),!0)}),a={};return s.length?(s.forEach((e,i)=>{a[e]={order:10*(i+1)},t?.[e]&&(a[e].width=t[e])}),this.patchColumnSettingsBatch(a,"column-drag")):this}setColumnResizeClasses(e,t=0){e&&(e.classList.add("is-resizing"),e.classList.toggle("is-resizing-forward",t>=0),e.classList.toggle("is-resizing-backward",t<0))}clearColumnResizeClasses(e){e&&e.classList.remove("is-resizing","is-resizing-forward","is-resizing-backward")}onColumnDragPointerDown(e){if(0!==e.button||this._columnResizeState)return;const t=this.getColumnDragHeader(e.target),i=t?.dataset?.key;if(!t||!i)return;const n=this.refs.table?.value;this.clearColumnAnimationStyles(n),this.clearColumnDragDom(n);const s=this.getColumnDragLayout(n),a=s.find(e=>e.key===i),l=s.map(e=>e.key);!a||s.length<2||(this._columnDragState={key:i,th:t,table:n,handle:t,startRect:t.getBoundingClientRect(),startX:e.clientX,startY:e.clientY,shiftX:e.clientX-a.left,shiftY:e.clientY-t.getBoundingClientRect().top,originalIndex:s.findIndex(e=>e.key===i),originalKeys:l,currentKeys:l,dropIndex:null,layout:s,started:!1,ghost:null,frozenWidths:null},t.setPointerCapture?.(e.pointerId),document.addEventListener("pointermove",this.onColumnDragPointerMove),document.addEventListener("pointerup",this.onColumnDragPointerUp,{once:!0}),document.addEventListener("pointercancel",this.onColumnDragPointerCancel,{once:!0}))}onColumnDragPointerMove(e){const t=this._columnDragState;if(!t)return;const i=e.clientX-t.startX,n=e.clientY-t.startY;if(!t.started){if(Math.abs(i)<4&&Math.abs(n)<4)return;e.preventDefault(),e.stopPropagation(),t.started=!0,wt(!0),t.frozenWidths=this.freezeColumnsWidthForResize(t.table),t.ghost=this.createColumnDragGhost(t.th),this.setColumnDragPlaceholderClass(t.key,!0,t.table),document.documentElement.classList.add("sf-table-column-dragging")}t.frame?t.latestEvent=e:(t.latestEvent=e,t.frame=requestAnimationFrame(()=>{const e=t.latestEvent;if(t.frame=null,!e||!t.ghost)return;t.ghost.style.left=e.clientX-t.shiftX+"px";const i=this.getColumnDragDropIndex(t.layout,e.clientX,t.key);this.updateColumnDragPreview(t,i)}))}onColumnDragPointerUp(e){this.clearColumnDragState(!0,e)}onColumnDragPointerCancel(e){this.clearColumnDragState(!1,e)}onColumnResizePointerDown(e){const t=this.getColumnResizeHandle(e.target);if(!t)return;const i=t.closest("th"),n=i?.dataset?.key;if(!i||!n)return;const s=this.getColumns().find(e=>e?.key===n);if(!s||s.system||!1===s.resizable)return;const a=this.refs.table?.value,l=this.escapeColumnKey(n),r=a?.querySelector(`col[data-key="${l}"]`),o=i.getBoundingClientRect().width,c=this.getColumnResizeLimits(s,o),d=this.freezeColumnsWidthForResize(a);e.preventDefault(),e.stopPropagation(),this._columnResizeState={key:n,table:a,th:i,col:r,startX:e.clientX,startWidth:o,width:o,frozenWidths:d,...c},wt(!0),document.documentElement.classList.add("sf-table-column-resizing"),document.addEventListener("pointermove",this.onColumnResizePointerMove),document.addEventListener("pointerup",this.onColumnResizePointerUp,{once:!0}),document.addEventListener("pointercancel",this.onColumnResizePointerUp,{once:!0})}onColumnResizePointerMove(e){const t=this._columnResizeState;if(!t)return;const i=e.clientX-t.startX;t.width=Math.min(Math.max(t.startWidth+i,t.minWidth),t.maxWidth),t.delta=i,t.frame||(t.frame=requestAnimationFrame(()=>{t.frame=null,t.col&&(t.col.style.width=`${t.width}px`),this.setColumnDomWidth(t.table,t.key,t.width)}))}onColumnResizePointerUp(){const e=this._columnResizeState;document.removeEventListener("pointermove",this.onColumnResizePointerMove),document.removeEventListener("pointerup",this.onColumnResizePointerUp),document.removeEventListener("pointercancel",this.onColumnResizePointerUp),document.documentElement.classList.remove("sf-table-column-resizing"),e&&(wt(!1),this._columnResizeState=null,this.outEvent({target:e.th}),this.applyColumnResizeWidths(e.key,e.width,e.frozenWidths))}bindContextEvent(){this._contextEventBound||(document.addEventListener("click",this.contextEvent),this._contextEventBound=!0)}unbindContextEvent(){this._contextEventBound&&(document.removeEventListener("click",this.contextEvent),this._contextEventBound=!1)}getPortalContainer(){let e=document.getElementById("sf-table-portal");return e||(e=document.createElement("div"),e.id="sf-table-portal",document.body.append(e)),e}openContextMenu(e,t={}){this.closeContextMenu(),this.contextTarget?.classList.remove("active"),this.contextTarget=e.target,this.contextTarget.classList.add("active");let i=e.target.getBoundingClientRect();e.preventDefault(),e.stopPropagation();let n,s={open:!0,id:this.contextTarget,...t};switch(t.type){case"left":n={x:i.left+i.width,y:i.y+i.height/2};break;case"bottom":{let s;t.parent&&(s=function(e){let t=e;for(;t;){if(t.nodeName.toLowerCase().startsWith("sf-"))return t.parentNode;t=t.parentNode}return null}(e.target),i=s.getBoundingClientRect()),n={x:i.left,y:i.y+i.height};break}default:n={x:i.left,y:i.y+i.height}}s={...s,...n},this.set({contextMenu:{...s}})}openContextSubmenu(e,t={}){e.preventDefault(),e.stopPropagation();const i=e.target||e.currentTarget,n=e.currentTarget||i,s=i.getBoundingClientRect(),a=t.anchorKey||t.template?.key||n.dataset?.contextSubmenuAnchor||"";if(a&&this.state.contextMenu?.submenu?.open&&this.state.contextMenu.submenu.anchorKey===a)return void this.closeContextSubmenu();const l={open:!0,type:t.type,anchorKey:a,x:s.left+s.width,y:s.y+s.height/2,position:t.position||"left",transform:-50,...t};this.set(e=>({contextMenu:{...e.contextMenu||{},submenu:l}}))}handleContextLayerClick(e){const t=e.target;t instanceof Element&&(t.closest("[data-context-submenu]")||t.closest("[data-context-submenu-anchor]")||this.state.contextMenu?.submenu?.open&&!t.closest("[data-context-main-menu]")&&this.closeContextSubmenu())}closeContextSubmenu(){this.set(e=>({contextMenu:{...e.contextMenu||{},submenu:null}}))}getSelectColumn(){return{...this.TABLE_SELECT_COLUMN,component:{...this.TABLE_SELECT_COLUMN.component,props:{...this.TABLE_SELECT_COLUMN.component?.props||{},checked:Boolean(this.state?.settingsChecked),indeterminate:Boolean(this.state?.selectIndeterminate)}}}}getColumns(){const e=this.getTableData().columns||[],t=this.getSystemColumns(),i=new Set(t.map(e=>e.key)),n=new Set(["actions"]),s=new Map(e.map((e,t)=>[e?.key,t])),a=e.filter(e=>e?.key&&!i.has(e.key)).map(e=>{const t=this.getTableField(e?.key),i=t?.column&&"object"==typeof t.column?t.column:{},n=this.getColumnSetting(e.key),s={...i,...e,...n};return!s.component?.type&&i.component?.type&&s.renderer===i.renderer&&(s.component=i.component),n.width&&(s.colWidth=n.width),s}).sort((e,t)=>{const i=e=>{const t=e?.order;return null!=t&&""!==t&&Number.isFinite(Number(t))?Number(t):s.get(e?.key)??0},n=i(e),a=i(t);return n===a?(s.get(e.key)??0)-(s.get(t.key)??0):n-a});return[...t.filter(e=>!n.has(e?.key)),...a,...t.filter(e=>n.has(e?.key))].filter(e=>!1!==e?.visible)}createRowComponentCell(e,t={}){return e?.type?{component:{type:e.type,props:{...e.props||{},...t}}}:null}getActionRowItems(e={}){return this.ACTIONS_SETTINGS_ROW.map(t=>{const i=t.component||{},n={...t.props||{},...i.props||{}},s=t.menu||n.menu,a="function"==typeof n["@click"]||"function"==typeof n.onClick;return"view"!==t.id||a||(n["@click"]=t=>{t?.preventDefault?.(),t?.stopPropagation?.(),this.openRowDetail(e)}),s&&!a&&(n["@click"]=i=>{const n=s&&"object"==typeof s?s:{menu:s};this.openContextMenu(i,{type:"left",row:e,action:t,...n})}),{...t,component:{...i,props:n}}})}getDefaultRowCell(e,t){return e?.key?"select"===e.key?this.createRowComponentCell(e.rowComponent,{checked:!!this.state.settingsChecked||Boolean(t?.selected||t?.checked),value:t?.id??t?.value??""}):"settings"===e.key?this.createRowComponentCell(e.rowComponent||{type:"icon-button",props:{size:"1",type:"link",scheme:"on-surface",icon:"menu",ariaLabel:"Меню",value:"menu","@click":e=>{this.openContextMenu(e,{type:"left",menu:"row-settings"})}}}):"actions"===e.key?this.getActionRowItems(t):null:null}normalizeRow(e={}){if(!e||"object"!=typeof e||Array.isArray(e))return e;const t={...e};return this.getSystemColumns().forEach(e=>{if(!e?.key||void 0!==t[e.key]||!1===e.visible)return;const i=this.getDefaultRowCell(e,t);i&&(t[e.key]=i)}),t}normalizeRows(e=[]){return Array.isArray(e)?e.map(e=>this.normalizeRow(e)):[]}setTableData(e={},t="data"){const i=this.getTableData();let n="function"==typeof e?e(i):e;if(!n||"object"!=typeof n)return this;Array.isArray(n.items)&&!Object.prototype.hasOwnProperty.call(n,"rows")&&(n={...n,rows:n.items}),Array.isArray(n.rows)&&(n={...n,rows:this.normalizeRows(n.rows)});const s={data:{...i,...n}};return n.pagination&&"object"==typeof n.pagination&&(s.pagination=this.normalizePaginationData(n.pagination)),this.set(s,t)}appendTableData(e={},t="data-append"){const i=this.getTableData();let n="function"==typeof e?e(i):e;if(!n||"object"!=typeof n)return this;Array.isArray(n.items)&&!Object.prototype.hasOwnProperty.call(n,"rows")&&(n={...n,rows:n.items});const s=Array.isArray(n.rows)?this.normalizeRows(n.rows):[],a={data:{...i,...n,rows:[...i.rows||[],...s]}};return n.pagination&&"object"==typeof n.pagination&&(a.pagination=this.normalizePaginationData(n.pagination)),this.set(a,t)}setColumns(e=[],t="columns"){const i=this.getTableData().columns||[],n="function"==typeof e?e(i):e;return this.setTableData({columns:Array.isArray(n)?n:[]},t)}addColumns(e=[]){const t=Array.isArray(e)?e:[e];return this.setColumns(e=>[...e,...t.filter(Boolean)])}updateColumn(e,t={},i="columns"){return e?this.setColumns(i=>i.map((i,n)=>{if(!i||i.key!==e)return i;const s="function"==typeof t?t(i,n):t;return{...i,...s||{}}}),i):this}setRows(e=[],t="rows"){const i=this.getTableData().rows||[],n="function"==typeof e?e(i):e;return this.setTableData({rows:this.normalizeRows(n)},t)}addRows(e=[],t="rows"){const i=Array.isArray(e)?e:[e];return this.setRows(e=>[...e,...i.filter(Boolean)],t)}updateRowsByKey(e,t,i={},n="rows"){if(!e)return this;const s="function"==typeof i?i:e=>({...e,...i||{}});return this.setRows(i=>i.map((i,n)=>{if(!i||i[e]!==t)return i;const a=s(i,n);return a&&"object"==typeof a?a:i}),n)}updateRowByKey(e,t,i={},n="row"){return this.updateRowsByKey(e,t,i,n)}updateRows(e={},t="rows"){const i="function"==typeof e?e:t=>({...t,...e||{}});return this.setRows(e=>e.map((e,t)=>{const n=i(e,t);return n&&"object"==typeof n?n:e}),t)}updateRowCell(e,t,i,n={},s="cell"){return i?this.updateRowsByKey(e,t,e=>{const t=e&&e[i]&&"object"==typeof e[i]?e[i]:{},s="function"==typeof n?n(t,e):n;return{...e,[i]:{...t,...s||{}}}},s):this}updateRowCellProps(e,t,i,n={},s="cell-props"){return this.updateRowCell(e,t,i,e=>({component:{...e.component||{},props:{...e.component?.props||{},..."function"==typeof n?n(e.component?.props||{},e):n||{}}}}),s)}closeContextMenu(){this.set({contextMenu:{open:!1}}),a(null,this.getPortalContainer()),this.refs.contextMenu&&(this.refs.contextMenu.value=null),this.unbindContextEvent(),this.contextTarget?.classList.remove("active"),this.contextTarget=null}get templateName(){return this.getAttribute("template")||"default"}disconnectedCallback(){this.unbindContextEvent(),this.unBindHoverEvent(),this.unbindColumnResizeEvent(),this.unbindColumnDragEvent(),this.unbindDetailModalEvents(),this.unbindFieldCreateModalEvents(),this.clearColumnDragState(!1),this.onColumnResizePointerUp()}templateContext(){const e=this.getPropsContext();return this.createTemplateContext({...e,component:this,rootClass:this.getRootClass(),rootStyle:this.getRootStyle()})}setCheckboxHeight(){if(!this.refs.items.size)return;const e=++this._checkboxMeasureToken;requestAnimationFrame(()=>{if(!this.isConnected||e!==this._checkboxMeasureToken)return;const t=function(e){const t=e.values().next().value,i=t?.value;if(!i)return;const n=i.parentNode;var s;return n?{gap:(s=n,parseFloat(getComputedStyle(s).rowGap)||0),item:i,parent:n}:void 0}(this.refs.items);if(!t)return;const{item:i,gap:n,parent:s}=t;this.parentGap=n;const a=i.tagName.toLowerCase().startsWith("sf-")?i.children[0]?.clientHeight:i.clientHeight;if(!a)return;const l=(a+n)*(s.dataset.size||8);if(s.clientHeight<=l)return!1;s.setAttribute("style",`height: ${l}px; overflow: auto;`)})}beforeRender(){super.beforeRender(),this._checkboxMeasureToken++,this.refs.items=new Map}afterRender(){this.setCheckboxHeight(),this.bindHoverEvent(),this.bindColumnResizeEvent(),this.bindColumnDragEvent(),this.bindDetailFieldDrag(),this.bindDetailModalEvents(),this.bindFieldCreateModalEvents()}template(){return Ce(this.templateContext())}}).define("sf-table")})();