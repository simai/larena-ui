(()=>{"use strict";const e="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},t="undefined"!=typeof window?window:{},n=e.SfBaseElement||t.SfBaseElement;if(!n)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const s=e.html||t.html,i=(e.nothing||t.nothing,e.render||t.render,e.litProps||t.litProps,e.toBoolean,e.toAttributeName,e.toNumber,e.normalizeEnum,e.parseJsonAttribute,n);function a(e){const t=function(...e){return e.flat().filter(Boolean).join(" ")}("sf-toggle",`sf-toggle--${e.type}`,`sf-toggle--size-${e.size}`,"flex","items-center",e.checked?"active":"",e.disabled?"disabled":"",e.rootClass),n=e.component?.hasSlotContent?.("label")?e.component.getSlotContent("label"):e.label?s`<span class="sf-toggle-text">${e.label}</span>`:"";return s`
    <label class=${t} data-sf-smart-toggle>
      <span class="sf-toggle-control">
        <input
          type="checkbox"
          name=${e.name||""}
          .value=${e.value||""}
          ?checked=${e.checked}
          ?disabled=${e.disabled}
          @change=${t=>e.component?.handleInputChange(t)}
        />
        <span class="sf-toggle-container transition flex items-center ${e.checked?"content-main-end":"content-main-start"}">
          <span class="sf-toggle-inner-wrap transition flex items-center content-main-center">
            ${function(e){return"icon"!==e.type?s`<span class="sf-toggle-inner transition" aria-hidden="true"></span>`:s`
    <sf-icon icon=${e.icon||"check"} aria-hidden="true"></sf-icon>
  `}(e)}
          </span>
        </span>
      </span>
      ${n}
    </label>
  `}(class extends i{static get props(){return{size:{default:"1"},type:{default:"simple"},label:{default:""},icon:{default:""},checked:{type:Boolean,default:!1},disabled:{type:Boolean,default:!1},name:{default:""},value:{default:""}}}get size(){return this.getAttribute("size")||"1"}get type(){return this.getAttribute("type")||"simple"}get label(){return this.getAttribute("label")||""}get icon(){return this.getAttribute("icon")||""}get checked(){return this.getBooleanAttr("checked",!1)}set checked(e){e?this.setAttribute("checked",""):this.removeAttribute("checked")}get disabled(){return this.getBooleanAttr("disabled",!1)}set disabled(e){e?this.setAttribute("disabled",""):this.removeAttribute("disabled")}get name(){return this.getAttribute("name")||""}get value(){return this.getAttribute("value")||""}set value(e){null!=e?this.setAttribute("value",String(e)):this.removeAttribute("value")}templateContext(){const e=this.getPropsContext();return this.createTemplateContext({...e,component:this,rootClass:this.getRootClass()})}template(){return a(this.templateContext())}handleInputChange(e){const t=e?.currentTarget||this.getInputElement();Boolean(t?.checked)?this.setAttribute("checked",""):this.removeAttribute("checked")}getInputElement(){return this.querySelector('.sf-toggle input[type="checkbox"]')}isChecked(){return!!this.getInputElement()?.checked}setChecked(e=!1){return this.setState({checked:!!e}),this}setDisabled(e=!1){return this.setState({disabled:!!e}),this}get state(){const e=this.getInputElement();return{type:this.type,size:this.size,checked:e?!!e.checked:this.checked,disabled:e?!!e.disabled:this.disabled,name:e?.name||this.name,value:e?.value||this.value,icon:this.icon,label:this.label}}onChange(e,t){return"function"==typeof e&&this.addEventListener("change",e,t),this}onFocus(e,t){return"function"==typeof e&&this.addEventListener("focusin",e,t),this}onBlur(e,t){return"function"==typeof e&&this.addEventListener("focusout",e,t),this}}).define("sf-toggle")})();