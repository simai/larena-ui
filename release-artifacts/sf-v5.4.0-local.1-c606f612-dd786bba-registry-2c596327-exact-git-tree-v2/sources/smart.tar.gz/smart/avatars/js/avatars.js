(()=>{"use strict";const t="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},a="undefined"!=typeof window?window:{},e=t.SfBaseElement||a.SfBaseElement;if(!e)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const r=t.html||a.html,s=t.nothing||a.nothing,i=(t.render||a.render,t.litProps||a.litProps,t.toBoolean),l=(t.toAttributeName,t.toNumber,t.normalizeEnum,t.parseJsonAttribute),n=e,o={tiny:"1/4",extra_small:"1/3",extraSmall:"1/3",small:"1/2",default:"",big:"2",extra_big:"3",extraBig:"3"},u={small:"3",big:"5"},c={md:"1",sm:"1/2",xs:"1/3"};function d(t){const a=String(t||"").trim();return o[a]??a}function v(t){const a=d(t);return a?`sf-avatar-round--${a}`:""}function f(t,a){const e=d(t);return e?`${a}--${e}`:""}function h(){return r`<i class="sf-icon">check</i>`}function p(t){const a=t.roundSize||t.avatarSize,e=["sf-avatar","sf-avatar-round",v(a),t.rootClass].filter(Boolean),i=f(a,"sf-avatar-cir"),l=f(a,"sf-avatar-check");return r`
        <div class=${e.join(" ")}>
            <button
                    type="button"
                    class="sf-avatar--image"
                    style=${n=t.imageUrl,n?`background-image: url(${n});`:s}
            >
                ${t.active?r`<span
                                class=${["sf-avatar-cir","sf-avatar-cir-green",i].filter(Boolean).join(" ")}
                        ></span>`:s}
                ${t.check?r`<span
                                class=${["sf-avatar-check",l].filter(Boolean).join(" ")}
                        >
              ${h()}
            </span>`:s}
            </button>
        </div>
    `;var n}function g(t){switch(t.templateName){case"user":return function(t){return r`
        <div class=${["sf-avatar","sf-avatar--user",t.rootClass].filter(Boolean).join(" ")}>
            ${t.imageUrl?r`<img src=${t.imageUrl} alt=""/>`:s}
            <div class="sf-avatar--user-description">
                <span class="sf-avatar--name">${t.name}</span>
                <span class="sf-avatar--additional">
          <i class="sf-icon">link</i>
          <span>${t.source}</span>
        </span>
            </div>
        </div>
    `}(t);case"group":return function(t){const a=["sf-avatar-group",`sf-avatar-group--size-${t.size}`,"flex","items-cross-center",t.rootClass].filter(Boolean);return r`
        <div class=${a.join(" ")}>
            <div class="sf-avatar-group-avatars flex items-center">
                ${t.avatars.map(a=>r`
                    <div class="sf-avatar-group-item flex">
                        <sf-avatar
                                size="${c[t.size]||1}"
                                image-url=${a.imageUrl}
                                aria-label=${a.title}
                        ></sf-avatar>
                    </div>
                `)}

                ${t.avatarsMore?r`
                            <div class=${["sf-avatar-round",v(t.roundSize)].filter(Boolean).join(" ")}>
                                <button type="button" class="sf-avatar--image">
                                    <span>${t.avatarsMore}&gt;</span>
                                </button>
                            </div>
                        `:s}
            </div>
        </div>
    `}(t);case"label":return function(t){const a=["sf-avatar-label",t.labelSize?`sf-avatar-label--${d(t.labelSize)}`:"",t.rootClass].filter(Boolean);return r`
        <div class=${a.join(" ")}>
            ${p({...t,imageUrl:t.avatarUrl,roundSize:t.avatarSize,active:!1,check:!1,rootClass:""})}
            <div class="sf-avatar-label--text">
                <span>${t.labelText}</span>
                <span>${t.labelSecondText}</span>
            </div>
        </div>
    `}(t);case"profile":return function(t){const a=t.profileSize,e=u[a]||"4",i=["sf-avatar","sf-avatar-profile",a?`sf-avatar-profile--${d(a)}`:"",t.rootClass].filter(Boolean);return r`
        <div class=${i.join(" ")}>
            ${t.imageUrl?r`<img src=${t.imageUrl} alt=""/>`:s}
            <span class=${["sf-avatar-check",`sf-avatar-check--${e}`].join(" ")}>
        ${h()}
      </span>
        </div>
    `}(t);default:return p(t)}}(class extends n{static get props(){return{templateName:{default:""},data:{default:""},property:{default:""},imageUrl:{default:""},avatarUrl:{default:""},avatarSize:{default:""},active:{type:Boolean,default:!1},check:{type:Boolean,default:!1},name:{default:""},source:{default:""},size:{default:"md"},labelText:{default:""},labelSecondText:{default:""},avatars:{type:Array,default:[]},avatarsMore:{default:""},roundSize:{default:""},labelSize:{default:""},profileSize:{default:""},rootClass:{default:""}}}get templateName(){return this.getAttribute("template")||"default"}get dataValue(){return l(this,"data",{})}get propertyValue(){return l(this,"property",{})}get imageUrl(){return this.getAttribute("image-url")||this.dataValue.imageUrl||this.dataValue.image_url||""}get avatarUrl(){return this.getAttribute("avatar-url")||this.dataValue.avatarUrl||this.dataValue.avatar_url||this.imageUrl}get avatarSize(){return this.getAttribute("avatar-size")||this.dataValue.avatarSize||this.dataValue.avatar_size||this.roundSize}get active(){return this.hasAttribute("active")?this.getBooleanAttr("active",!0):i(this.dataValue.active,!1)}get check(){return this.hasAttribute("check")?this.getBooleanAttr("check",!0):i(this.dataValue.check,!1)}get name(){return this.getAttribute("name")||this.dataValue.name||""}get source(){return this.getAttribute("source")||this.dataValue.source||""}get labelText(){return this.getAttribute("label-text")||this.dataValue.labelText||this.dataValue.label_text||""}get labelSecondText(){return this.getAttribute("label-second-text")||this.dataValue.labelSecondText||this.dataValue.label_second_text||""}get avatars(){const t=this.getAttribute("avatars");if(t)try{return JSON.parse(t)}catch(t){console.warn("sf-avatars: invalid avatars JSON",t)}return Array.isArray(this.dataValue.avatars)?this.dataValue.avatars:[]}get avatarsMore(){return this.getAttribute("avatars-more")||this.dataValue.avatarsMore||this.dataValue.avatars_more||""}get roundSize(){return this.getAttribute("round-size")||this.propertyValue.round_size||this.propertyValue.roundSize||""}get labelSize(){return this.getAttribute("label-size")||this.propertyValue.label_size||this.propertyValue.labelSize||""}get profileSize(){return this.getAttribute("profile-size")||this.propertyValue.profile_size||this.propertyValue.profileSize||""}get rootClass(){return this.getAttribute("root-class")||""}templateContext(){const t=this.getPropsContext();return this.createTemplateContext({...t,component:this,imageUrl:this.imageUrl,avatarUrl:this.avatarUrl,avatarSize:this.avatarSize,active:this.active,check:this.check,name:this.name,source:this.source,labelText:this.labelText,labelSecondText:this.labelSecondText,avatars:this.avatars,avatarsMore:this.avatarsMore,roundSize:this.roundSize,labelSize:this.labelSize,profileSize:this.profileSize,rootClass:this.rootClass})}hasBuiltInTemplate(t=this.templateName){return["default","user","group","label","profile"].includes(t)}template(){return g(this.templateContext())}get value(){return this.templateContext()}set value(t){this.setValueAttributes(t,{removeEmptyString:!1})}}).define("sf-avatars")})();