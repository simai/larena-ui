(()=>{"use strict";const t="undefined"!=typeof window&&(window.SF?.smart||window.SF)||{},e="undefined"!=typeof window?window:{},a=t.SfBaseElement||e.SfBaseElement;if(!a)throw new Error("SF smart runtime is not loaded. Load smart-base before smart components.");const n=t.html||e.html,r=t.nothing||e.nothing,s=t.render||e.render,i=(t.litProps||e.litProps,t.toBoolean,t.toAttributeName,t.toNumber),o=(t.normalizeEnum,t.parseJsonAttribute,a);function l(...t){return t.flat().filter(Boolean).join(" ")}function u(t){return"year"===t.context?function(t){return n`
        <div class="sf-datepicker-top flex content-main-between items-cross-center">
            <sf-icon-button
                    type="link"
                    scheme="on-surface"
                    size="1"
                    icon="keyboard_arrow_left"
                    aria-label="Previous years"
                    @click=${()=>t.component.shiftYearPage(-1)}
            ></sf-icon-button>
            <div class="sf-datepicker-range-title">
                ${t.yearPageStart} - ${t.yearPageEnd}
            </div>
            <sf-icon-button
                    type="link"
                    scheme="on-surface"
                    size="1"
                    icon="keyboard_arrow_right"
                    aria-label="Next years"
                    @click=${()=>t.component.shiftYearPage(1)}
            ></sf-icon-button>
        </div>
    `}(t):n`
        <div class="sf-datepicker-top flex content-main-between">
            <sf-button
            type="link"
            scheme="on-surface"
            tightness="low"
            text="${t.monthLabel}"
            icon-right="expand_${"month"===t.context?"less":"more"}"
            @click=${()=>t.component.toggleContext("month")}
            >
            </sf-button>
            <sf-button
                    type="link"
                    scheme="on-surface"
                    tightness="low"
                    text="${t.year}"
                    icon-right="expand_${"year"===t.context?"less":"more"}"
                    @click=${()=>t.component.toggleContext("year")}
            >
            </sf-button>
        </div>
    `}function h(t){return"month"===t.context?function(t){return n`
        <div class="sf-datepicker-context absolute top-0 bottom-0 inline-start-0 inline-end-0 grid grid-col-3 content-cross-start items-cross-start z-2 overflow-auto gap-1/4">
            ${t.months.map(e=>n`
                <button
                        class=${l("sf-datepicker-text flex content-main-center items-cross-center",e.selected?"active":"",e.disabled?"disabled":"")}
                        ?disabled=${e.disabled}
                        type="button"
                        @click=${()=>t.component.selectMonth(e)}
                >
                    <span class="sf-datepicker-text-date">${e.label}</span>
                </button>
            `)}
        </div>
    `}(t):"year"===t.context?function(t){return n`
        <div class="sf-datepicker-context absolute top-0 bottom-0 inline-start-0 inline-end-0 grid grid-col-3 content-cross-start items-cross-start z-2 overflow-auto gap-1/4">
            ${t.years.map(e=>n`
                <button
                        class=${l("sf-datepicker-text flex content-main-center items-cross-center",e.selected?"active":"",e.disabled?"disabled":"")}
                        type="button"
                        ?disabled=${e.disabled}
                        @click=${()=>t.component.selectYear(e)}
                >
                    <span class="sf-datepicker-text-date">${e.year}</span>
                </button>
            `)}
        </div>
    `}(t):r}function d(t){const e=l("sf-datepicker inline-flex",t.rootClass);return n`
        <div
                :ref=${t.component.refs.datePickerPanel}
                class=${e}
                style=${t.rootStyle||r}
                @click=${e=>t.component.handlePanelClick(e)}
        >
            <div class="sf-datepicker-container flex flex-col">
                ${u(t)}
                <div class="sf-datepicker-main relative">
                    ${h(t)}
                    <div class="grid grid-col-7">
                        ${t.days.map(e=>function(t,e){const a=l("sf-datepicker-day",t.weekend?"sf-datepicker-day-off":"",t.selected?"active":"",t.rangeStart?"sf-datepicker-day-start":"",t.rangeSelected?"sf-datepicker-day-selected":"",t.rangeEnd?"sf-datepicker-day-end":"",t.currentMonth?"":"sf-datepicker-another-month",t.disabled?"disabled":"");return n`
        <button
                class=${a}
                type="button"
                ?disabled=${t.disabled}
                data-date=${t.value}
                @click=${()=>e.component.selectDate(t)}
        >
            <span class="sf-datepicker-day-date">${t.day}</span>
        </button>
    `}(e,t))}
                    </div>
                </div>
            </div>
        </div>
    `}function c(t){const{refs:e,state:a}=t.component;return t.input?n`
        <div
                class=${l("sf-datepicker-wrap inline-flex flex-col relative",t.open?"is-open":"",a?"sf-datepicker-wrap--drop-up":"sf-datepicker-wrap--drop-down")}
                :ref=${e.datepickerRoot}
                data-portal=${t.portal?"true":"false"}
        >
            ${function(t){return n`
        <sf-input
                class="sf-datepicker-input"
                :ref=${t.component.refs.input}
                type=${t.inputType}
                size=${t.inputSize}
                name=${t.inputName||r}
                placeholder=${t.placeholder||r}
                left-icon=${t.leftIcon||r}
                root-class=${t.inputRootClass||r}
                value=${t.displayValue||""}
                ?mask=${t.mask}
                mask-pattern=${t.maskPattern||r}
                mask-lazy=${String(t.maskLazy)}
                mask-placeholder-char=${t.maskPlaceholderChar||r}
                mask-options=${t.maskOptions||r}
                readonly
                @click=${e=>t.component.handleInputClick(e)}
                @focusin=${e=>t.component.handleInputClick(e)}
        ></sf-input>
    `}(t)}
            ${t.open&&!t.portal?d(t):r}
        </div>
    `:d(t)}const m=/^(\d{4})-(\d{2})-(\d{2})$/;function p(t){return String(t).padStart(2,"0")}function g(t){return`${t.getFullYear()}-${p(t.getMonth()+1)}-${p(t.getDate())}`}function f(t,e="YYYY.MM.DD"){if(!t)return"";const a={YYYY:String(t.getFullYear()),YY:String(t.getFullYear()).slice(-2),MM:p(t.getMonth()+1),DD:p(t.getDate())};return String(e||"YYYY.MM.DD").replace(/YYYY|YY|MM|DD/g,t=>a[t]||t)}function y(t,e="DD.MM.YYYY"){if(!t)return null;if(t instanceof Date)return function(t){return t instanceof Date&&!Number.isNaN(t.getTime())}(t)?new Date(t.getFullYear(),t.getMonth(),t.getDate()):null;const a=String(t).trim(),n=function(t){if(!t)return null;const e=String(t).match(m);if(!e)return null;const[,a,n,r]=e,s=new Date(Number(a),Number(n)-1,Number(r));return s.getFullYear()!==Number(a)||s.getMonth()!==Number(n)-1||s.getDate()!==Number(r)?null:s}(a);if(n)return n;const r=a.match(/\d+/g),s=String(e||"DD.MM.YYYY").match(/YYYY|YY|MM|DD/g);if(!r||!s||r.length<3||s.length<3)return null;const i={};s.slice(0,3).forEach((t,e)=>{i[t]=Number(r[e])});let o=i.YYYY;!o&&i.YY&&(o=i.YY+2e3);const l=i.MM,u=i.DD;if(!o||!l||!u)return null;const h=new Date(o,l-1,u);return h.getFullYear()!==o||h.getMonth()!==l-1||h.getDate()!==u?null:h}function b(t,e=0){const a=i(t,e);return Number.isFinite(a)?Math.max(0,Math.min(11,a)):e}function D(t,e){return t&&e&&t.getFullYear()===e.getFullYear()&&t.getMonth()===e.getMonth()&&t.getDate()===e.getDate()}function k(t,e){if(!t||!e)return 0;return new Date(t.getFullYear(),t.getMonth(),t.getDate()).getTime()-new Date(e.getFullYear(),e.getMonth(),e.getDate()).getTime()}function v(t,e,a){return!!(t&&e&&a)&&(k(t,e)>0&&k(t,a)<0)}function V(t,e){try{return function(t=""){const e=String(t||"");return e?`${e.charAt(0).toLocaleUpperCase()}${e.slice(1)}`:""}(new Intl.DateTimeFormat(e,{month:"long"}).format(new Date(2026,t,1)))}catch{return String(t+1)}}(class extends o{constructor(){super(),this._input=null,this._documentClickHandler=this.handleDocumentClick.bind(this),this._documentKeydownHandler=this.handleDocumentKeydown.bind(this),this._viewportHandler=this.positionPanel.bind(this),this._portalRoot=null,this.state={openAbove:!1,yearPageStart:null,maxDate:this.setMaxDate(),minDate:this.setMinDate()},this.refs={input:this.createRef(),datePickerRoot:this.createRef(),datePickerPanel:this.createRef()}}static get props(){return{templateName:{attribute:"template",default:"default"},value:{default:""},date:{default:""},startValue:{attribute:"start-value",default:""},endValue:{attribute:"end-value",default:""},maxDate:{default:""},minDate:{default:""},range:{type:Boolean,default:!1},month:{type:Number,default:null},year:{type:Number,default:null},context:{default:""},weekStart:{type:Number,default:1},locale:{default:""},format:{default:"DD.MM.YYYY"},rootClass:{default:""},closeOnSelect:{type:Boolean,default:!0},input:{type:Boolean,default:!0},open:{type:Boolean,default:!1},portal:{type:Boolean,default:!0},inputType:{attribute:"input-type",default:"bordered"},inputSize:{attribute:"input-size",default:"1"},inputName:{attribute:"input-name",default:""},placeholder:{default:""},leftIcon:{attribute:"left-icon",default:"calendar_today"},inputRootClass:{attribute:"input-root-class",default:""},mask:{type:Boolean,default:!1},maskPattern:{attribute:"mask-pattern",default:""},maskLazy:{attribute:"mask-lazy",default:!1},maskPlaceholderChar:{attribute:"mask-placeholder-char",default:"_"},maskOptions:{attribute:"mask-options",default:""}}}connectedCallback(){this.upgradeProperty("value"),super.connectedCallback()}upgradeProperty(t){if(!Object.prototype.hasOwnProperty.call(this,t))return;const e=this[t];delete this[t],this[t]=e}get componentName(){return"datepicker"}get templateName(){return this.getAttribute("template")||"default"}get selectedDate(){return y(this.date,this.format)}get primaryDate(){return this.selectedDate||this.startDate}get startDate(){return y(this.startValue,this.format)}get endDate(){return y(this.endValue,this.format)}get date(){return this.getAttribute("date")||this.getAttribute("value")||""}get value(){return this.range?[this.startValue,this.endValue]:this.date}set value(t){if(Array.isArray(t)){const[e="",a=""]=t;return void this.setState({date:e||"",startValue:e||"",endValue:a||""})}if(t&&"object"==typeof t){const e=t.start||t.startValue||t.date||"",a=t.end||t.endValue||"";return void this.setState({date:t.date||e||"",startValue:e,endValue:a})}this.setState({date:t?String(t):"",startValue:"",endValue:""})}setMaxDate(){return y(this.maxDate,this.format)}setMinDate(){return y(this.minDate,this.format)}get maxDate(){return this.getAttribute("max-date")||""}get minDate(){return this.getAttribute("min-date")||""}set date(t){this.setState({date:t?String(t):""})}get startValue(){return this.getAttribute("start-value")||""}set startValue(t){this.setState({startValue:t?String(t):""})}get endValue(){return this.getAttribute("end-value")||""}set endValue(t){this.setState({endValue:t?String(t):""})}get range(){return this.getBooleanAttr("range",!1)}get input(){return this.getBooleanAttr("input",!0)}get open(){return this.getBooleanAttr("open",!1)}get portal(){return this.getBooleanAttr("portal",!0)}get inputType(){return this.getAttribute("input-type")||"bordered"}get inputSize(){return this.getAttribute("input-size")||"1"}get inputName(){return this.getAttribute("input-name")||this.getAttribute("name")||""}get placeholder(){return this.getAttribute("placeholder")||""}get leftIcon(){return this.getAttribute("left-icon")||"calendar_today"}get inputRootClass(){return this.getAttribute("input-root-class")||""}get mask(){return this.getBooleanAttr("mask",!0)}get maskPattern(){return this.getAttribute("mask-pattern")||this.formatToMask(this.format)}get maskLazy(){return!!this.hasAttribute("mask-lazy")&&this.getBooleanAttr("mask-lazy",!1)}get maskPlaceholderChar(){return this.getAttribute("mask-placeholder-char")||"_"}get maskOptions(){return this.getAttribute("mask-options")||""}get year(){const t=this.primaryDate,e=t?t.getFullYear():(new Date).getFullYear();return this.hasAttribute("year")?this.getNumberAttr("year",e):e}set year(t){this.setState({year:null==t||""===t?"":String(i(t,(new Date).getFullYear()))})}get month(){const t=this.primaryDate,e=t?t.getMonth():(new Date).getMonth();return this.hasAttribute("month")?b(this.getAttribute("month"),e):e}set month(t){this.setState({month:null==t||""===t?"":String(b(t,(new Date).getMonth()))})}get contextMode(){return this.getEnumAttr("context",["month","year",""],"")}get weekStart(){return 0===this.getNumberAttr("week-start",1)?0:1}get locale(){return function(t=""){return String(t||"").trim()||("undefined"!=typeof document&&document.documentElement?.lang?document.documentElement.lang:"undefined"!=typeof navigator&&navigator.language?navigator.language:"ru-RU")}(this.getAttribute("locale"))}get format(){return this.getAttribute("format")||"DD.MM.YYYY"}get formattedValue(){return f(this.selectedDate,this.format)}get formattedStartValue(){return f(this.startDate,this.format)}get formattedEndValue(){return f(this.endDate,this.format)}get displayValue(){return this.range?this.formattedStartValue&&this.formattedEndValue?`${this.formattedStartValue} - ${this.formattedEndValue}`:this.formattedStartValue||this.formattedEndValue||"":this.formattedValue||this.formattedStartValue}get displayDate(){return new Date(this.year,this.month,1)}get normalizedRange(){const t=this.startDate,e=this.endDate;return t&&e?k(t,e)<=0?{startDate:t,endDate:e}:{startDate:e,endDate:t}:{startDate:t,endDate:e}}get days(){const t=(new Date(this.year,this.month,1).getDay()-this.weekStart+7)%7,e=new Date(this.year,this.month,1-t),{startDate:a,endDate:n}=this.normalizedRange,r=Boolean(this.startValue&&this.endValue),{minDate:s,maxDate:i}=this.state;return Array.from({length:42}).map((t,o)=>{const l=new Date(e.getFullYear(),e.getMonth(),e.getDate()+o),u=l.getTime(),h=Boolean(s&&u<s.getTime()||i&&u>i.getTime());return{date:l,value:g(l),formattedValue:f(l,this.format),day:l.getDate(),currentMonth:l.getMonth()===this.month,weekend:[0,6].includes(l.getDay()),disabled:h,selected:this.range?D(l,a)||D(l,n):D(l,this.selectedDate),rangeStart:this.range&&r&&D(l,a),rangeEnd:this.range&&r&&D(l,n),rangeSelected:this.range&&r&&v(l,a,n)}})}get months(){const{minDate:t,maxDate:e}=this.state,a=t?new Date(t.getFullYear(),t.getMonth(),1):null,n=e?new Date(e.getFullYear(),e.getMonth(),1):null;return Array.from({length:12}).map((t,e)=>{const r=new Date(this.year,e,1).getTime(),s=Boolean(a&&r<a.getTime()||n&&r>n.getTime());return{index:e,label:V(e,this.locale),selected:e===this.month,disabled:s}})}get years(){const{minDate:t,maxDate:e}=this.state,a=this.yearPageStart;return Array.from({length:18}).map((n,r)=>{const s=a+r;return{year:s,disabled:Boolean(t&&s<t.getFullYear()||e&&s>e.getFullYear()),selected:s===this.year}})}get yearPageStart(){return this.state.yearPageStart??this.getYearPageStart(this.year)}get yearPageEnd(){return this.yearPageStart+18-1}getYearPageStart(t=this.year){const e=i(t,(new Date).getFullYear());return e-e%18}formatToMask=t=>{let e=String(t).replace(/[A-Za-z]/g,"0");return this.range&&(e+=` - ${e}`),e};setContext(t=""){return this.setState({context:t||""}),this}toggleContext(t){const e=this.contextMode===t?"":t,a={context:e};return"year"===e&&(a.yearPageStart=this.getYearPageStart(this.year)),this.setState(a),this}shiftYearPage(t=1){return this.set({yearPageStart:this.yearPageStart+18*t}),this}openPanel(){return this.open?(this.positionPanel(),this):(this.setState({open:!0}),this)}closePanel(){return this.open?(this.setState({open:!1,context:""}),this):this}togglePanel(){return this.open?this.closePanel():this.openPanel()}handleInputClick(t){t?.preventDefault?.(),t?.stopPropagation?.(),this.openPanel()}handlePanelClick(t){t?.stopPropagation?.()}handleDocumentClick(t){if(!this.open)return;const e=t.target;this.contains(e)||this.refs.datePickerPanel.value?.contains?.(e)||this.closePanel()}handleDocumentKeydown(t){this.open&&"Escape"===t.key&&(t.preventDefault(),this.contextMode?this.setContext(""):this.closePanel())}syncOverlayListeners(){if(this.input&&this.open)return document.addEventListener("click",this._documentClickHandler),document.addEventListener("keydown",this._documentKeydownHandler),window.addEventListener("resize",this._viewportHandler),void document.addEventListener("scroll",this._viewportHandler,!0);this.removeOverlayListeners()}removeOverlayListeners(){document.removeEventListener("click",this._documentClickHandler),document.removeEventListener("keydown",this._documentKeydownHandler),window.removeEventListener("resize",this._viewportHandler),document.removeEventListener("scroll",this._viewportHandler,!0)}getPortalRoot(){return"undefined"==typeof document?null:(this._portalRoot?.isConnected||(this._portalRoot=document.createElement("div"),this._portalRoot.className="sf-datepicker-portal-root",this._portalRoot.dataset.sfDatepickerPortal=this.id||this.componentName,document.body.append(this._portalRoot)),this._portalRoot)}renderPortalPanel(){if(!this.input||!this.portal||!this.open)return void this.clearPortalPanel();const t=this.getPortalRoot();t&&s(d(this.templateContext()),t)}clearPortalPanel(){this._portalRoot&&s(r,this._portalRoot)}removePortalPanel(){this._portalRoot&&(this.clearPortalPanel(),this._portalRoot.remove(),this._portalRoot=null)}positionPanel(){const t=this.refs.datePickerPanel.value;if(!(this.input&&this.portal&&this.open&&t))return;const e=this._input||this.querySelector("sf-input");if(!e)return;const a=e.getBoundingClientRect(),n=window.innerHeight||document.documentElement.clientHeight||0,r=t?.getBoundingClientRect().height||0,s=n-a.bottom-8,i=a.top-8,o=r>s&&i>s,l=o?Math.max(8,a.top-r-4):a.bottom+4;Object.assign(t?.style,{position:"fixed",top:`${Math.round(l)}px`,left:`${Math.round(a.left)}px`,zIndex:"9999"}),this.state.openAbove!==o&&this.set({openAbove:o})}selectDate(t){return!t?.date||t.disabled?this:this.range?(this.selectRangeDate(t),this):(this.setState({year:t.date.getFullYear(),month:t.date.getMonth(),date:t.value,context:""}),this.emitChange(),this.closePanel(),this)}selectRangeDate(t){if(!this.startValue||this.startValue&&this.endValue)return this.setState({year:t.date.getFullYear(),month:t.date.getMonth(),startValue:t.value,endValue:"",date:t.value,context:""}),this.emitChange(),this;const e=this.startDate,a={year:t.date.getFullYear(),month:t.date.getMonth(),context:""};return e&&k(t.date,e)<0?(a.startValue=t.value,a.endValue=this.startValue,a.date=t.value):(a.endValue=t.value,a.date=this.startValue),this.setState(a),this.emitChange(),this.closePanel(),this}selectMonth(t){return!t||t.disabled||this.setState({month:t.index,context:""}),this}selectYear(t){if(!t||t.disabled)return this;const e={year:t.year,context:""},a=this.getClosestEnabledMonth(t.year,this.month);return a!==this.month&&(e.month=a),this.setState(e),this}getClosestEnabledMonth(t,e){const{minDate:a,maxDate:n}=this.state;return a&&t===a.getFullYear()&&e<a.getMonth()?a.getMonth():n&&t===n.getFullYear()&&e>n.getMonth()?n.getMonth():e}emitChange(){const t=this.range?{value:[this.startValue,this.endValue],date:this.formattedValue,startValue:this.startValue,endValue:this.endValue,formattedValue:this.displayValue,formattedStartValue:this.formattedStartValue,formattedEndValue:this.formattedEndValue,isoValue:this.date,startIsoValue:this.startValue,endIsoValue:this.endValue,range:!0,format:this.format}:{value:this.date,date:this.date,formattedValue:this.formattedValue,isoValue:this.date,range:!1,format:this.format};this.dispatchEvent(new CustomEvent("change",{bubbles:!0,composed:!0,detail:t})),this.emitComponentEvent("change",this.data)}templateContext(){const t=this.getPropsContext();return this.createTemplateContext({...t,component:this,date:this.date,formattedValue:this.formattedValue,displayValue:this.displayValue,startValue:this.startValue,formattedStartValue:this.formattedStartValue,endValue:this.endValue,formattedEndValue:this.formattedEndValue,range:this.range,format:this.format,selectedDate:this.selectedDate,startDate:this.startDate,endDate:this.endDate,year:this.year,month:this.month,monthLabel:V(this.month,this.locale),context:this.contextMode,locale:this.locale,days:this.days,months:this.months,years:this.years,yearPageStart:this.yearPageStart,yearPageEnd:this.yearPageEnd,rootClass:this.getRootClass(),rootStyle:this.getRootStyle(),input:this.input,open:this.open,portal:this.portal,inputType:this.inputType,inputSize:this.inputSize,inputName:this.inputName,placeholder:this.placeholder,leftIcon:this.leftIcon,inputRootClass:this.inputRootClass,mask:this.mask,maskPattern:this.maskPattern,maskLazy:this.maskLazy,maskPlaceholderChar:this.maskPlaceholderChar,maskOptions:this.maskOptions})}template(){return c(this.templateContext())}afterRender(){this._input=this.refs.input?.value?.querySelector(".sf-input"),this.syncOverlayListeners(),this.renderPortalPanel(),requestAnimationFrame(()=>this.positionPanel())}onDisconnected(){this.removeOverlayListeners(),this.removePortalPanel(),super.onDisconnected()}get data(){return{value:this.value,date:this.date,formattedValue:this.formattedValue,displayValue:this.displayValue,startValue:this.startValue,formattedStartValue:this.formattedStartValue,endValue:this.endValue,formattedEndValue:this.formattedEndValue,range:this.range,format:this.format,year:this.year,month:this.month,context:this.contextMode,maxDate:this.maxDate,minDate:this.minDate,locale:this.locale,input:this.input,open:this.open,portal:this.portal,mask:this.mask,maskPattern:this.maskPattern,maskOptions:this.maskOptions}}}).define("sf-datepicker")})();