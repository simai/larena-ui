import { html, nothing } from "lit";
import { renderListItemTemplate } from "../../../list-item/js/templates/default";
import { nearestFieldSize } from "../../../../component/field-size";

function normalizeSizeGroup(value) {
  const size = String(value || "1");

  if (size === "1/3" || size === "1/2") {
    return {
      item: size,
      checkbox: nearestFieldSize(size),
      avatarGroup: "1/2",
      colorTag: "1/2",
    };
  }

  return {
    item: size,
    checkbox: nearestFieldSize(size),
    avatarGroup: size,
    colorTag: "1",
  };
}

function getOptionLabel(option = {}) {
  if (option.type === "avatar") return option.avatarTitle || option.text || option.value || "";
  return option.text || option.avatarTitle || option.value || "";
}

function renderOption(option) {
  return renderListItemTemplate({
    component: {
      hasSlotContent: () => false,
      getSlotContent: () => nothing,
    },
    templateName: "default",
    type: option.type,
    size: option.size,
    sizeGroup: normalizeSizeGroup(option.size),
    text: option.text,
    icon: option.icon,
    checked: option.checked || option.selected,
    selected: option.selected,
    disabled: option.disabled,
    value: option.value,
    colorClass: option.colorClass,
    avatarImageUrl: option.avatarImageUrl,
    avatarTitle: option.avatarTitle,
    ariaLabel: option.ariaLabel,
    option: true,
  });
}

// From size 1 up the field has room for a compact tag of its own size, with the
// field's own text. Size 1/2 does not (one pixel would be left), so its tag
// goes one size down onto the field line, rendered inline: its label is one
// text step down and it takes no block padding.
const FIELD_TAG = Object.freeze({
  "1/2": {size: "1/3", spacing: ""},
  "1": {size: "1", spacing: "compact"},
  "2": {size: "2", spacing: "compact"},
});

// A single choice shows its picture in the field as well as its label.
function renderFieldVisual(context) {
  if (context.multiple || context.selectedOptions?.length !== 1) return nothing;
  const option = context.selectedOptions[0];
  if (option.type === "icon" && option.icon) {
    return html`<i class="sf-icon sf-dropdown-field-visual" aria-hidden="true">${option.icon}</i>`;
  }
  if (option.type === "color" && option.colorClass) {
    return html`<span class="sf-tag-color-icon sf-dropdown-field-visual ${option.colorClass}" aria-hidden="true"></span>`;
  }
  if (option.type === "avatar" && option.avatarImageUrl) {
    return html`<span class="sf-avatar sf-avatar--size-1/2 bg-cover sf-dropdown-field-visual" aria-hidden="true" style=${`background-image: url(${option.avatarImageUrl});`}></span>`;
  }
  return nothing;
}

function renderTag(context, option) {
  const label = getOptionLabel(option);
  const fieldTag = FIELD_TAG[context.size] || FIELD_TAG["1"];
  const tagSize = fieldTag.size;
  const tagSpacing = fieldTag.spacing ? ` spacing-${fieldTag.spacing}` : "";
  const tagType =
    option.type === "color" ? "color" : option.type === "avatar" ? "avatar" : "icon";

  return html`
    <div
      class="sf-tag transition sf-tag--${tagType} sf-tag--size-${tagSize} sf-tag--inline${tagSpacing} flex flex-row flex-nowrap items-center active"
      data-value=${option.value}
    >
      ${option.type === "color"
        ? html`<span class="sf-tag-color-icon ${option.colorClass}" aria-hidden="true"></span>`
        : nothing}
      ${option.type === "icon"
        ? html`<i class="sf-icon sf-tag-icon" aria-hidden="true">${option.icon}</i>`
        : nothing}
      ${option.type === "avatar"
        ? html`
            <span
              class="sf-avatar sf-avatar--size-${tagSize} bg-cover"
              aria-hidden="true"
              style=${option.avatarImageUrl
                ? `background-image: url(${option.avatarImageUrl});`
                : nothing}
            ></span>
          `
        : nothing}
      <span class="sf-tag-container">${label}</span>
      <button
        type="button"
        class="sf-icon-button sf-icon-button--link sf-icon-button--on-surface sf-icon-button--size-1/3"
        aria-label=${`Remove ${label}`}
        ?disabled=${context.disabled}
        @click=${(event) => {
          event.preventDefault();
          event.stopPropagation();
          context.component.removeSelectedValue(option.value);
        }}
      >
        <div class="sf-close sf-close--size-1/3 flex">
          <div class="sf-close-icon"></div>
        </div>
      </button>
    </div>
  `;
}

export function renderDropdownTemplate(context) {
  const rootClasses = [
    "sf-dropdown",
    context.rootClass,
    context.open ? "open" : "",
    context.open ? "sf-dropdown--open" : "",
    `sf-dropdown--size-${context.size}`,
    `sf-dropdown--${context.appearance ?? context.type}`,
    context.mode === "tag" ? "sf-dropdown--tag" : "",
    context.mode !== "tag" ? "sf-dropdown--text" : "",
    context.disabled ? "disabled" : "",
    "flex",
    "flex-col",
  ].filter(Boolean);

  const fieldClasses = [
    "sf-dropdown-field",
    !context.disabled ? "cursor-pointer" : "",
    "items-cross-center",
    "relative",
    "transition",
    "flex",
  ].filter(Boolean);

  const iconButtonSize =
    context.size === "1" || context.size === "1/2" ? "1/2" : context.size;
  const listInputSize = context.size;
  const dropdownIcon = context.open ? "keyboard_arrow_up" : "keyboard_arrow_down";

  const renderTrigger = () => {
    const hiddenInput = context.name
      ? html`
          <input
            class="sf-dropdown-hidden-input"
            type="hidden"
            name=${context.name}
            value=${context.value || ""}
            ?disabled=${context.disabled}
          />
        `
      : nothing;

    if (context.mode === "tag") {
      return html`
        <div
          class=${fieldClasses.join(" ")}
          @click=${(event) => context.component.handleTriggerClick(event)}
        >
          ${hiddenInput}
          <div class="sf-dropdown-tag-container flex flex-wrap flex-1">
            ${context.selectedOptions.map((option) => renderTag(context, option))}
          </div>
          <button
            type="button"
            class="sf-icon-button sf-icon-button--icon sf-icon-button--on-surface sf-icon-button--link sf-icon-button--size-${iconButtonSize}"
            ?disabled=${context.disabled}
          >
            <i class="sf-icon" aria-hidden="true">${dropdownIcon}</i>
          </button>
        </div>
      `;
    }

    return html`
      <label
        class=${fieldClasses.join(" ")}
        @click=${(event) => context.component.handleTriggerClick(event)}
      >
        ${hiddenInput}
        ${renderFieldVisual(context)}
        <input
          placeholder=${context.placeholder}
          type="text"
          class="cursor-pointer"
          .value=${context.triggerText || ""}
          readonly
          ?disabled=${context.disabled}
        />
        <button
          type="button"
          class="sf-icon-button sf-icon-button--icon sf-icon-button--on-surface sf-icon-button--link sf-icon-button--size-${iconButtonSize} absolute"
          ?disabled=${context.disabled}
        >
          <i class="sf-icon" aria-hidden="true">${dropdownIcon}</i>
        </button>
      </label>
    `;
  };

  return html`
    <div
      class=${rootClasses.join(" ")}
      style=${context.rootStyle || nothing}
      ?disabled=${context.disabled}
      ?multiple=${context.multiple}
      ?portal=${context.portal}
      data-portal=${context.portal ? "true" : "false"}
    >
      ${context.label || context.required
        ? html`
            <span class="sf-dropdown-label flex">
              ${context.label
                ? html`<span class="sf-dropdown-text">${context.label}</span>`
                : nothing}
              ${context.required
                ? html`<span class="sf-dropdown-required">*</span>`
                : nothing}
            </span>
          `
        : nothing}
      ${renderTrigger()}

      <div class="sf-list flex flex-col" ?hidden=${!context.open}>
        ${context.search
          ? html`
              <label
                class="sf-input sf-input--size-${listInputSize} sf-input--filled flex flex-col"
              >
                <span class="sf-input-field items-cross-center transition flex">
                  <input
                    placeholder=${context.searchPlaceholder}
                    type="text"
                    .value=${context.searchValue || ""}
                    ?disabled=${context.disabled}
                    @input=${(event) => context.component.handleSearchInput(event)}
                    @click=${(event) => event.stopPropagation()}
                  />
                  <i class="sf-icon sf-icon-hint" aria-hidden="true">search</i>
                </span>
              </label>
            `
          : nothing}
        <div class="sf-list-container-wrap">
          <div
            class="sf-list-container flex flex-col"
            @click=${(event) => context.component.handleOptionClick(event)}
            @keydown=${(event) => context.component.handleOptionKeydown(event)}
          >
            ${context.options.map((option) => renderOption(option))}
          </div>
        </div>
      </div>
    </div>
  `;
}
