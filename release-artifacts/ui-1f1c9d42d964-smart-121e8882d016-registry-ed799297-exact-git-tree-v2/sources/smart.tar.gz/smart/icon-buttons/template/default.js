import {html, nothing} from 'lit';
import './default.css';

export function renderIconButtonTemplate(context) {
    const {
        size,
        type,
        scheme,
        icon,
        segment,
        tightness,
        variant,
        radius,
        filled,
        rootClass,
        loading,
        disabled,
        nativeType,
        ariaLabel,
    } = context;

    const rootClasses = [
        'sf-icon-button',
        `sf-icon-button--size-${size || '1'}`,
        `sf-icon-button--${variant || 'icon'}`,
        `sf-icon-button--${type || 'default'}`,
        'flex',
        'items-cross-center',
        segment ? `segment-${segment}` : '',
        `sf-icon-button--${scheme || 'primary'}`,
        tightness ? `tightness-${tightness}` : '',
        radius ? `radius-${radius}` : '',
        rootClass,
        loading ? 'loading sf-icon-button-state-loading' : '',
    ].filter(Boolean);

    const iconContent =
        context.component?.hasSlotContent?.('icon')
            ? context.component.getSlotContent('icon')
            : variant === 'close'
                ? html`
                            <sf-close root-class="pointer-event-none" size="${size || '1'}"></sf-close>`
                : html`
                            <sf-icon filled="${filled}" root-class="pointer-event-none" icon="${icon}" weight="400" aria-hidden="true"></sf-icon>`;

    return html`
        <button
                type=${nativeType}
                class=${rootClasses.join(' ')}
                style=${context.rootStyle || nothing}
                ?disabled=${disabled || loading}
                aria-label=${ariaLabel || nothing}
                aria-busy=${loading ? 'true' : nothing}
        >
            ${iconContent}
        </button>
    `;
}
