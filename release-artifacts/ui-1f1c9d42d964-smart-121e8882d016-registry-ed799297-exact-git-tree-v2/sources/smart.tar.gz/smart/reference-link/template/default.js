import { html, nothing } from 'lit';

export function renderReferenceLinkTemplate(context) {
  const { component, icon, label, text, href, target, disabled, ariaLabel, rootClass } =
    context;

  const rootClasses = [
    'sf-reference-link',
    'flex',
    'items-cross-center',
    disabled ? 'disabled' : '',
    rootClass,
  ]
    .filter(Boolean)
    .join(' ');

  const labelContent =
    component?.hasSlotContent?.('label')
      ? component.getSlotContent('label')
      : label;

  const textContent =
    component?.hasSlotContent?.('text')
      ? component.getSlotContent('text')
      : text;

  const linkContent =
    href && !disabled
      ? html`
          <a class="sf-reference-link__link"
            href=${href}
            target=${target || nothing}
            rel=${target && target !== '_self' ? 'noopener noreferrer' : nothing}
            aria-label=${ariaLabel || nothing}
          >
            ${labelContent}
          </a>
        `
      : html`<span>${labelContent}</span>`;

  return html`
    <div
      class=${rootClasses}
      style=${context.rootStyle || nothing}
      @click=${component?.handleRootClick}
      aria-disabled=${disabled ? 'true' : nothing}
    >
      <div class="sf-reference-link__main sf-reference-link-left">
        <i class="sf-reference-link__icon sf-icon" aria-hidden="true">${icon}</i>
        ${linkContent}
      </div>
      <div class="sf-reference-link__meta sf-reference-link-text">${textContent}</div>
    </div>
  `;
}
