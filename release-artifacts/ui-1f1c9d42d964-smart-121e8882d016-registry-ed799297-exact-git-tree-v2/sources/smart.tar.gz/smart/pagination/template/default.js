import { html, nothing } from "lit";

function joinClasses(...tokens) {
  return tokens.flat().filter(Boolean).join(" ");
}

function renderPageItem(item, context) {
  if (item.type === "ellipsis") {
    return html`
      <li class="sf-pagination-item sf-pagination-item--ellipsis" aria-hidden="true">
        <span class="sf-page-number sf-page-number--ellipsis">…</span>
      </li>
    `;
  }

  return html`
    <li
      class=${joinClasses(
        "sf-pagination-item",
        item.edge ? "sf-pagination-item--edge" : "",
        item.selected ? "sf-pagination-item--current" : "",
      )}
    >
      <button
        type="button"
        class=${joinClasses(
          "sf-page-number",
          "sf-page-number--square",
          item.selected ? "selected" : "",
        )}
        data-page=${String(item.value)}
        aria-current=${item.selected ? "page" : nothing}
        aria-label=${`${context.pageLabel} ${item.value}`}
        @click=${() => context.component.goToPage(item.value)}
      >
        ${item.value}
      </button>
    </li>
  `;
}

export function renderPaginationTemplate(context) {
  const { component } = context;
  const rootClasses = joinClasses(
    "sf-pagination",
    "flex",
    "flex-col",
    context.rootClass,
  );
  const topClasses = joinClasses(
    "sf-pagination-top",
    "flex",
    "content-main-center",
    context.topClass,
  );
  const mainClasses = joinClasses(
    "sf-pagination-main",
    "flex",
    "items-cross-center",
    "content-main-between",
    context.mainClass,
  );
  const bottomClasses = joinClasses(
    "sf-pagination-bottom",
    "flex",
    "items-cross-center",
    context.bottomClass,
  );

  return html`
    <nav
      class=${rootClasses}
      style=${context.rootStyle || nothing}
      aria-label=${context.ariaLabel}
    >
      ${context.top
        ? html`
            <div class=${topClasses}>
              <sf-button
                size="1"
                type="outline"
                ?disabled=${!context.hasNext}
                scheme="primary"
                @click=${(e) => component.showMore(e.target)}
                text="${context.showMoreText}"
              ></sf-button>
            </div>
          `
        : ""}
      ${context.middle
        ? html`
            <div class=${mainClasses}>
              <div class="sf-pagination-left flex items-cross-center">
                <div class="sf-pagination-marked flex">
                  <div class="sf-pagination-marked-text">
                    ${context.selectedLabel}
                  </div>
                  <div class="sf-pagination-marked-text">
                    ${context.selectedCount}/${context.total}
                  </div>
                </div>
                <div class="sf-pagination-total flex items-cross-center">
                  <div class="sf-pagination-total-text">
                    ${context.totalLabel} ${context.total}
                  </div>
                </div>
              </div>

              ${context.total > 0
                ? html`
                    <div class="sf-pagination-container flex items-cross-center">
                      <span class="sf-pagination-pages-label">${context.pagesLabel}</span>
                      <ol class="sf-pagination-list flex items-cross-center">
                        <li class="sf-pagination-item">
                          <sf-icon-button
                            class="sf-pagination-direction sf-pagination-direction--prev"
                            size="1"
                            type="link"
                            scheme="on-surface"
                            icon="keyboard_arrow_left"
                            ?disabled=${!context.hasPrev}
                            aria-label=${context.previousLabel}
                            @click=${() =>
                              component.goToPage(context.current - 1)}
                          ></sf-icon-button>
                        </li>
                        ${context.pageItems.map((item) =>
                          renderPageItem(item, context),
                        )}
                        <li class="sf-pagination-item">
                          <sf-icon-button
                            class="sf-pagination-direction sf-pagination-direction--next"
                            size="1"
                            type="link"
                            scheme="on-surface"
                            icon="keyboard_arrow_right"
                            ?disabled=${!context.hasNext}
                            aria-label=${context.nextLabel}
                            @click=${() =>
                              component.goToPage(context.current + 1)}
                          ></sf-icon-button>
                        </li>
                      </ol>
                      <span class="sf-pagination-last">
                        <sf-button
                          size="1"
                          type="link"
                          scheme="primary"
                          ?disabled=${!context.hasNext}
                          text=${context.lastLabel}
                          @click=${() => component.lastPage()}
                        ></sf-button>
                      </span>
                    </div>
                  `
                : ""}

              ${context.showPageSize && context.total > 0
                ? html`
                    <div class="sf-pagination-count flex items-cross-center">
                      <span>${context.pageSizeLabel}</span>
                      <sf-dropdown
                        size="1"
                        type="outlined"
                        search="false"
                        mode="select"
                        portal="true"
                        value=${String(context.pageSize)}
                        aria-label=${context.pageSizeLabel}
                        @change=${(event) =>
                          component.setPageSize(Number(event.detail.value))}
                      >
                        ${(context.pageSizes || []).map(
                          (size) => html`
                            <sf-list-item
                              type="text"
                              size="1"
                              text=${String(size)}
                              value=${String(size)}
                              ?selected=${Number(size) ===
                              Number(context.pageSize)}
                            ></sf-list-item>
                          `,
                        )}
                      </sf-dropdown>
                    </div>
                  `
                : ""}
            </div>
          `
        : ""}
      ${context.bottom && context.showActions && context.actions?.length
        ? html`
            <div class=${bottomClasses}>
              ${context.showActions && context.actions?.length
                ? html`
                    <sf-dropdown
                      size="1"
                      type="outlined"
                      search="false"
                      mode="select"
                      value=${context.action}
                      aria-label=${context.actionsLabel}
                      @change=${(event) =>
                        component.setAction(event.detail.value)}
                    >
                      ${context.actions.map(
                        (action) => html`
                          <sf-list-item
                            type="text"
                            size="1"
                            text=${action.text}
                            value=${action.value}
                            ?selected=${action.value === context.action}
                            ?disabled=${Boolean(action.disabled)}
                          ></sf-list-item>
                        `,
                      )}
                    </sf-dropdown>
                    <sf-button
                      size="1"
                      type="default"
                      scheme="primary"
                      text=${context.actionApplyText}
                      ?disabled=${!context.action}
                      @click=${() => component.applyAction()}
                    ></sf-button>
                    ${context.showActionForAll
                      ? html`
                          <sf-checkbox
                            label=${context.actionForAllLabel}
                            ?checked=${Boolean(context.actionForAll)}
                            @click=${() =>
                              component.setActionForAll(!context.actionForAll)}
                          ></sf-checkbox>
                        `
                      : ""}
                  `
                : ""}
            </div>
          `
        : ""}
    </nav>
  `;
}
