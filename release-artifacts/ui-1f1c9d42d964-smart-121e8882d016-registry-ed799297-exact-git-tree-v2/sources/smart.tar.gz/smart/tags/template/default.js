import {html, nothing} from 'lit';
import './default.css';

function closeSize(size) {
    return size === '1' ? '1/3' : '1/4';
}

function dotSize(size) {
    return size === '1' ? '1/2' : '1/3';
}

function renderCheckboxIcon(context) {
    return context.component?.hasSlotContent?.('leading')
        ? context.component.getSlotContent('leading')
        : html`<span class="sf-tag-check" aria-hidden="true"></span>`;
}

function renderGenericIcon(context) {
    const iconName = context.icon || 'sell';

    return context.component?.hasSlotContent?.('leading')
        ? context.component.getSlotContent('leading')
        : html`<i class="sf-icon sf-tag-icon" aria-hidden="true">${iconName}</i>`;
}

function renderColorIcon(context) {
    const extraClass = context.colorClass || '';

    return context.component?.hasSlotContent?.('leading')
        ? context.component.getSlotContent('leading')
        : html`<span class=${['sf-tag-color-icon', extraClass].filter(Boolean).join(' ')} aria-hidden="true"></span>`;
}

function renderStatusDot(context) {
    return context.component?.hasSlotContent?.('leading')
        ? context.component.getSlotContent('leading')
        : html`
                <span class="sf-dot sf-dot--size-${dotSize(context.size)}" aria-hidden="true">
                    <div class="sf-dot-item"></div>
                </span>
        `;
}

function renderAvatar(context) {
    if (context.component?.hasSlotContent?.('avatar')) {
        return context.component.getSlotContent('avatar');
    }

    if (context.avatarImageUrl) {
        return html`
            <span
                    class="sf-avatar sf-avatar--size-1/4 bg-cover"
                    aria-hidden="true"
                    style=${`background-image: url(${context.avatarImageUrl});`}
            ></span>
        `;
    }

    if (context.avatarText) {
        return html`
            <span class="sf-avatar sf-avatar--size-1/4 sf-avatar--text flex justify-center items-center" aria-hidden="true">
        ${context.avatarText}
      </span>
        `;
    }

    return html`
        <span class="sf-avatar sf-avatar--size-1/4 sf-avatar--placeholder flex justify-center items-center" aria-hidden="true">
      <i class="sf-icon">person</i>
    </span>
    `;
}

function renderLeading(context) {
    switch (context.type) {
        case 'checkbox':
            return renderCheckboxIcon(context);
        case 'icon':
            return renderGenericIcon(context);
        case 'color':
            return renderColorIcon(context);
        case 'avatar':
            return renderAvatar(context);
        case 'success':
        case 'error':
        case 'warning':
            return renderStatusDot(context);
        default:
            return nothing;
    }
}

function renderCount(context) {
    if (context.type !== 'default') return nothing;

    return context.component?.hasSlotContent?.('count')
        ? context.component.getSlotContent('count')
        : html`<span class="sf-tag-count pointer-events-none flex">${context.count || nothing}</span>`;
}

function renderClose(context) {
    if (!context.closable || context.type === 'checkbox') return nothing;

    return context.component?.hasSlotContent?.('close')
        ? context.component.getSlotContent('close')
        : html`
                <sf-icon-button
                        variant="close"
                        size="${closeSize(context.size)}"
                        type="link"
                        scheme="on-surface"
                        ?disabled=${context.disabled}
                        aria-label=${context.closeLabel}
                        @click="${(e) => {
                            e.stopPropagation();
                            context.component.onClose();
                        }}"
                ></sf-icon-button>
        `;
}

export function renderTagTemplate(context) {
    const textContent = context.component?.hasSlotContent?.('text')
        ? context.component.getSlotContent('text')
        : context.text;

    const classes = [
        'sf-tag',
        `sf-tag--${context.type}`,
        `sf-tag--size-${context.size}`,
        'inline-flex',
        'flex-row',
        'flex-nowrap',
        'items-center',
        `${context.rootClass}`,
        context.type === 'checkbox' ? 'sf-tag--interactive' : '',
        context.closable ? 'sf-tag--removable' : '',
        context.active ? 'active' : '',
        context.disabled ? 'disabled' : '',
    ].filter(Boolean);

    const content = html`
            ${renderLeading(context)}
            <span class="sf-tag-container pointer-events-none">${textContent}</span>
            ${renderCount(context)}
            ${renderClose(context)}
    `;

    if (context.type === 'checkbox') {
        return html`
            <button
                    type="button"
                    class=${classes.join(' ')}
                    style=${context.rootStyle || nothing}
                    aria-label=${context.ariaLabel || nothing}
                    aria-pressed=${String(context.active)}
                    ?disabled=${context.disabled}
                    @click=${() => context.component.onToggle()}
            >${content}</button>
        `;
    }

    return html`
        <div
                class=${classes.join(' ')}
                style=${context.rootStyle || nothing}
        >${content}</div>
    `;
}
