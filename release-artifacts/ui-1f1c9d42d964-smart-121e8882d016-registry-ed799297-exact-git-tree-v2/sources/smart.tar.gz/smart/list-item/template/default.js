import { html, nothing } from "lit";

export function renderListItemTemplate(context) {
  const isOption = context.option === true;
  const textContent = context.component?.hasSlotContent?.("text")
    ? context.component.getSlotContent("text")
    : context.text;

  const leadingContent = context.component?.hasSlotContent?.("leading")
    ? context.component.getSlotContent("leading")
    : nothing;

  const trailingContent = context.component?.hasSlotContent?.("trailing")
    ? context.component.getSlotContent("trailing")
    : nothing;

  const classes = [
    "sf-list-item",
    "flex",
    "items-cross-center",
    `sf-list-item--${context.type}`,
    `sf-list-item--size-${context.size}`,
    isOption ? "cursor-pointer" : "",
    context.selected ? "selected" : "",
    context.disabled ? "disabled" : "",
    context.rootClass,
  ].filter(Boolean);

  const wrapClasses = ["sf-list-item-wrap", "flex", "flex-1"];
  const isDecoratedType = ["icon", "checkbox", "avatar", "color"].includes(
    context.type,
  );

  if (isDecoratedType) {
    wrapClasses.push(
      "flex",
      "flex-row",
      "flex-nowrap",
      "items-center",
      "gap-2",
    );
  }

  if (context.type === "avatar" || context.type === "color") {
    wrapClasses.splice(wrapClasses.indexOf("gap-2"), 1);
    wrapClasses.push("justify-between", "gap-2");
  }

  const renderLeading = () => {
    if (leadingContent !== nothing) return leadingContent;

    if (context.type === "icon") {
      return html`<i class="sf-icon" aria-hidden="true">${context.icon}</i>`;
    }

    if (context.type === "checkbox") {
      return html`
        <label
          class="sf-checkbox sf-checkbox--size-${context.sizeGroup
            .checkbox} flex"
          aria-hidden="true"
        >
          <span class="sf-checkbox-box flex">
            <input
              ?checked=${context.checked || context.selected}
              ?disabled=${context.disabled}
              tabindex="-1"
              type="checkbox"
            />
            <span class="sf-icon" aria-hidden="true"></span>
          </span>
        </label>
      `;
    }

    if (context.type === "avatar") {
      const avatarClasses = [
        "sf-avatar",
        `sf-avatar--size-${context.sizeGroup.item === "1/3" || context.sizeGroup.item === "1/2" ? "1/3" : context.sizeGroup.item === "1" ? "1/2" : context.sizeGroup.item === "2" ? "1" : "2"}`,
        "bg-cover",
        context.disabled ? "disabled" : "",
      ].filter(Boolean);

      return html`
        <div
          class="sf-avatar-label-group sf-avatar-label-group--size-${context
            .sizeGroup.avatarGroup} flex items-cross-center"
        >
          <span
            class=${avatarClasses.join(" ")}
            aria-hidden="true"
            style=${context.avatarImageUrl
              ? `background-image: url(${context.avatarImageUrl});`
              : nothing}
          ></span>
          <div class="sf-avatar-label-group-container flex flex-col">
            <div class="sf-avatar-label-group-title">
              ${context.avatarTitle}
            </div>
          </div>
        </div>
      `;
    }

    if (context.type === "color") {
      const tagClasses = [
        "sf-tag",
        "sf-tag--color",
        `sf-tag--size-${context.sizeGroup.colorTag}`,
        "flex",
        "flex-row",
        "flex-nowrap",
        "items-center",
        "flex-1",
        context.disabled ? "disabled" : "",
      ].filter(Boolean);

      return html`
        <div class=${tagClasses.join(" ")}>
          <span class="sf-tag-color-icon ${context.colorClass}" aria-hidden="true"></span>
          <span class="sf-tag-container">${textContent}</span>
        </div>
      `;
    }

    return nothing;
  };

  const renderText = () => {
    if (context.type === "color") return nothing;
    if (context.type === "avatar") return nothing;
    return html`<div class="sf-list-item-container">${textContent}</div>`;
  };

  const renderTrailing = () => {
    if (trailingContent !== nothing) return trailingContent;

    if (context.type === "avatar" || context.type === "color") {
      return html`
        <label
          class="sf-checkbox sf-checkbox--size-${context.sizeGroup
            .checkbox} flex"
          aria-hidden="true"
        >
          <span class="sf-checkbox-box flex">
            <input
              ?checked=${context.checked || context.selected}
              ?disabled=${context.disabled}
              tabindex="-1"
              type="checkbox"
            />
            <span class="sf-icon" aria-hidden="true"></span>
          </span>
        </label>
      `;
    }

    return nothing;
  };

  return html`
    <div
      class=${classes.join(" ")}
      style=${context.rootStyle || nothing}
      role=${isOption ? "option" : nothing}
      tabindex=${isOption ? "-1" : nothing}
      data-value=${isOption ? context.value || nothing : nothing}
      aria-label=${isOption ? context.ariaLabel || nothing : nothing}
      aria-disabled=${isOption && context.disabled ? "true" : nothing}
      aria-selected=${isOption ? (context.selected ? "true" : "false") : nothing}
    >
      <div class=${wrapClasses.join(" ")}>
        ${renderLeading()} ${renderText()} ${renderTrailing()}
      </div>
    </div>
  `;
}
