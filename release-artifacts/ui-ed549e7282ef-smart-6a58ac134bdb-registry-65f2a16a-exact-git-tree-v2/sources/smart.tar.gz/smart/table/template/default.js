import {html, nothing} from "lit";
import {keyed} from "lit/directives/keyed.js";
import {ref} from "lit/directives/ref.js";
import "./default.css";
import {normalizeTableLinkCell} from "./link-cell-contract.js";

function getEventInputValue(event, fallback = '') {
    const pathTarget = event?.composedPath?.()?.[0];
    const candidates = [pathTarget, event?.target, event?.currentTarget];

    for (const candidate of candidates) {
        if (!candidate) continue;

        if (typeof candidate.value !== 'undefined') {
            return candidate.value;
        }

        const input = candidate.querySelector?.('input, textarea');
        if (input && typeof input.value !== 'undefined') {
            return input.value;
        }
    }

    return fallback;
}

function renderToolbar(context) {
    const {state} = context.component;
    const {value} = state.search;
    const filterTags = context.component.getCurrentFilterTags();
    const filterValues = context.component.getCurrentFilterValues();
    const hasUnsavedFilterDataChanges =
        context.component.hasUnsavedFilterDataChanges();
    const activeFilterTags = Object.entries(filterTags || {}).filter(
        ([, tag]) => tag?.active !== false,
    );
    return html`
        <div
                class="sf-table-toolbar flex flex-wrap gap-1/2 items-cross-start content-main-between flex-none"
                data-sf-filter-tags="${activeFilterTags.length ? '1' : '0'}"
        >
            <div class="sf-table-toolbar-start flex items-cross-center gap-1/3 flex-wrap min-w-0">
                <div class="flex items-cross-center">
                    <sf-button
                            size="1"
                            type="default"
                            scheme="primary"
                            text=${context.filterText}
                            segment="start"
                            icon-left="filter_list"
                            @click=${(e) => {
                                context.component.openContextMenu(e, {
                                    type: 'bottom',
                                    menu: 'filter-settings',
                                })
                            }}
                    ></sf-button>
                    <sf-icon-button
                            size="1"
                            type="default"
                            scheme="primary"
                            aria-label="Сохранить шаблон фильтра"
                            ?disabled=${!activeFilterTags.length}
                            segment="end"
                            icon="bookmark_add"
                            @click=${(e) => {
                                context.component.openContextMenu(e, {
                                    type: 'bottom',
                                    menu: 'filter-favorites',
                                    parent: true
                                })
                            }}
                    ></sf-icon-button>
                </div>
                ${activeFilterTags.map(([k, tag]) => {
                    const filterValue = filterValues?.[k] || {};
                    const hasFilteredValues = Object.prototype.hasOwnProperty.call(
                            filterValues || {},
                            k,
                    );
                    const count = Array.isArray(filterValue.values)
                            ? filterValue.values.length
                            : tag.count || '';

                    return html`
                        <div class="sf-table-tags">
                            <sf-tag
                                    type="default"
                                    size="1"
                                    text='${tag.label}'
                                    interactive
                                    closable
                                    :key=${k}
                                    root-class="${hasFilteredValues ? 'active' : ''}"
                                    @close="${() => {
                                        context.component.removeFilterTag(k);
                                    }}"
                                    @click=${(e) => {
                                        context.component.openContextMenu(e, {
                                            type: 'bottom',
                                            menu: 'tag-settings',
                                            fieldKey: k,
                                            anchorSelector: '.sf-tag',
                                        })
                                    }}
                                    count='${count}'
                            ></sf-tag>
                        </div>`
                })}
                ${activeFilterTags.length || hasUnsavedFilterDataChanges ? html`
                    ${hasUnsavedFilterDataChanges ? html`
                        <sf-button
                                size="1"
                                type="default"
                                scheme="primary"
                                text="Сохранить"
                                @click="${() => context.component.saveCurrentFilterTemplateData()}"
                        ></sf-button>
                    ` : nothing}
                    ${activeFilterTags.length ? html`
                        <sf-button
                                size="1"
                                type="outline"
                                scheme="on-surface"
                                text=${context.clearText}
                                @click="${() => context.component.removeFilterTag()}"
                        ></sf-button>
                    ` : nothing}
                ` : nothing}
            </div>

            <div class="sf-table-toolbar-end flex items-cross-center gap-1/3 flex-wrap flex-auto min-w-0">
                <sf-input
                        size="1"
                        root-class="sf-search-input m-inline-start-auto"
                        type="bordered"
                        value="${value}"
                        placeholder=${context.searchPlaceholder}
                        name="sf_table_search"
                        @input=${(e) => {
                            context.component.searchChange({
                                value: getEventInputValue(e, value)
                            });
                        }}
                        @keydown=${(e) => {
                            context.component.handleSearchKeyDown(e);
                        }}
                        @keyup=${(e) => {
                            context.component.handleSearchKeyUp(e);
                        }}
                        hint-icon="search"
                >
          <span slot="right">
                <sf-icon-button
                        size="1"
                        type="link"
                        scheme="on-surface"
                        icon=${value.length ? 'close' : 'search'}
                        aria-label=${value.length ? 'Очистить поиск' : 'Поиск'}
                        @click=${(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            if (!value.length) return false;
                            context.component.updateSearchState({
                                value: '',
                            });
                        }}
                ></sf-icon-button>

          </span>
                </sf-input>

                ${context.actions
                        ? html`
                            <div class="flex items-cross-center">
                                <sf-button
                                        size="1"
                                        type="outline"
                                        scheme="on-surface"
                                        text=${context.createText}
                                        segment=${state.createItems?.length ? 'start' : nothing}
                                        @click=${() => context.component.requestCreateIntent(null)}
                                ></sf-button>
                                ${state.createItems?.length ? html`
                                    <sf-icon-button
                                            size="1"
                                            type="outline"
                                            scheme="primary"
                                            segment="end"
                                            icon="keyboard_arrow_down"
                                            aria-label="Дополнительные действия создания"
                                            aria-haspopup="menu"
                                            @click=${(e) => {
                                                context.component.openContextMenu(e, {
                                                    type: 'bottom',
                                                    menu: 'create',
                                                });
                                            }}
                                    ></sf-icon-button>
                                ` : nothing}
                            </div>
                        `
                        : nothing}

                ${context.settings
                        ? html`
                            <sf-icon-button
                                    size="1"
                                    type="outline"
                                    scheme="primary"
                                    icon="settings"
                                    aria-label="Настройки таблицы"
                                    @click=${e => {
                                        context.component.openContextMenu(e, { menu: 'table-settings' });
                                    }}
                            ></sf-icon-button>
                        `
                        : nothing}
            </div>
        </div>
    `;
}


// The state the region is actually in: the author's data-state, or what the
// rows resolve to. It is declared on the region, not guessed from the markup.
export function resolvedDataState(context) {
    if (context.dataState !== 'auto') return context.dataState;
    return (context.component?.getTableData?.().rows || []).length ? 'populated' : 'empty';
}

function renderHeadLabel(context, column) {
    const content = column.component
        ? context.component.renderSmartElement(column.component.type, column.component.props)
        : column.label;
    if (column.sortable !== true || column.system) {
        return content;
    }
    const sort = context.component.state.sort || {};
    const direction = sort.key === column.key ? sort.direction : null;
    const icon = direction === 'asc' ? 'arrow_upward' : direction === 'desc' ? 'arrow_downward' : 'unfold_more';

    return html`
        <button type="button" class="sf-table-sort-button flex items-cross-center gap-1/4 min-w-0"
                data-direction=${direction || nothing}>
            <span class="truncate">${content}</span>
            <i class="sf-icon sf-table-sort-icon" aria-hidden="true">${icon}</i>
        </button>
    `;
}

function ariaSort(context, column) {
    if (column.sortable !== true || column.system) return nothing;
    const sort = context.component.state.sort || {};
    if (sort.key !== column.key) return 'none';
    return sort.direction === 'asc' ? 'ascending' : 'descending';
}

function renderHead(context) {
    if (context.component?.hasSlotContent?.("head")) {
        return context.component.getSlotContent("head");
    }
    const columns = context.component?.getColumns?.() || [];

    return html`
        <thead class="sticky top-0 z-5">
        <tr>
            ${columns.map((column, k) => {
                        return keyed(`head:${column.key}`, html`
                            <th
                                    class="relative"
                                    data-key="${column.key}"
                                    data-label="${column.label || column.key || ''}"
                                    data-sf-pinned=${context.component.isPinnedColumn(column, columns) ? '' : nothing}
                                    style=${context.component.getStickyCellStyle(columns, k) || nothing}
                                    aria-sort=${ariaSort(context, column)}
                                    @click=${column.sortable === true
                                            ? (event) => context.component.handleHeaderSortClick(event, column)
                                            : nothing}
                            >
                                ${column.system || k === columns.length - 1 ?
                                        renderHeadLabel(context, column) :
                                html`<div
                                        class="sidebar-resizer flex items-cross-center h-full select-none"
                                >
                                    ${renderHeadLabel(context, column)}
                                    <sf-icon-button size="1/3"
                                                    radius="default"
                                                    root-class="sidebar-resizer-button absolute top-1/2 -translate-y-half translate-x-half inline-end-0 z-1 cursor-col-resize"
                                                    id=${context.component.getColumnResizerId(column.key)}
                                                    data-sf-column-resizer=${column.key}
                                                    aria-label="Изменить ширину столбца: ${column.label || column.key}"
                                                    aria-keyshortcuts="ArrowLeft ArrowRight"
                                                    type="link"
                                                    scheme="on-surface"
                                                    icon="drag_handle"
                                                    @keydown=${(event) => context.component.resizeColumnByKeyboard(event, column.key)}
                                    ></sf-icon-button>
                                </div>`}
                            </th>`
                        )
                    }
            )}
        </tr>
        </thead>
    `
}

function toColumnSize(value) {
    if (value === null || typeof value === "undefined" || value === "") {
        return "";
    }

    return typeof value === "number" ? `${value}px` : String(value);
}

function renderColgroup(context) {
    const columns = context.component?.getColumns?.() || [];

    if (!columns.length) {
        return nothing;
    }

    return html`
        <colgroup>
            ${columns.map((column) => {
                const width = toColumnSize(
                        column.colWidth ?? column.width ?? column.size,
                );
                const minWidth = toColumnSize(column.min_width ?? column.minWidth);
                const maxWidth = toColumnSize(column.maxWidth);
                const style = [
                    width ? `width: ${width}` : "",
                    minWidth ? `min-width: ${minWidth}` : "",
                    maxWidth ? `max-width: ${maxWidth}` : "",
                ].filter(Boolean).join("; ");

                return keyed(`col:${column.key}`, html`
                    <col
                            data-key=${column.key || nothing}
                            style=${style || nothing}
                    />
                `);
            })}
        </colgroup>
    `;
}

function renderComponent(component, owner) {
    if (!component?.type) {
        return nothing;
    }
    const props = {...(component.props || {})};
    return owner.renderSmartElement(component.type, props);
}

function renderCellItem(item, owner) {
    if (item === null || typeof item === "undefined") {
        return nothing;
    }

    if (typeof item === "object") {
        const {
            component,
            props: itemProps,
            ...itemMeta
        } = item;

        if (!component?.type) {
            return nothing;
        }

        return renderComponent({
            ...component,
            props: {
                ...itemMeta,
                ...(itemProps || {}),
                ...(component.props || {}),
            },
        }, owner);
    }

    return item;
}

function renderLinkCell(value) {
    const cell = normalizeTableLinkCell(value);
    if (!cell) {
        return nothing;
    }

    const content = html`
        <span class="sf-table-link-cell-content flex flex-col min-w-0">
            <span class="sf-table-link-cell-text">${cell.text}</span>
            ${cell.subtext === null ? nothing : html`
                <span class="sf-table-link-cell-subtext sf-text-1/2">${cell.subtext}</span>
            `}
        </span>
    `;

    return cell.href
        ? html`<a class="sf-table-link-cell" href=${cell.href}>${content}</a>`
        : html`<span class="sf-table-link-cell">${content}</span>`;
}


export function renderTableTemplate(context) {
    const {state} = context.component;

    function renderBody() {
        if (context.component?.hasSlotContent?.("body")) {
            return html`
                <tbody>
                ${context.component.getSlotContent("body")}
                </tbody>`;
        }

        const {state} = context.component;
        const columns = context.component?.getColumns?.() || [];
        const {rows = []} = state.data || {};
        const dataState = resolvedDataState(context);

        if (dataState !== 'populated') {
            const stateContent = {
                loading: html`
                    <div class="flex items-cross-center gap-1/2" role="status">
                        <sf-spinner size="1" aria-hidden="true"></sf-spinner>
                        <span>${context.loadingText}</span>
                    </div>
                `,
                error: html`
                    <div class="flex flex-col items-cross-start gap-1/2" role="alert">
                        <span>${context.errorText}</span>
                        <sf-button
                                type="outline"
                                scheme="on-surface"
                                size="1"
                                text=${context.retryText}
                                @click=${() => context.component.requestRetry()}
                        ></sf-button>
                    </div>
                `,
                empty: html`<span>${context.emptyText}</span>`,
            }[dataState] || html`<span>${context.emptyText}</span>`;

            return html`
                <tbody data-state=${dataState}>
                    <tr>
                        <td colspan=${String(Math.max(columns.length, 1))}>
                            <div class="sf-table-state p-2">${stateContent}</div>
                        </td>
                    </tr>
                </tbody>
            `;
        }

        return html`
            <tbody>
            ${rows.map((row) => keyed(`row:${row.id ?? row.value ?? rows.indexOf(row)}`, html`
                <tr data-selected=${row.select?.component?.props?.checked === true ? '' : nothing}
                    data-row-id=${String(row.id ?? '')}
                    data-current=${row.id != null && String(state.currentRowId ?? '') === String(row.id) ? '' : nothing}
                    tabindex="-1"
                    @mousedown=${(event) => context.component.handleRowPointerDown(event)}
                    @click=${(event) => context.component.handleRowClick(event, row)}
                    @dblclick=${(event) => context.component.handleRowOpen(event, row)}
                    @keydown=${(event) => context.component.handleRowKeydown(event, row)}>
                    ${columns.map((column, index) => keyed(
                        `cell:${row.id ?? row.value ?? rows.indexOf(row)}:${column.key}`,
                        html`
                        <td data-key="${column.key}" data-item="${row.id}_${column.key}"
                            data-sf-pinned=${context.component.isPinnedColumn(column, columns) ? '' : nothing}
                            style=${context.component.getStickyCellStyle(columns, index) || nothing}>${renderCellValue(row, column)}</td>
                    `))}
                </tr>
            `))}
            </tbody>`;
    }

    function renderCellValue(row, column) {
        if (!column || !row) {
            return nothing;
        }

        let value = row[column.key];

        if (column.renderer === "link") {
            return renderLinkCell(value);
        }
        if (
            column.key === 'actions' &&
            (!Array.isArray(value) || !value.length) &&
            context.component?.getActionRowItems
        ) {
            value = context.component.getActionRowItems(row);
        } else if (column.key === 'actions' && Array.isArray(value)
            && context.component?.getActionRowItems) {
            value = context.component.getActionRowItems(row, value);
        }


        if (column.component) {
            if (
                value !== null &&
                typeof value !== "undefined" &&
                (!Array.isArray(value) || value.length)
            ) {
                return renderCellItem(value, context.component);
            }
            if (
                column.key === "settings" &&
                (!value || (Array.isArray(value) && !value.length))
            ) {
                return renderComponent({
                    type: "icon-button",
                    props: {
                        size: "1",
                        type: "link",
                        scheme: "on-surface",
                        icon: "menu",
                        ariaLabel: "Меню",
                        value: "menu",
                    },
                }, context.component);
            }

            return renderComponent(column.rowComponent || column.component, context.component);
        }

        if (value === null || typeof value === "undefined") {
            return nothing;
        }

        if (Array.isArray(value)) {
            if (column.key === 'actions') {
                value = value.filter(el => {
                    const {actions} = state;
                    const actionId = el.id || el.component?.props?.value;
                    const action = actions.find(action => action.id === actionId);

                    return action?.visible ?? true
                });
            }
            return html`
                <div class="flex items-cross-center gap-1/3">
                    ${value.map((item) => renderCellItem(item, context.component))}
                </div>
            `;
        }

        if (typeof value === "object") {
            return renderCellItem(value, context.component);
        }

        return value;
    }

    return html`
        <section
                class="sf-table min-w-0 flex flex-col gap-1/3 flex-1 min-h-0 ${context.rootClass ||
                ""}"
                style=${context.rootStyle || nothing}
                aria-label=${context.ariaLabel || nothing}
                data-sf-instance=${context.component.getInstanceId()}
                data-state=${resolvedDataState(context)}
                aria-busy=${resolvedDataState(context) === 'loading' ? 'true' : nothing}
        >
            ${context.toolbar ? renderToolbar(context) : nothing}
            ${context.component.renderBulkActions()}

            <div class="table-wrap min-w-0 max-w-full flex flex-col flex-1 min-h-0">
                <div class="sf-table-scroll min-h-0 min-w-0 overflow-auto flex-1 relative m-bottom-2"
                     ${ref(context.component.refs.scroll)}
                     data-sf-vertical-scroll=${context.verticalScroll}>
                    <div class="sf-table-resize-guide" aria-hidden="true" hidden
                         ${ref(context.component.refs.resizeGuide)}></div>
                    <table
                            ${ref(context.component.refs.table)}
                            class="table border-separate border-spacing-0 min-w-full w-max table-fixed transition"
                            aria-label=${context.ariaLabel || nothing}
                    >
                        ${renderColgroup(context)}
                        ${renderHead(context)}
                        ${renderBody(context)}
                    </table>
                </div>

                ${context.pagin
                        ? html`
                            <sf-pagination
                                    current="1"
                                    total=${String(context.paginationTotal)}
                                    bottom="true"
                                    show-action-for-all
                                    page-size=${String(context.paginationPageSize)}
                                    page-sizes=${context.pageSizes}
                                    show-page-size
                                    top-class="content-main-center"
                                    main-class="items-cross-center content-main-between"
                                    bottom-class="items-cross-center gap-2"
                            ></sf-pagination>`
                        : nothing}
            </div>
        </section>
        ${state.contextMenu?.open ? context.component.renderContextMenu(context.state.contextMenu) : nothing}
        <sf-modal @modal:after-close=${(event) => {
            if (event.target !== event.currentTarget) return;
            context.component.set({
                modalOpen: false
            })
        }} ?open=${state.modalOpen} root-class="sf-modal-panel" id="modal" position="inline-end"
                  title="Ticket #183743503490">
            <div slot="content">This is modal</div>
        </sf-modal>
    `;
}
