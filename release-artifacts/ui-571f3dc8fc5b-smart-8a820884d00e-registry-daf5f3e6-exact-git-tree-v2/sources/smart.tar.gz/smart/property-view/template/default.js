import {html, nothing} from 'lit';
import "./default.css";
import {renderViewField, renderEditField} from '../../../field-renderers/index.js';

// The arrangement, drawn in the component's own light DOM. Not in a shadow root:
// the field controls are Smart elements whose stylesheets are document-level, and
// a document stylesheet does not cross a shadow boundary. sf-data-view slots its
// children for exactly this reason and says so beside the slot; the first version
// of this composite built them inside a shadow root and every control came out
// with its markup and none of its CSS.

function renderFieldValue(context, field, editing) {
    const key = String(field.key ?? '');
    const editHost = {
        setFieldValue: (target, value) => context.component.changeField(target, value),
        ...(context.canUploadFiles
            ? {
                getFieldUploads: (target) => context.component.getFieldUploads(target),
                startFieldUpload: (target, items) => context.component.startFieldUpload(target, items),
                retryFieldUpload: (target, index) => context.component.retryFieldUpload(target, index),
            }
            : {}),
        ...(context.canPickRecords
            ? {
                getFieldOptionsPage: (target) => context.component.getFieldOptionsPage(target),
                getFieldOptionSearch: (target) => context.component.getFieldOptionSearch(target),
                setFieldOptionSearch: (target, text) => context.component.setFieldOptionSearch(target, text),
                loadFieldOptions: (target, request) => context.component.loadFieldOptions(target, request),
            }
            : {}),
    };
    const content = editing
        ? renderEditField(
            field,
            context.changed.has(key) ? context.changed.get(key) : field.value,
            editHost,
        )
        : renderViewField(field, field.value, context.hostPort);

    const reference = ['record', 'relation', 'user'].includes(field.propertyType || field.type)
        && field.value && typeof field.value === 'object';
    if (!editing && reference && content) {
        return html`<span
                class="sf-property-view-reference"
                @click=${(event) => {
                    event.preventDefault();
                    context.component.openReference(field, field.value);
                }}
        >${content}</span>`;
    }

    // An edit control the set cannot build is not an empty value. record and
    // relation have no editor until the picker's host methods exist, and the
    // first version showed «не заполнено» over a field that had a value -- a
    // consumer read it as the value having been lost. Fall back to the view, so
    // the value is shown and plainly not editable yet.
    if (editing && (content === null || typeof content === 'undefined' || content === nothing)) {
        const shown = renderViewField(field, field.value, context.hostPort);
        if (shown !== null && typeof shown !== 'undefined' && shown !== nothing) {
            return html`<span class="sf-property-view-readonly" data-readonly="true">${shown}</span>`;
        }
    }

    if (content === null || typeof content === 'undefined' || content === nothing) {
        return html`<span class="sf-property-view-empty">${context.emptyText}</span>`;
    }

    return content;
}

function renderField(context, field, editing) {
    const key = String(field.key ?? '');
    const error = context.errors.get(key);

    return html`
        <div class="sf-property-view-field ${field.width === 'full' ? 'sf-property-view-field--full' : ''}"
             data-field=${key}>
            <div class="sf-property-view-field-label">${String(field.label ?? key)}</div>
            <div class="sf-property-view-field-value">${renderFieldValue(context, field, editing)}</div>
            ${error
                    ? html`<div class="sf-property-view-field-error" role="alert">${error}</div>`
                    : nothing}
        </div>
    `;
}

function renderGroup(context, section, group) {
    const groupKey = String(group.key ?? '');
    const editing = context.editing?.group === groupKey
        && context.editing?.section === String(section.key ?? '');
    const fields = context.visible(group.fields);

    return html`
        <section class="sf-property-view-group ${editing ? 'sf-property-view-group--editing' : ''}"
                 data-group=${groupKey}
                 data-columns=${group.columns === 2 ? '2' : '1'}>
            <header class="sf-property-view-group-header">
                <h3 class="sf-property-view-group-title">${String(group.label ?? groupKey)}</h3>
                ${!editing && group.editable !== false
                        ? html`
                            <sf-button
                                    appearance="link"
                                    size="1"
                                    text=${context.editText}
                                    data-action="edit"
                                    @click=${() => context.component.editGroup(String(section.key ?? ''), groupKey)}
                            ></sf-button>`
                        : nothing}
            </header>
            <div class="sf-property-view-group-fields">
                ${fields.map((field) => renderField(context, field, editing))}
            </div>
        </section>
    `;
}

function renderSectionList(context, sections) {
    // One section is drawn as its groups alone: a list of one is a control nobody
    // can use, and the consumer's request asks for the groups to stand alone.
    if (sections.length < 2) return nothing;

    return html`
        <nav class="sf-property-view-sections" aria-label=${context.sectionsLabel}>
            <sf-tree selection="single">
                ${sections.map((section) => html`
                    <sf-tree-item
                            label=${String(section.label ?? section.key)}
                            value=${String(section.key)}
                            ?selected=${String(section.key) === context.selectedSection}
                            @click=${() => context.component.selectSection(String(section.key))}
                    ></sf-tree-item>
                `)}
            </sf-tree>
        </nav>
    `;
}

function renderActions(context) {
    if (!context.editing) return nothing;

    return html`
        <div class="sf-property-view-actions" role="group">
            <span class="sf-property-view-changed">${context.changedText}: ${context.changed.size}</span>
            ${context.errors.size
                    ? html`<span class="sf-property-view-errors">${context.errorsText}: ${context.errors.size}</span>`
                    : nothing}
            ${context.conflict
                    ? html`<span class="sf-property-view-conflict" role="alert">${context.conflict}</span>`
                    : nothing}
            <sf-button
                    appearance="default"
                    size="1"
                    text=${context.saveText}
                    data-action="save"
                    ?disabled=${context.changed.size === 0}
                    @click=${() => context.component.saveGroup()}
            ></sf-button>
            <sf-button
                    appearance="outline"
                    size="1"
                    text=${context.cancelText}
                    data-action="cancel"
                    @click=${() => context.component.cancelEdit()}
            ></sf-button>
        </div>
    `;
}

// The three controls a panel carries, and none of them invents anything. Close is
// the component's own business; copying and opening need an address, and the
// address is the host's -- a composite that constructed a URL would be guessing at
// the consumer's routing and would be wrong in the first consumer whose routing
// did not match the guess. No address, no two controls.
function renderPanelControls(context) {
    return html`
        <div class="sf-property-view-panel-controls flex items-cross-center gap-1/3">
            <sf-icon-button
                    appearance="link"
                    size="1"
                    icon="close"
                    aria-label=${context.closeLabel}
                    data-action="close"
                    @click=${() => context.component.closePanel('close')}
            ></sf-icon-button>
            ${context.hostSlot('actions')}
            ${context.address
                    ? html`
                        <sf-icon-button
                                appearance="link"
                                size="1"
                                icon="link"
                                aria-label=${context.copyLinkLabel}
                                data-action="copy-link"
                                @click=${() => context.component.copyAddress()}
                        ></sf-icon-button>
                        <sf-icon-button
                                appearance="link"
                                size="1"
                                icon="open_in_full"
                                aria-label=${context.openFullLabel}
                                data-action="open-full"
                                @click=${() => context.component.openFullPage()}
                        ></sf-icon-button>`
                    : nothing}
        </div>
    `;
}

function renderBody(context) {
    const sections = context.visible(context.sections);
    const current = sections.find((section) => String(section.key) === context.selectedSection)
        ?? sections[0] ?? null;

    return html`
        <div class="sf-property-view-status" role="status" aria-live="polite" ?hidden=${!context.message}>
            ${context.message}
        </div>
        ${!context.panel && context.hasHostSlot('actions')
                ? html`<div class="sf-property-view-host-actions">${context.hostSlot('actions')}</div>`
                : nothing}
        <div class="sf-property-view-layout" data-sections=${String(sections.length)}>
            ${renderSectionList(context, sections)}
            <div class="sf-property-view-body">
                ${context.visible(current?.groups).map((group) => renderGroup(context, current, group))}
            </div>
        </div>
        ${context.hasHostSlot('footer')
                ? html`<div class="sf-property-view-host-footer">${context.hostSlot('footer')}</div>`
                : nothing}
        ${renderActions(context)}
    `;
}

// The same component, in the work area or in a modeless panel beside the list it
// was opened from. Modeless is the point: `modal` and `overlay` are both off, so
// the list stays visible and usable -- which is what the consumer asked for, and
// what a modal would take away. Esc is handled here rather than by the drawer,
// because in a stack it must close the top window and not every one of them.
export function renderPropertyViewTemplate(context) {
    if (!context.panel) return renderBody(context);

    return html`
        <sf-drawer
                open
                placement="inline-end"
                modal="false"
                overlay="false"
                size=${context.panelSize}
                show-close="false"
                close-on-esc="false"
                label=${context.panelLabel || context.recordId || ''}
        >
            <div class="sf-property-view-panel flex flex-col"
                 data-record-id=${context.recordId || ''}
                 data-stack-depth=${String(context.stackDepth)}
                 data-stacked=${context.isTopPanel ? 'false' : 'true'}
                 style=${context.stackDepth
                         ? `margin-inline-start: calc(var(--sf-space-4) * ${context.stackDepth})`
                         : nothing}>
                ${renderPanelControls(context)}
                ${renderBody(context)}
            </div>
        </sf-drawer>
    `;
}
