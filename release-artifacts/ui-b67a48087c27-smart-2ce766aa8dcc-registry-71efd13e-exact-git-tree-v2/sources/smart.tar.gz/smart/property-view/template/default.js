import {html, nothing} from 'lit';
import "./default.css";
import {renderViewField, renderEditField} from '../../../field-renderers/index.js';

// The arrangement, drawn in the component's own light DOM. Not in a shadow root:
// the field controls are Smart elements whose stylesheets are document-level, and
// a document stylesheet does not cross a shadow boundary. sf-data-view slots its
// children for exactly this reason and says so beside the slot; the first version
// of this composite built them inside a shadow root and every control came out
// with its markup and none of its CSS.

function renderFieldValue(context, field, editing) {
    const key = String(field.key ?? '');
    const editHost = {
        setFieldValue: (target, value) => context.component.changeField(target, value),
        ...(context.canUploadFiles
            ? {
                getFieldUploads: (target) => context.component.getFieldUploads(target),
                startFieldUpload: (target, items) => context.component.startFieldUpload(target, items),
                retryFieldUpload: (target, index) => context.component.retryFieldUpload(target, index),
            }
            : {}),
        ...(context.canPickRecords
            ? {
                getFieldOptionsPage: (target) => context.component.getFieldOptionsPage(target),
                getFieldOptionSearch: (target) => context.component.getFieldOptionSearch(target),
                setFieldOptionSearch: (target, text) => context.component.setFieldOptionSearch(target, text),
                loadFieldOptions: (target, request) => context.component.loadFieldOptions(target, request),
            }
            : {}),
    };
    const content = editing
        ? renderEditField(
            field,
            context.changed.has(key) ? context.changed.get(key) : field.value,
            editHost,
        )
        : renderViewField(field, field.value, context.hostPort);

    const reference = ['record', 'relation', 'user'].includes(field.propertyType || field.type)
        && field.value && typeof field.value === 'object';
    if (!editing && reference && content) {
        return html`<span
                class="sf-property-view-reference"
                @click=${(event) => {
                    event.preventDefault();
                    context.component.openReference(field, field.value);
                }}
        >${content}</span>`;
    }

    // An edit control the set cannot build is not an empty value. record and
    // relation have no editor until the picker's host methods exist, and the
    // first version showed «не заполнено» over a field that had a value -- a
    // consumer read it as the value having been lost. Fall back to the view, so
    // the value is shown and plainly not editable yet.
    if (editing && (content === null || typeof content === 'undefined' || content === nothing)) {
        const shown = renderViewField(field, field.value, context.hostPort);
        if (shown !== null && typeof shown !== 'undefined' && shown !== nothing) {
            return html`<span class="sf-property-view-readonly" data-readonly="true">${shown}</span>`;
        }
    }

    if (content === null || typeof content === 'undefined' || content === nothing) {
        return html`<span class="sf-property-view-empty">${context.emptyText}</span>`;
    }

    return content;
}

// While the view is being configured every entry is listed, hidden and rare ones
// included: a hidden field a person cannot see is a field they cannot show again,
// and «показать редкие поля» is a reading choice rather than part of the
// arrangement being edited.
function listed(context, entries) {
    return context.configuring ? (entries ?? []) : context.visible(entries);
}

// The chooser names the layers this person may write and nothing else. A layer
// they may not write is drawn disabled with the host's own reason on it rather
// than left out, because a «Для всех» that is simply absent reads as a feature
// the product does not have.
function renderConfigureBar(context) {
    if (!context.canConfigureView) return nothing;
    if (!context.configuring) {
        return html`
            <div class="sf-property-view-configure-bar">
                <sf-button
                        appearance="link"
                        size="1"
                        text=${context.configureText}
                        data-action="configure"
                        @click=${() => context.component.startConfiguringView()}
                ></sf-button>
            </div>
        `;
    }

    const layers = [
        {kind: 'personal', text: context.personalLayerText},
        {kind: 'shared', text: context.sharedLayerText},
    ];

    return html`
        <div class="sf-property-view-configure-bar" data-configuring="true">
            <div class="sf-property-view-configure-layers" role="group" aria-label=${context.configureText}>
                ${layers.map((layer) => {
                    const denied = context.layerDenied(layer.kind);
                    return html`
                        <sf-button
                                appearance=${context.viewTarget === layer.kind ? 'filled' : 'outlined'}
                                size="1"
                                text=${layer.text}
                                data-layer=${layer.kind}
                                ?disabled=${Boolean(denied)}
                                title=${denied || nothing}
                                aria-pressed=${context.viewTarget === layer.kind ? 'true' : 'false'}
                                @click=${() => context.component.setViewTarget(layer.kind)}
                        ></sf-button>
                    `;
                })}
            </div>
            <sf-button
                    appearance="link"
                    size="1"
                    text=${context.resetViewText}
                    data-action="reset-view"
                    @click=${() => context.component.resetView()}
            ></sf-button>
            <sf-button
                    appearance="outlined"
                    size="1"
                    text=${context.doneConfiguringText}
                    data-action="done-configuring"
                    @click=${() => context.component.stopConfiguringView()}
            ></sf-button>
        </div>
    `;
}

// Width, template variant and hint, per field, and the visibility the layer above
// may have taken out of this person's hands. The controls are drawn beside the
// field rather than behind a dialog, because the arrangement is what is being
// edited and a dialog would hide the thing being changed.
function renderFieldSettings(context, field, key) {
    const variants = Array.isArray(field.variantOptions) ? field.variantOptions : [];
    const locked = !context.canChangeVisibility(field);

    return html`
        <div class="sf-property-view-field-settings">
            <sf-button
                    appearance=${field.width === 'full' ? 'filled' : 'outlined'}
                    size="1"
                    text=${context.widthText}
                    data-action="width"
                    aria-pressed=${field.width === 'full' ? 'true' : 'false'}
                    @click=${() => context.component.setFieldView(key, {width: field.width === 'full' ? 'half' : 'full'})}
            ></sf-button>
            ${variants.length
                    ? html`
                        <sf-dropdown
                                size="1"
                                appearance="outlined"
                                mode="select"
                                search="false"
                                data-action="variant"
                                aria-label=${context.variantText}
                                value=${String(field.variant ?? '')}
                                .options=${variants.map((variant) => ({
                                    type: 'text',
                                    size: '1',
                                    text: variant.label ?? variant.text ?? String(variant.value ?? variant),
                                    value: String(variant.value ?? variant),
                                    selected: String(field.variant ?? '') === String(variant.value ?? variant),
                                }))}
                                @change=${(event) => context.component.setFieldView(key, {variant: event.detail?.value ?? null})}
                        ></sf-dropdown>`
                    : nothing}
            <sf-input
                    size="1"
                    appearance="bordered"
                    data-action="hint"
                    aria-label=${context.hintText}
                    placeholder=${context.hintText}
                    value=${String(field.hint ?? '')}
                    @change=${(event) => context.component.setFieldView(key, {hint: event.target?.value ?? ''})}
            ></sf-input>
            <sf-button
                    appearance=${field.hidden ? 'filled' : 'outlined'}
                    size="1"
                    text=${context.hiddenText}
                    data-action="hide"
                    ?disabled=${locked}
                    title=${locked ? context.layerDenied('shared') || context.hiddenText : nothing}
                    aria-pressed=${field.hidden ? 'true' : 'false'}
                    @click=${() => context.component.toggleEntryHidden('field', key)}
            ></sf-button>
        </div>
    `;
}

function renderField(context, field, editing) {
    const key = String(field.key ?? '');
    const error = context.errors.get(key);

    const arrangementError = context.configuring ? context.entryError('field', key) : null;

    return html`
        <div class="sf-property-view-field ${field.width === 'full' ? 'sf-property-view-field--full' : ''}"
             data-field=${key}
             data-sf-sortable-item=${context.configuring ? key : nothing}
             data-hidden=${context.configuring && field.hidden ? 'true' : nothing}>
            ${context.configuring
                    ? html`<span class="sf-property-view-grip" data-sf-sortable-handle aria-hidden="true"></span>`
                    : nothing}
            <div class="sf-property-view-field-label">${String(field.label ?? key)}</div>
            <div class="sf-property-view-field-value">${renderFieldValue(context, field, editing)}</div>
            ${context.configuring ? renderFieldSettings(context, field, key) : nothing}
            ${error || arrangementError
                    ? html`<div class="sf-property-view-field-error" role="alert">${error || arrangementError}</div>`
                    : nothing}
        </div>
    `;
}

// A group of related records: the component composes a data view in it and the
// view asks the host for its own port. The records never come through the
// property-view seam -- rows, columns, sorting and paging are the data-view
// port's vocabulary, and relaying them through this one would duplicate all of it.
//
// `chrome=""` leaves out the search box and the page row: the list stands inside a
// group that already has a heading, and a page row under four rows of a capped
// list would offer paging through records the cap is not showing anyway.
//
// The table is slotted in, which is how a data view is composed -- its own page
// markup slots one too. An earlier version left it out and relied on the fallback
// inside the data view's content slot instead, to satisfy a fence that said a
// component rendering another one has to fetch it. That traded one defect for a
// worse one: fallback content lives in the shadow tree, where the Framework's
// page-level stylesheets do not reach, so a consumer got a list whose sort buttons
// read «unfold_more» as text and whose reference cells read «arrow_forward». The
// fence was right and the clever fix was wrong: this component does render a table,
// so it fetches cl-table.
function renderRelatedList(context, group, groupKey) {
    return html`
        <sf-data-view
                class="sf-property-view-related"
                chrome=""
                row-cap=${String(group.rowCap ?? 5)}
                port-owner="property-view"
                port-record=${context.recordId || ''}
                port-group=${groupKey}
                aria-label=${String(group.label ?? groupKey)}
        >
            <sf-table
                    slot="content"
                    toolbar="false"
                    aria-label=${String(group.label ?? groupKey)}
            ></sf-table>
        </sf-data-view>
    `;
}

function renderGroup(context, section, group) {
    const groupKey = String(group.key ?? '');
    const editing = context.editing?.group === groupKey
        && context.editing?.section === String(section.key ?? '');
    const fields = listed(context, group.fields);
    const configuring = context.configuring;
    const groupError = configuring ? context.entryError('group', groupKey) : null;
    const groupLocked = configuring && !context.canChangeVisibility(group);
    // The field list is a sortable list and nothing more: the drop is reported by
    // sf-sortable and applied or refused by the component, which is the seam that
    // mechanism already publishes. Its id carries the kind and the container, so
    // one listener can tell a field dropped into a group from a group dropped into
    // a section.
    const rows = html`${fields.map((field) => renderField(context, field, editing))}`;

    return html`
        <section class="sf-property-view-group ${editing ? 'sf-property-view-group--editing' : ''}"
                 data-group=${groupKey}
                 data-sf-sortable-item=${configuring ? groupKey : nothing}
                 data-hidden=${configuring && group.hidden ? 'true' : nothing}
                 data-columns=${group.columns === 2 ? '2' : '1'}>
            <header class="sf-property-view-group-header">
                ${configuring
                        ? html`<span class="sf-property-view-grip" data-sf-sortable-handle aria-hidden="true"></span>`
                        : nothing}
                <h3 class="sf-property-view-group-title">${String(group.label ?? groupKey)}</h3>
                ${configuring
                        ? html`
                            <sf-button
                                    appearance=${group.hidden ? 'filled' : 'outlined'}
                                    size="1"
                                    text=${context.hiddenText}
                                    data-action="hide-group"
                                    ?disabled=${groupLocked}
                                    aria-pressed=${group.hidden ? 'true' : 'false'}
                                    @click=${() => context.component.toggleEntryHidden('group', groupKey)}
                            ></sf-button>`
                        : nothing}
                ${!configuring && !editing && group.kind !== 'related' && group.editable !== false
                        ? html`
                            <sf-button
                                    appearance="link"
                                    size="1"
                                    text=${context.editText}
                                    data-action="edit"
                                    @click=${() => context.component.editGroup(String(section.key ?? ''), groupKey)}
                            ></sf-button>`
                        : nothing}
            </header>
            ${groupError
                    ? html`<div class="sf-property-view-group-error" role="alert">${groupError}</div>`
                    : nothing}
            ${group.kind === 'related'
                    ? html`<div class="sf-property-view-group-related">${renderRelatedList(context, group, groupKey)}</div>`
                    : configuring
                            ? html`
                                <sf-sortable
                                        class="sf-property-view-group-fields"
                                        group="field"
                                        accepts="field"
                                        id=${`field:${groupKey}`}
                                        label=${String(group.label ?? groupKey)}
                                >${rows}</sf-sortable>`
                            : html`<div class="sf-property-view-group-fields">${rows}</div>`}
        </section>
    `;
}

// The phone's first screen: the sections as a list, each one leading to its own
// screen. Drawn only when there is more than one, for the same reason the desktop
// list is: a list of one is a control nobody can use, and it would put a screen
// between a person and the only groups there are.
function renderPhoneSectionList(context, sections) {
    return html`
        <nav class="sf-property-view-phone-sections" aria-label=${context.sectionsLabel}>
            ${sections.map((section) => html`
                <button
                        type="button"
                        class="sf-property-view-phone-section"
                        data-phone-section=${String(section.key)}
                        @click=${() => context.component.openPhoneSection(String(section.key))}
                >
                    <span class="sf-property-view-phone-section-label">${String(section.label ?? section.key)}</span>
                    <i class="sf-icon" aria-hidden="true">chevron_right</i>
                </button>
            `)}
        </nav>
    `;
}

// The second screen's head: back to the list, and the name of where you are.
function renderPhoneSectionHead(context) {
    return html`
        <div class="sf-property-view-phone-head">
            <sf-icon-button
                    size="1"
                    type="link"
                    icon="arrow_back"
                    data-action="phone-back"
                    aria-label=${context.backLabel}
                    @click=${() => context.component.closePhoneSection()}
            ></sf-icon-button>
            <h2 class="sf-property-view-phone-title">${context.phoneSectionLabel}</h2>
        </div>
    `;
}

function renderSectionList(context, sections) {
    // One section is drawn as its groups alone: a list of one is a control nobody
    // can use, and the consumer's request asks for the groups to stand alone.
    if (sections.length < 2) return nothing;

    return html`
        <nav class="sf-property-view-sections" aria-label=${context.sectionsLabel}>
            <sf-tree selection="single">
                ${sections.map((section) => html`
                    <sf-tree-item
                            label=${String(section.label ?? section.key)}
                            value=${String(section.key)}
                            ?selected=${String(section.key) === context.selectedSection}
                            @click=${() => context.component.selectSection(String(section.key))}
                    ></sf-tree-item>
                `)}
            </sf-tree>
        </nav>
    `;
}

function renderActions(context) {
    if (!context.editing) return nothing;

    return html`
        <div class="sf-property-view-actions" role="group">
            <span class="sf-property-view-changed">${context.changedText}: ${context.changed.size}</span>
            ${context.errors.size
                    ? html`<span class="sf-property-view-errors">${context.errorsText}: ${context.errors.size}</span>`
                    : nothing}
            ${context.conflict
                    ? html`<span class="sf-property-view-conflict" role="alert">${context.conflict}</span>`
                    : nothing}
            <sf-button
                    appearance="default"
                    size="1"
                    text=${context.saveText}
                    data-action="save"
                    ?disabled=${context.changed.size === 0}
                    @click=${() => context.component.saveGroup()}
            ></sf-button>
            <sf-button
                    appearance="outline"
                    size="1"
                    text=${context.cancelText}
                    data-action="cancel"
                    @click=${() => context.component.cancelEdit()}
            ></sf-button>
        </div>
    `;
}

// The three controls a panel carries, and none of them invents anything. Close is
// the component's own business; copying and opening need an address, and the
// address is the host's -- a composite that constructed a URL would be guessing at
// the consumer's routing and would be wrong in the first consumer whose routing
// did not match the guess. No address, no two controls.
function renderPanelControls(context) {
    return html`
        <div class="sf-property-view-panel-controls flex items-cross-center gap-1/3">
            <sf-icon-button
                    appearance="link"
                    size="1"
                    icon="close"
                    aria-label=${context.closeLabel}
                    data-action="close"
                    @click=${() => context.component.closePanel('close')}
            ></sf-icon-button>
            ${context.hostSlot('actions')}
            ${context.address
                    ? html`
                        <sf-icon-button
                                appearance="link"
                                size="1"
                                icon="link"
                                aria-label=${context.copyLinkLabel}
                                data-action="copy-link"
                                @click=${() => context.component.copyAddress()}
                        ></sf-icon-button>
                        <sf-icon-button
                                appearance="link"
                                size="1"
                                icon="open_in_full"
                                aria-label=${context.openFullLabel}
                                data-action="open-full"
                                @click=${() => context.component.openFullPage()}
                        ></sf-icon-button>`
                    : nothing}
        </div>
    `;
}

// The phone's list screen: below the breakpoint, with more than one section and
// none of them opened. Named once rather than written out at each of the three
// places that ask it -- the first version repeated the expression and the third
// copy was the one that forgot to suppress the groups, so the list screen drew the
// list with a section's groups underneath it.
function onPhoneSectionList(context, sections) {
    return !context.wide && sections.length > 1 && context.phoneSection === null;
}

function renderBody(context) {
    // Sections are listed the same way fields and groups are while the view is
    // being configured: a hidden section filtered out here would be a section
    // nobody could ever show again.
    const sections = listed(context, context.sections);
    const current = sections.find((section) => String(section.key) === context.selectedSection)
        ?? sections[0] ?? null;

    return html`
        <div class="sf-property-view-status" role="status" aria-live="polite" ?hidden=${!context.message}>
            ${context.message}
        </div>
        ${renderConfigureBar(context)}
        ${!context.panel && context.hasHostSlot('actions')
                ? html`<div class="sf-property-view-host-actions">${context.hostSlot('actions')}</div>`
                : nothing}
        ${onPhoneSectionList(context, sections) ? renderPhoneSectionList(context, sections) : nothing}
        <div class="sf-property-view-layout"
             data-sections=${String(sections.length)}
             data-screen=${onPhoneSectionList(context, sections) ? 'sections' : 'groups'}>
            ${!context.wide && sections.length > 1 && context.phoneSection !== null
                    ? renderPhoneSectionHead(context)
                    : nothing}
            ${context.wide ? renderSectionList(context, sections) : nothing}
            ${onPhoneSectionList(context, sections) ? nothing : context.configuring
                    ? html`
                        <sf-sortable
                                class="sf-property-view-body"
                                group="group"
                                accepts="group"
                                id=${`group:${current ? String(current.key) : ''}`}
                                label=${String(current?.label ?? current?.key ?? '')}
                        >${listed(context, current?.groups).map((group) => renderGroup(context, current, group))}</sf-sortable>`
                    : html`
                        <div class="sf-property-view-body">
                            ${context.visible(current?.groups).map((group) => renderGroup(context, current, group))}
                        </div>`}
        </div>
        ${context.hasHostSlot('footer')
                ? html`<div class="sf-property-view-host-footer">${context.hostSlot('footer')}</div>`
                : nothing}
        ${renderActions(context)}
    `;
}

// A deeper window is narrower by a step, so the one below shows along the
// inline-start edge. That is what makes a stack visible rather than merely true
// in the DOM, and `width` is a declared input on sf-drawer, so it reaches into
// none of that component's internals.
//
// Interim by intent. The drawer's owner is taking a declared `stack-offset` input
// to the owner, where the window above is inset instead of the window below being
// narrowed -- the better idiom, because a stack four deep should not end in a
// sliver. When it lands this switches to it.
//
// The same component, in the work area or in a modeless panel beside the list it
// was opened from. Modeless is the point: `modal` and `overlay` are both off, so
// the list stays visible and usable -- which is what the consumer asked for, and
// what a modal would take away. Esc is handled here rather than by the drawer,
// because in a stack it must close the top window and not every one of them.
export function renderPropertyViewTemplate(context) {
    if (!context.panel) return renderBody(context);

    return html`
        <sf-drawer
                open
                placement="inline-end"
                modal="false"
                overlay="false"
                size=${context.wide ? context.panelSize : 'full'}
                width=${context.wide ? (context.drawerWidth || nothing) : nothing}
                stack-offset="var(--sf-space-4)"
                show-close="false"
                close-on-esc="false"
                title=${context.panelLabel || nothing}
                label=${context.panelLabel || context.recordId || ''}
        >
            <div class="sf-property-view-panel flex flex-col"
                 data-record-id=${context.recordId || ''}
                 data-stack-depth=${String(context.stackDepth)}
                 data-stacked=${context.isTopPanel ? 'false' : 'true'}
            >
                ${renderPanelControls(context)}
                ${renderBody(context)}
            </div>
        </sf-drawer>
    `;
}
