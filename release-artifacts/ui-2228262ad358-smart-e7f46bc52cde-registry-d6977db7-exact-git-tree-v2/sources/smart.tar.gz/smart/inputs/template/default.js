import { html, nothing } from 'lit';
import { createFieldContract } from '../../../../component/field-contract';
import './default.css'
export function renderInputTemplate(context) {
  const {
    size,
    type,
    label,
    required,
    placeholder,
    hint,
    value,
    defaultValue,
    hasControlledValue,
    name,
    leftIcon,
    rightText,
    hintIcon,
    disabled,
    error,
    invalid,
    errorMessage,
    mask,
    rootClass,
    readonly,
    maskPattern,
    maskLazy,
    maskPlaceholderChar,
    maskOptions,
  } = context;
  const maskLazyValue = maskLazy === '' ? '' : String(maskLazy);
  const inputValue = hasControlledValue ? value : defaultValue;
  const field = createFieldContract(context.component, {
    prefix: 'sf-input',
    required,
    invalid: invalid || error,
    hint,
    errorMessage,
  });

  const rootClasses = [
    'sf-input',
      field.invalid ? 'error' : '',
    `sf-input--size-${size}`,
    `sf-input--${type}`,
      rootClass,
    'flex',
    'flex-col',
  ];

  if(type === 'hidden') {
      return  html`<input
              type="hidden"
              .value=${inputValue}
              name=${name || ''}
              ?disabled=${disabled}
              ?readonly=${readonly}
              data-mask=${String(mask)}
              data-mask-pattern=${maskPattern || ''}
              data-mask-lazy=${maskLazyValue}
              data-mask-placeholder-char=${maskPlaceholderChar || ''}
              data-mask-options=${maskOptions || ''}
      />`
  }
  const labelContent =
    context.component?.hasSlotContent?.('label')
      ? context.component.getSlotContent('label')
      : label
        ? html`
            <span class="sf-input-text">${label}</span>
            ${required ? html`<span class="sf-input-required">*</span>` : ''}
          `
        : required
          ? html`<span class="sf-input-required">*</span>`
          : '';

  const leftContent =
    context.component?.hasSlotContent?.('left')
      ? context.component.getSlotContent('left')
      : leftIcon
        ? html`<span class="sf-input-left flex"><sf-icon icon="${leftIcon}"></sf-icon></span>`
        : '';

  const rightContent =
    context.component?.hasSlotContent?.('right')
      ? context.component.getSlotContent('right')
      : html`
          ${rightText ? html`<span class="sf-input-right"><span class="sf-input-text">${rightText}</span></span>` : ''}
          ${hintIcon ? html`<span class="sf-input-hint flex"><sf-icon icon="${hintIcon}"></sf-icon></span>` : ''}
        `;

  const hintContent =
    context.component?.hasSlotContent?.('hint')
      ? context.component.getSlotContent('hint')
      : hint;

  const errorContent =
    context.component?.hasSlotContent?.('error')
      ? context.component.getSlotContent('error')
      : errorMessage;
  const messageContent = field.invalid && errorContent ? errorContent : hintContent;

  return html`
    <label
      class=${rootClasses.join(' ')}
      data-mask=${String(mask)}
      data-mask-pattern=${maskPattern || ''}
      data-mask-lazy=${maskLazyValue}
      data-mask-placeholder-char=${maskPlaceholderChar || ''}
      data-mask-options=${maskOptions || ''}
    >
      ${labelContent
        ? html`
            <span class="sf-input-label flex">
              ${labelContent}
            </span>
          `
        : ''}

      <span class="sf-input-field items-cross-center transition flex">
        ${leftContent}
        ${hasControlledValue
          ? html`
              <input
                id=${field.controlId}
                type="text"
                placeholder=${placeholder}
                .value=${value}
                .defaultValue=${inputValue}
                name=${name || ''}
                ?disabled=${disabled}
                ?readonly=${readonly}
                ?required=${field.required}
                aria-invalid=${field.invalid ? 'true' : nothing}
                aria-describedby=${messageContent ? field.messageId : nothing}
                aria-errormessage=${field.invalid && errorContent ? field.messageId : nothing}
                data-mask=${String(mask)}
                data-mask-pattern=${maskPattern || ''}
                data-mask-lazy=${maskLazyValue}
                data-mask-placeholder-char=${maskPlaceholderChar || ''}
                data-mask-options=${maskOptions || ''}
              />
            `
          : html`
              <input
                id=${field.controlId}
                type="text"
                placeholder=${placeholder}
                .defaultValue=${inputValue}
                name=${name || ''}
                ?disabled=${disabled}
                ?readonly=${readonly}
                ?required=${field.required}
                aria-invalid=${field.invalid ? 'true' : nothing}
                aria-describedby=${messageContent ? field.messageId : nothing}
                aria-errormessage=${field.invalid && errorContent ? field.messageId : nothing}
                data-mask=${String(mask)}
                data-mask-pattern=${maskPattern || ''}
                data-mask-lazy=${maskLazyValue}
                data-mask-placeholder-char=${maskPlaceholderChar || ''}
                data-mask-options=${maskOptions || ''}
              />
            `}
        ${rightContent}
      </span>

      ${messageContent
        ? html`<span
            id=${field.messageId}
            class="sf-input-hint-text-wrap"
            data-field-message=${field.invalid && errorContent ? 'error' : 'hint'}
          >${messageContent}</span>`
        : ''}
    </label>
  `;
}
