import { html, nothing } from "lit";

function joinClasses(...tokens) {
  return tokens.flat().filter(Boolean).join(" ");
}

function renderPageItem(item, context) {
  // The gap is a button like the numbers beside it, and it leads into the
  // middle of the pages it hides. It used to be an aria-hidden span: the
  // distance it stood for was unreachable, and a reader was told nothing at
  // all. The label names the page it goes to, so the promise is the same by
  // pointer, by keyboard and by voice.
  if (item.type === "ellipsis") {
    const target = Number(item.target) || 1;
    const label = `${context.pageLabel} ${target}`;

    return html`
      <li class="sf-pagination-item sf-pagination-item--ellipsis">
        <button
          type="button"
          class="sf-page-number sf-page-number--square sf-page-number--ellipsis"
          data-page=${String(target)}
          title=${label}
          aria-label=${label}
          @click=${() => context.component.goToPage(target)}
        >
          …
        </button>
      </li>
    `;
  }

  return html`
    <li
      class=${joinClasses(
        "sf-pagination-item",
        item.edge ? "sf-pagination-item--edge" : "",
        item.selected ? "sf-pagination-item--current" : "",
      )}
    >
      <button
        type="button"
        class=${joinClasses(
          "sf-page-number",
          "sf-page-number--square",
          item.selected ? "selected" : "",
        )}
        data-page=${String(item.value)}
        aria-current=${item.selected ? "page" : nothing}
        aria-label=${`${context.pageLabel} ${item.value}`}
        @click=${() => context.component.goToPage(item.value)}
      >
        ${item.value}
      </button>
    </li>
  `;
}

export function renderPaginationTemplate(context) {
  const { component } = context;
  const rootClasses = joinClasses(
    "sf-pagination",
    "flex",
    "flex-col",
    context.rootClass,
  );
  const topClasses = joinClasses(
    "sf-pagination-top",
    "flex",
    "content-main-center",
    context.topClass,
  );
  const mainClasses = joinClasses(
    "sf-pagination-main",
    "flex",
    "items-cross-center",
    "content-main-between",
    context.mainClass,
  );
  // The row of bulk controls is a panel over the page while rows are marked,
  // not a row inside the pagination: the controls act on the selection, which
  // outlives the part of the page a person is looking at.
  const bottomClasses = joinClasses(
    "sf-pagination-bottom",
    "sf-pagination-actions",
    "flex",
    "items-cross-center",
    context.bottomClass,
  );

  return html`
    <nav
      class=${rootClasses}
      style=${context.rootStyle || nothing}
      aria-label=${context.ariaLabel}
    >
      ${context.top && context.hasNext
        ? html`
            <div class=${topClasses}>
              <sf-button
                size="1"
                type="outline"
                scheme="primary"
                @click=${(e) => component.showMore(e.target)}
                text="${context.showMoreText}"
              ></sf-button>
            </div>
          `
        : ""}
      ${context.middle
        ? html`
            <div class=${mainClasses}>
              <div class="sf-pagination-left flex items-cross-center">
                <div class="sf-pagination-marked flex">
                  <div class="sf-pagination-marked-text">
                    ${context.selectedLabel}
                  </div>
                  <div class="sf-pagination-marked-text">
                    ${context.countKnown
                      ? `${context.selectedCount}/${context.total}`
                      : String(context.selectedCount)}
                  </div>
                </div>
                <!-- Three answers to "how many": the number, a short wait, or
                     an offer to find out. A host that cannot count is not
                     offered at all — a link that answers "unavailable" is worse
                     than no link. -->
                <div class="sf-pagination-total flex items-cross-center">
                  ${context.countKnown
                    ? html`
                        <div class="sf-pagination-total-text">
                          ${context.totalLabel} ${context.total}
                        </div>
                      `
                    : context.counting
                      ? html`
                          <div class="sf-pagination-total-text flex items-cross-center">
                            ${context.totalLabel}
                            <sf-spinner size="1" aria-label=${context.countingLabel}></sf-spinner>
                          </div>
                        `
                      : context.canCount
                        ? html`
                            <div class="sf-pagination-total-text flex items-cross-center">
                              ${context.totalLabel}
                              <sf-button
                                class="sf-pagination-count-request"
                                size="1"
                                type="link"
                                scheme="primary"
                                text=${context.showCountLabel}
                                @click=${() => component.requestCount("total")}
                              ></sf-button>
                            </div>
                          `
                        : ""}
                </div>
              </div>

              ${!context.countKnown || context.total > 0
                ? html`
                    <div class="sf-pagination-container flex items-cross-center">
                      <span class="sf-pagination-pages-label">${context.pagesLabel}</span>
                      <ol class="sf-pagination-list flex items-cross-center">
                        ${context.hasPrev
                          ? html`
                              <li class="sf-pagination-item">
                                <sf-icon-button
                                  class="sf-pagination-direction sf-pagination-direction--prev"
                                  size="1"
                                  type="link"
                                  scheme="on-surface"
                                  icon="keyboard_arrow_left"
                                  aria-label=${context.previousLabel}
                                  @click=${() =>
                                    component.goToPage(context.current - 1)}
                                ></sf-icon-button>
                              </li>
                            `
                          : ""}
                        ${context.pageItems.map((item) =>
                          renderPageItem(item, context),
                        )}
                        ${context.hasNext
                          ? html`
                              <li class="sf-pagination-item">
                                <sf-icon-button
                                  class="sf-pagination-direction sf-pagination-direction--next"
                                  size="1"
                                  type="link"
                                  scheme="on-surface"
                                  icon="keyboard_arrow_right"
                                  aria-label=${context.nextLabel}
                                  @click=${() =>
                                    component.goToPage(context.current + 1)}
                                ></sf-icon-button>
                              </li>
                              <li class="sf-pagination-item">
                                <sf-icon-button
                                  class="sf-pagination-direction sf-pagination-direction--last"
                                  size="1"
                                  type="link"
                                  scheme="on-surface"
                                  icon="last_page"
                                  aria-label=${context.lastLabel}
                                  @click=${() => component.lastPage()}
                                ></sf-icon-button>
                              </li>
                            `
                          : ""}
                      </ol>
                    </div>
                  `
                : ""}

              ${context.showPageSize && (!context.countKnown || context.total > 0)
                ? html`
                    <div class="sf-pagination-count flex items-cross-center">
                      <span>${context.pageSizeLabel}</span>
                      <sf-dropdown
                        size="1"
                        type="outlined"
                        search="false"
                        mode="select"
                        portal="true"
                        value=${String(context.pageSize)}
                        aria-label=${context.pageSizeLabel}
                        .options=${(context.pageSizes || []).map((size) => ({
                          type: "text",
                          size: "1",
                          text: String(size),
                          value: String(size),
                          selected: Number(size) === Number(context.pageSize),
                        }))}
                        @change=${(event) =>
                          component.setPageSize(Number(event.detail.value))}
                      ></sf-dropdown>
                    </div>
                  `
                : ""}
            </div>
          `
        : ""}
      ${context.bottom && context.showActions && context.actions?.length && context.selectedCount > 0
        ? html`
            <div
              class=${bottomClasses}
              role="region"
              aria-label=${context.actionsRegionLabel}
            >
              <span class="sf-pagination-actions-count">
                ${context.selectedLabel} ${context.selectedCount}
              </span>
              <span class="sf-pagination-actions-separator" aria-hidden="true"></span>
              <sf-dropdown
                size="1"
                type="outlined"
                search="false"
                mode="select"
                value=${context.action}
                placeholder=${context.actionChooseLabel}
                aria-label=${context.actionsLabel}
                .options=${[
                  // The list opens on a choice that is not an action. A select
                  // that starts on the first real action makes Apply pressable
                  // before anyone has chosen anything, and the first action in
                  // the list is as likely to be "delete for ever" as anything
                  // else.
                  {
                    type: "text",
                    size: "1",
                    text: context.actionChooseLabel,
                    value: "",
                    selected: !context.action,
                  },
                  ...context.actions.map((action) => ({
                    type: "text",
                    size: "1",
                    text: action.text,
                    value: action.value,
                    selected: action.value === context.action,
                    disabled: Boolean(action.disabled),
                  })),
                ]}
                @change=${(event) => component.setAction(event.detail.value)}
              ></sf-dropdown>
              <sf-button
                size="1"
                type="default"
                scheme="primary"
                text=${context.actionApplyText}
                ?disabled=${!context.action}
                @click=${() => component.applyAction()}
              ></sf-button>
              ${context.showActionForAll
                ? html`
                    <span class="sf-pagination-actions-separator" aria-hidden="true"></span>
                    <sf-checkbox
                      label=${context.countKnown
                        ? `${context.actionForAllLabel} (${context.total})`
                        : context.actionForAllLabel}
                      ?checked=${Boolean(context.actionForAll)}
                      @change=${(event) =>
                        component.setActionForAll(Boolean(event.target?.checked))}
                    ></sf-checkbox>
                  `
                : ""}
              <sf-icon-button
                class="sf-pagination-actions-clear"
                size="1"
                type="link"
                scheme="on-surface"
                icon="close"
                title=${context.clearSelectionLabel}
                aria-label=${context.clearSelectionLabel}
                @click=${() => component.clearSelection()}
              ></sf-icon-button>
            </div>
          `
        : ""}
    </nav>
  `;
}
