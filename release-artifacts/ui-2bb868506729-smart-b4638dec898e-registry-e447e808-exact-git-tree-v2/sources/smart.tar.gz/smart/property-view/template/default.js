import {html, nothing} from 'lit';
import "./default.css";
import {renderViewField, renderEditField} from '../../../field-renderers/index.js';

// The arrangement, drawn in the component's own light DOM. Not in a shadow root:
// the field controls are Smart elements whose stylesheets are document-level, and
// a document stylesheet does not cross a shadow boundary. sf-data-view slots its
// children for exactly this reason and says so beside the slot; the first version
// of this composite built them inside a shadow root and every control came out
// with its markup and none of its CSS.

function renderFieldValue(context, field, editing) {
    const key = String(field.key ?? '');
    const content = editing
        ? renderEditField(
            field,
            context.changed.has(key) ? context.changed.get(key) : field.value,
            {setFieldValue: (target, value) => context.component.changeField(target, value)},
        )
        : renderViewField(field, field.value, context.hostPort);

    if (content === null || typeof content === 'undefined' || content === nothing) {
        return html`<span class="sf-property-view-empty">${context.emptyText}</span>`;
    }

    return content;
}

function renderField(context, field, editing) {
    const key = String(field.key ?? '');
    const error = context.errors.get(key);

    return html`
        <div class="sf-property-view-field ${field.width === 'full' ? 'sf-property-view-field--full' : ''}"
             data-field=${key}>
            <div class="sf-property-view-field-label">
                ${String(field.label ?? key)}
                ${field.required ? html`<span class="sf-property-view-required" aria-hidden="true">*</span>` : nothing}
            </div>
            <div class="sf-property-view-field-value">${renderFieldValue(context, field, editing)}</div>
            ${error
                    ? html`<div class="sf-property-view-field-error" role="alert">${error}</div>`
                    : nothing}
        </div>
    `;
}

function renderGroup(context, section, group) {
    const groupKey = String(group.key ?? '');
    const editing = context.editing?.group === groupKey
        && context.editing?.section === String(section.key ?? '');
    const fields = context.visible(group.fields);

    return html`
        <section class="sf-property-view-group ${editing ? 'sf-property-view-group--editing' : ''}"
                 data-group=${groupKey}
                 data-columns=${group.columns === 2 ? '2' : '1'}>
            <header class="sf-property-view-group-header">
                <h3 class="sf-property-view-group-title">${String(group.label ?? groupKey)}</h3>
                ${!editing && group.editable !== false
                        ? html`
                            <sf-button
                                    appearance="link"
                                    size="1"
                                    text=${context.editText}
                                    data-action="edit"
                                    @click=${() => context.component.editGroup(String(section.key ?? ''), groupKey)}
                            ></sf-button>`
                        : nothing}
            </header>
            <div class="sf-property-view-group-fields">
                ${fields.map((field) => renderField(context, field, editing))}
            </div>
        </section>
    `;
}

function renderSectionList(context, sections) {
    // One section is drawn as its groups alone: a list of one is a control nobody
    // can use, and the consumer's request asks for the groups to stand alone.
    if (sections.length < 2) return nothing;

    return html`
        <nav class="sf-property-view-sections" aria-label=${context.sectionsLabel}>
            <sf-tree selection="single">
                ${sections.map((section) => html`
                    <sf-tree-item
                            label=${String(section.label ?? section.key)}
                            value=${String(section.key)}
                            ?selected=${String(section.key) === context.selectedSection}
                            @click=${() => context.component.selectSection(String(section.key))}
                    ></sf-tree-item>
                `)}
            </sf-tree>
        </nav>
    `;
}

function renderActions(context) {
    if (!context.editing) return nothing;

    return html`
        <div class="sf-property-view-actions" role="group">
            <span class="sf-property-view-changed">${context.changedText}: ${context.changed.size}</span>
            ${context.errors.size
                    ? html`<span class="sf-property-view-errors">${context.errorsText}: ${context.errors.size}</span>`
                    : nothing}
            ${context.conflict
                    ? html`<span class="sf-property-view-conflict" role="alert">${context.conflict}</span>`
                    : nothing}
            <sf-button
                    appearance="primary"
                    size="1"
                    text=${context.saveText}
                    data-action="save"
                    ?disabled=${context.changed.size === 0}
                    @click=${() => context.component.saveGroup()}
            ></sf-button>
            <sf-button
                    appearance="outline"
                    size="1"
                    text=${context.cancelText}
                    data-action="cancel"
                    @click=${() => context.component.cancelEdit()}
            ></sf-button>
        </div>
    `;
}

export function renderPropertyViewTemplate(context) {
    const sections = context.visible(context.sections);
    const current = sections.find((section) => String(section.key) === context.selectedSection)
        ?? sections[0] ?? null;

    return html`
        <div class="sf-property-view-status" role="status" aria-live="polite" ?hidden=${!context.message}>
            ${context.message}
        </div>
        <div class="sf-property-view-layout" data-sections=${String(sections.length)}>
            ${renderSectionList(context, sections)}
            <div class="sf-property-view-body">
                ${context.visible(current?.groups).map((group) => renderGroup(context, current, group))}
            </div>
        </div>
        ${renderActions(context)}
    `;
}
