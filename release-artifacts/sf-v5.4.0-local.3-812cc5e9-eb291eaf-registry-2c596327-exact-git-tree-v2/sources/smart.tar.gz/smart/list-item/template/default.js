import { html, nothing } from "lit";

export function renderListItemTemplate(context) {
  const textContent = context.component?.hasSlotContent?.("text")
    ? context.component.getSlotContent("text")
    : context.text;

  const leadingContent = context.component?.hasSlotContent?.("leading")
    ? context.component.getSlotContent("leading")
    : nothing;

  const trailingContent = context.component?.hasSlotContent?.("trailing")
    ? context.component.getSlotContent("trailing")
    : nothing;

  const classes = [
    "sf-list-item",
    "cursor-pointer",
    "flex",
    "items-cross-center",
    `sf-list-item--${context.type}`,
    `sf-list-item--size-${context.size}`,
    "transition",
    context.selected ? "selected" : "",
    context.disabled ? "disabled" : "",
  ].filter(Boolean);

  const wrapClasses = ["sf-list-item-wrap", "flex", "flex-1"];
  const isDecoratedType = ["icon", "checkbox", "avatar", "color"].includes(
    context.type,
  );

  if (isDecoratedType) {
    wrapClasses.push(
      "flex",
      "flex-row",
      "flex-nowrap",
      "items-center",
      "gap-2",
    );
  }

  if (context.type === "avatar" || context.type === "color") {
    wrapClasses.splice(wrapClasses.indexOf("gap-2"), 1);
    wrapClasses.push("justify-between", "gap-2");
  }

  const renderLeading = () => {
    if (leadingContent !== nothing) return leadingContent;

    if (context.type === "icon") {
      return html`<i class="sf-icon">${context.icon}</i>`;
    }

    if (context.type === "checkbox") {
      return html`
        <label
          class="sf-checkbox sf-checkbox--size-${context.sizeGroup
            .checkbox} flex"
        >
          <span class="sf-checkbox-box transition flex">
            <input
              ?checked=${context.checked}
              ?disabled=${context.disabled}
              type="checkbox"
            />
            <span class="sf-icon" aria-hidden="true"></span>
          </span>
        </label>
      `;
    }

    if (context.type === "avatar") {
      const avatarClasses = [
        "sf-avatar",
        `sf-avatar--size-${context.sizeGroup.item === "1/3" || context.sizeGroup.item === "1/2" ? "1/3" : context.sizeGroup.item === "1" ? "1/2" : context.sizeGroup.item === "2" ? "1" : "2"}`,
        "bg-cover",
        context.disabled ? "disabled" : "",
      ].filter(Boolean);

      return html`
        <div
          class="sf-avatar-label-group sf-avatar-label-group--size-${context
            .sizeGroup.avatarGroup} flex items-cross-center"
        >
          <span
            class=${avatarClasses.join(" ")}
            style=${context.avatarImageUrl
              ? `background-image: url(${context.avatarImageUrl});`
              : nothing}
          ></span>
          <div class="sf-avatar-label-group-container flex flex-col">
            <div class="sf-avatar-label-group-title">
              ${context.avatarTitle}
            </div>
          </div>
        </div>
      `;
    }

    if (context.type === "color") {
      const tagClasses = [
        "sf-tag",
        "sf-tag--color",
        `sf-tag--size-${context.sizeGroup.colorTag}`,
        "flex",
        "flex-row",
        "flex-nowrap",
        "items-center",
        "flex-1",
        context.disabled ? "disabled" : "",
      ].filter(Boolean);

      return html`
        <div class=${tagClasses.join(" ")}>
          <span class="sf-tag-color-icon ${context.colorClass}"></span>
          <span class="sf-tag-container">${textContent}</span>
        </div>
      `;
    }

    return nothing;
  };

  const renderText = () => {
    if (context.type === "color") return nothing;
    if (context.type === "avatar") return nothing;
    return html`<div class="sf-list-item-container">${textContent}</div>`;
  };

  const renderTrailing = () => {
    if (trailingContent !== nothing) return trailingContent;

    if (context.type === "avatar" || context.type === "color") {
      return html`
        <label
          class="sf-checkbox sf-checkbox--size-${context.sizeGroup
            .checkbox} flex"
        >
          <span class="sf-checkbox-box transition flex">
            <input
              ?checked=${context.checked}
              ?disabled=${context.disabled}
              type="checkbox"
            />
            <span class="sf-icon" aria-hidden="true"></span>
          </span>
        </label>
      `;
    }

    return nothing;
  };

  return html`
    <div
      class=${classes.join(" ")}
      role="button"
      tabindex=${context.disabled ? "-1" : "0"}
      data-value=${context.value || nothing}
      aria-label=${context.ariaLabel || nothing}
      aria-disabled=${context.disabled ? "true" : nothing}
      aria-selected=${context.selected ? "true" : nothing}
    >
      <div class=${wrapClasses.join(" ")}>
        ${renderLeading()} ${renderText()} ${renderTrailing()}
      </div>
    </div>
  `;
}
