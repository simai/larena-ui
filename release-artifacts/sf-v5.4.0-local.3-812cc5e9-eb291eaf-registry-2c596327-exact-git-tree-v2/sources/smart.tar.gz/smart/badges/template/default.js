import { html, nothing } from 'lit';

function createIcon(name) {
  if (!name) return nothing;

  return html`
    <span class="sf-badge-icon-container flex justify-center items-center">
      <i class="sf-icon flex justify-center items-center">${name}</i>
    </span>
  `;
}

export function renderBadgeTemplate(context) {
  const normalizedIconPosition = String(context.iconPosition || 'start').toLowerCase();
  const isIconEnd = ['right', 'end'].includes(normalizedIconPosition);
  const leftIconName = context.iconLeft || (context.icon && !isIconEnd ? context.icon : '');
  const rightIconName = context.iconRight || (context.icon && isIconEnd ? context.icon : '');

  const leftIconContent = context.component?.hasSlotContent?.('icon-left')
    ? context.component.getSlotContent('icon-left')
    : createIcon(leftIconName);

  const rightIconContent = context.component?.hasSlotContent?.('icon-right')
    ? context.component.getSlotContent('icon-right')
    : createIcon(rightIconName);

  const hasTextSlot = context.component?.hasSlotContent?.('text');
  const hasTextContent = hasTextSlot || String(context.text ?? '').length > 0;
  const textContent = hasTextSlot
    ? context.component.getSlotContent('text')
    : context.text;

  const classes = [
    'sf-badge',
    `sf-badge--${context.type}`,
    `sf-badge--${context.scheme}`,
    `sf-badge--size-${context.size}`,
    'flex',
    'flex-row',
    'flex-nowrap',
    'justify-center',
    'items-center',
  ].filter(Boolean);

  return html`
    <div class=${classes.join(' ')} aria-label=${context.ariaLabel || nothing}>
      ${leftIconContent}
      ${hasTextContent
        ? html`
            <span class="sf-badge-text-container flex items-center">
              <span class="sf-badge-text">${textContent}</span>
            </span>
          `
        : nothing}
      ${rightIconContent}
    </div>
  `;
}
