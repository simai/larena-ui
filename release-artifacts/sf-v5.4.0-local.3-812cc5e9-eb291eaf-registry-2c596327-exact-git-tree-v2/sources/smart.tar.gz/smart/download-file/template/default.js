import { html, nothing } from 'lit';

export function renderDownloadFileTemplate(context) {
  const {
    size,
    fileName,
    fileSize,
    icon,
    href,
    download,
    disabled,
    target,
    ariaLabel,
  } = context;

  const tagName = href && !disabled ? 'a' : 'button';
  const rootClasses = [
    'sf-download-file',
    `sf-download-file--size-${size}`,
    disabled ? 'disabled' : 'cursor-pointer transition',
  ].filter(Boolean);

  const content = html`
    <div class="sf-download-file-wrap flex items-cross-center">
      <div class="sf-download-file-container flex flex-1 items-cross-center">
        <i class="sf-icon">${icon}</i>
        <span class="sf-download-file-file-name">${fileName}</span>
      </div>
      <span class="sf-download-file-file-size">${fileSize}</span>
    </div>
  `;

  if (tagName === 'a') {
    return html`
      <a
        class=${rootClasses.join(' ')}
        href=${href}
        target=${download ? nothing : target}
        rel=${download ? nothing : 'noopener noreferrer'}
        download=${download ? fileName || '' : nothing}
        aria-label=${ariaLabel || nothing}
      >
        ${content}
      </a>
    `;
  }

  return html`
    <button
      type="button"
      class=${rootClasses.join(' ')}
      ?disabled=${disabled}
      aria-disabled=${disabled ? 'true' : nothing}
      aria-label=${ariaLabel || nothing}
    >
      ${content}
    </button>
  `;
}
