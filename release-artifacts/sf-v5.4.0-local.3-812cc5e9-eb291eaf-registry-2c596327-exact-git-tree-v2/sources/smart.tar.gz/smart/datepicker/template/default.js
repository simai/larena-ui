import {html, nothing} from 'lit';

// import {whenRef} from "../../../helpers/refs";

function joinClasses(...tokens) {
    return tokens.flat().filter(Boolean).join(' ');
}

function renderTop(context) {
    if (context.context === 'year') {
        return renderYearTop(context);
    }

    return html`
        <div class="sf-datepicker-top flex content-main-between">
            <sf-button
            type="link"
            scheme="on-surface"
            tightness="low"
            text="${context.monthLabel}"
            icon-right="expand_${context.context === 'month' ? 'less': 'more'}"
            @click=${() => context.component.toggleContext('month')}
            >
            </sf-button>
            <sf-button
                    type="link"
                    scheme="on-surface"
                    tightness="low"
                    text="${context.year}"
                    icon-right="expand_${context.context === 'year' ? 'less': 'more'}"
                    @click=${() => context.component.toggleContext('year')}
            >
            </sf-button>
        </div>
    `;
}

function renderYearTop(context) {
    return html`
        <div class="sf-datepicker-top flex content-main-between items-cross-center">
            <sf-icon-button
                    type="link"
                    scheme="on-surface"
                    size="1"
                    icon="keyboard_arrow_left"
                    aria-label="Previous years"
                    @click=${() => context.component.shiftYearPage(-1)}
            ></sf-icon-button>
            <div class="sf-datepicker-range-title">
                ${context.yearPageStart} - ${context.yearPageEnd}
            </div>
            <sf-icon-button
                    type="link"
                    scheme="on-surface"
                    size="1"
                    icon="keyboard_arrow_right"
                    aria-label="Next years"
                    @click=${() => context.component.shiftYearPage(1)}
            ></sf-icon-button>
        </div>
    `;
}

function renderMonthContext(context) {
    return html`
        <div class="sf-datepicker-context absolute top-0 bottom-0 inline-start-0 inline-end-0 grid grid-col-3 content-cross-start items-cross-start z-2 overflow-auto gap-1/4">
            ${context.months.map((month) => html`
                <button
                        class=${joinClasses(
                                'sf-datepicker-text flex content-main-center items-cross-center',
                                month.selected ? 'active' : '',
                                month.disabled ? 'disabled' : '',
                        )}
                        ?disabled=${month.disabled}
                        type="button"
                        @click=${() => context.component.selectMonth(month)}
                >
                    <span class="sf-datepicker-text-date">${month.label}</span>
                </button>
            `)}
        </div>
    `;
}

function renderYearContext(context) {
    return html`
        <div class="sf-datepicker-context absolute top-0 bottom-0 inline-start-0 inline-end-0 grid grid-col-3 content-cross-start items-cross-start z-2 overflow-auto gap-1/4">
            ${context.years.map((year) => html`
                <button
                        class=${joinClasses(
                                'sf-datepicker-text flex content-main-center items-cross-center',
                                year.selected ? 'active' : '',
                                year.disabled ? 'disabled' : '',
                        )}
                        type="button"
                        ?disabled=${year.disabled}
                        @click=${() => context.component.selectYear(year)}
                >
                    <span class="sf-datepicker-text-date">${year.year}</span>
                </button>
            `)}
        </div>
    `;
}

function renderContext(context) {
    if (context.context === 'month') {
        return renderMonthContext(context);
    }

    if (context.context === 'year') {
        return renderYearContext(context);
    }

    return nothing;
}



function renderDatepickerInput(context) {
    return html`
        <sf-input
                class="sf-datepicker-input"
                :ref=${context.component.refs.input}
                type=${context.inputType}
                size=${context.inputSize}
                name=${context.inputName || nothing}
                placeholder=${context.placeholder || nothing}
                left-icon=${context.leftIcon || nothing}
                root-class=${context.inputRootClass || nothing}
                value=${context.displayValue || ''}
                ?mask=${context.mask}
                mask-pattern=${context.maskPattern || nothing}
                mask-lazy=${String(context.maskLazy)}
                mask-placeholder-char=${context.maskPlaceholderChar || nothing}
                mask-options=${context.maskOptions || nothing}
                readonly
                @click=${(event) => context.component.handleInputClick(event)}
                @focusin=${(event) => context.component.handleInputClick(event)}
        ></sf-input>
    `;
}

export function renderDatepickerTemplate(context) {
    const {refs, state} = context.component;
    if (!context.input) {
        return renderDatepickerPanel(context);
    }

    function renderDay(day) {
        const classes = joinClasses(
            'sf-datepicker-day',
            day.weekend ? 'sf-datepicker-day-off' : '',
            day.selected ? 'active' : '',
            day.rangeStart ? 'sf-datepicker-day-start' : '',
            day.rangeSelected ? 'sf-datepicker-day-selected' : '',
            day.rangeEnd ? 'sf-datepicker-day-end' : '',
            day.currentMonth ? '' : 'sf-datepicker-another-month',
            day.disabled ? 'disabled' : ''
        );

        return html`
            <button
                    class=${classes}
                    type="button"
                    ?disabled=${day.disabled}
                    data-date=${day.value}
                    @click=${() => context.component.selectDate(day)}
            >
                <span class="sf-datepicker-day-date">${day.day}</span>
            </button>
        `;
    }

    function renderDatepickerPanel() {
        const rootClasses = joinClasses('sf-datepicker inline-flex', context.rootClass);

        return html`
        <div
                :ref=${refs.datePickerPanel}
                class=${rootClasses}
                style=${context.rootStyle || nothing}
                @click=${(event) => context.component.handlePanelClick(event)}
        >
            <div class="sf-datepicker-container flex flex-col">
                ${renderTop(context)}
                <div class="sf-datepicker-main relative">
                    ${renderContext(context)}
                    <div class="grid grid-col-7">
                        ${context.days.map((day) => renderDay(day, context))}
                    </div>
                </div>
            </div>
        </div>
    `;
    }

    return html`
        <div
                class=${joinClasses(
                        'sf-datepicker-wrap inline-flex flex-col relative',
                        context.open ? 'is-open' : '',
                        state ? 'sf-datepicker-wrap--drop-up' : 'sf-datepicker-wrap--drop-down'
                )}
                :ref=${refs.datepickerRoot}
                data-portal=${context.portal ? 'true' : 'false'}
        >
            ${renderDatepickerInput(context)}
            ${context.open ? renderDatepickerPanel(context) : nothing}
        </div>
    `;
}
