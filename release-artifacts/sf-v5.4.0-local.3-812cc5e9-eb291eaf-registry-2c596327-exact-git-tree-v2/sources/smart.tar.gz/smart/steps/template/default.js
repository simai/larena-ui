import { html } from 'lit';

function joinClasses(...tokens) {
  return tokens.flat().filter(Boolean).join(' ');
}

function renderStep(item, context) {
  const stepClasses = joinClasses(
    'sf-step',
    'transition',
    `sf-step--size-${context.size}`,
    `sf-step--stage-${item.stage}`,
    'flex',
    'items-center',
    'justify-center',
    item.selected ? 'selected' : '',
    item.disabled ? 'disabled' : 'cursor-pointer',
  );

  const iconName =
    item.stage === 'completed' ? 'check_circle' : item.stage === 'error' ? 'error' : '';

  return html`
    <div
      class=${stepClasses}
      data-step-index=${String(item.index)}
      tabindex=${item.disabled ? '-1' : '0'}
      role=${item.disabled ? 'presentation' : 'button'}
      aria-disabled=${item.disabled ? 'true' : 'false'}
      aria-current=${item.selected ? 'step' : 'false'}
    >
      ${iconName ? html`<i class="sf-icon">${iconName}</i>` : ''}
      <div class="sf-step-container flex items-center justify-center">${item.label}</div>
    </div>
  `;
}

export function renderStepsTemplate(context) {
  const rootClasses = joinClasses(
    'sf-steps',
    `sf-steps--size-${context.size}`,
    'flex',
    'flex-col',
    context.rootClass,
  );

  return html`
    <div class=${rootClasses}>
      <div class="sf-steps-container flex items-center">
        ${context.items.map(
          (item, index) => html`
            ${renderStep(item, context)}
            ${index < context.items.length - 1
              ? html`<i class="sf-icon">${context.separatorIcon}</i>`
              : ''}
          `,
        )}
      </div>
    </div>
  `;
}
