import {html, nothing} from 'lit';
import './default.css';

function closeSize(size) {
    return size === '1' ? '1/3' : '1/4';
}

function checkboxSize(size) {
    return size === '1' ? '1' : '1/3';
}

function dotSize(size) {
    return size === '1' ? '1/2' : '1/3';
}

function renderCheckboxIcon(context) {
    return context.component?.hasSlotContent?.('leading')
        ? context.component.getSlotContent('leading')
        : html`
                <sf-checkbox
                        checked="${context.active}"
                        disabled=${context.disabled}
                        size="${checkboxSize(context.size)}"
                ></sf-checkbox>
        `;


}

function renderGenericIcon(context) {
    const iconName = context.icon || 'sell';

    return context.component?.hasSlotContent?.('leading')
        ? context.component.getSlotContent('leading')
        : html`<i class="sf-icon sf-tag-icon">${iconName}</i>`;
}

function renderColorIcon(context) {
    const extraClass = context.colorClass || '';

    return context.component?.hasSlotContent?.('leading')
        ? context.component.getSlotContent('leading')
        : html`<span class=${['sf-tag-color-icon', extraClass].filter(Boolean).join(' ')}></span>`;
}

function renderStatusDot(context) {
    return context.component?.hasSlotContent?.('leading')
        ? context.component.getSlotContent('leading')
        : html`
                <div class="sf-dot sf-dot--size-${dotSize(context.size)}">
                    <div class="sf-dot-item"></div>
                </div>
        `;
}

function renderAvatar(context) {
    if (context.component?.hasSlotContent?.('avatar')) {
        return context.component.getSlotContent('avatar');
    }

    if (context.avatarImageUrl) {
        return html`
            <span
                    class="sf-avatar sf-avatar--size-1/4 bg-cover"
                    style=${`background-image: url(${context.avatarImageUrl});`}
            ></span>
        `;
    }

    if (context.avatarText) {
        return html`
            <span class="sf-avatar sf-avatar--size-1/4 sf-avatar--text flex justify-center items-center">
        ${context.avatarText}
      </span>
        `;
    }

    return html`
        <span class="sf-avatar sf-avatar--size-1/4 sf-avatar--placeholder flex justify-center items-center">
      <i class="sf-icon">person</i>
    </span>
    `;
}

function renderLeading(context) {
    switch (context.type) {
        case 'checkbox':
            return renderCheckboxIcon(context);
        case 'icon':
            return renderGenericIcon(context);
        case 'color':
            return renderColorIcon(context);
        case 'avatar':
            return renderAvatar(context);
        case 'success':
        case 'error':
        case 'warning':
            return renderStatusDot(context);
        default:
            return nothing;
    }
}

function renderCount(context) {
    if (context.type !== 'default') return nothing;

    return context.component?.hasSlotContent?.('count')
        ? context.component.getSlotContent('count')
        : html`<span class="sf-tag-count pointer-events-none flex">${context.count || nothing}</span>`;
}

function renderClose(context) {
    if (!context.closable) return nothing;

    return context.component?.hasSlotContent?.('close')
        ? context.component.getSlotContent('close')
        : html`
                <sf-icon-button
                        variant="close"
                        size="${closeSize(context.size)}"
                        type="link"
                        scheme="on-surface"
                        disabled=${context.disabled}
                        @click="${(e) => {
                            e.stopPropagation();
                            context.component.onClose(this);
                        }}"
                ></sf-icon-button>
        `;
}

export function renderTagTemplate(context) {
    const textContent = context.component?.hasSlotContent?.('text')
        ? context.component.getSlotContent('text')
        : context.text;

    const classes = [
        'sf-tag',
        'transition',
        `sf-tag--${context.type}`,
        `sf-tag--size-${context.size}`,
        'inline-flex',
        'flex-row',
        'flex-nowrap',
        'items-center',
        `${context.rootClass}`,
        context.active ? 'active' : '',
        context.disabled ? 'disabled' : '',
    ].filter(Boolean);

    return html`
        <div
                tabindex=${context.disabled ? '-1' : '0'}
                role="button"
                class=${classes.join(' ')}
                aria-label=${context.ariaLabel || nothing}
                aria-disabled=${context.disabled ? 'true' : nothing}
                aria-pressed=${context.type === 'checkbox' ? String(context.active) : nothing}
        >
            ${renderLeading(context)}
            <span class="sf-tag-container pointer-events-none">${textContent}</span>
            ${renderCount(context)}
            ${renderClose(context)}
        </div>
    `;
}
