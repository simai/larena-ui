import { html, nothing } from 'lit';

function normalizeValue(value) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    return 0;
  }
  return Math.max(0, Math.min(100, parsed));
}

export function renderProgressBarTemplate(context) {
  const { size, value, textPosition } = context;
  const normalizedValue = normalizeValue(value);
  const normalizedPosition = ['none', 'right', 'inline-end', 'bottom'].includes(textPosition)
    ? textPosition
    : 'none';

  const rootClasses = ['sf-progress-bar', `sf-progress-bar--size-${size}`, 'flex'];
  if (normalizedPosition === 'right' || normalizedPosition === 'inline-end') {
    rootClasses.push('flex-row', 'items-cross-center');
  } else if (normalizedPosition === 'bottom') {
    rootClasses.push('flex-col', 'items-cross-end');
  }

  return html`
    <div
      class=${rootClasses.join(' ')}
      data-value=${String(normalizedValue)}
      data-text-position=${normalizedPosition}
    >
      <div class="sf-progress-bar-main">
        <div class="sf-progress-bar-progress transition"></div>
      </div>
      ${normalizedPosition !== 'none'
        ? html`<div class="sf-progress-bar-text">${normalizedValue}%</div>`
        : nothing}
    </div>
  `;
}
