import { html } from 'lit';

export function renderTextareaTemplate(context) {
  const {
    size,
    type,
    label,
    required,
    placeholder,
    hint,
    value,
    name,
    rows,
    disabled,
    error,
    mask,
    maskPattern,
    maskOptions,
  } = context;

  const rootClasses = [
    'sf-textarea',
    `sf-textarea--size-${size}`,
    `sf-textarea--${type}`,
    error ? 'error' : '',
    'flex',
    'flex-col',
  ].filter(Boolean);

  const labelContent = label
    ? html`
        <span class="sf-textarea-text">${label}</span>
        ${required ? html`<span class="sf-textarea-required">*</span>` : ''}
      `
    : required
      ? html`<span class="sf-textarea-required">*</span>`
      : '';

  return html`
    <label
      class=${rootClasses.join(' ')}
      data-mask=${String(mask)}
      data-mask-pattern=${maskPattern || ''}
      data-mask-options=${maskOptions || ''}
    >
      ${labelContent
        ? html`
            <span class="sf-textarea-label flex">
              ${labelContent}
            </span>
          `
        : ''}

      <textarea
        class=${`transition${error ? ' error' : ''}`}
        placeholder=${placeholder}
        .value=${value}
        name=${name || ''}
        rows=${rows}
        ?disabled=${disabled}
        data-mask=${String(mask)}
        data-mask-pattern=${maskPattern || ''}
        data-mask-options=${maskOptions || ''}
      ></textarea>

      ${hint ? html`<span class="sf-textarea-hint-text-wrap">${hint}</span>` : ''}
    </label>
  `;
}
