import { html } from 'lit';

function normalizeList(value, fallback = []) {
  if (value == null || value === '') return [...fallback];
  if (Array.isArray(value)) return value;
  return `${value}`
    .replace(/^\[|\]$/g, '')
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
}

function resolveSize(value) {
  if (value == null || value === '') return '';
  const token = `${value}`.trim().replace(/^\[|\]$/g, '');
  if (/^[a-g][0-9]+(?:\/[0-9]+)?$/i.test(token)) {
    return `var(--sf-${token.toLowerCase()})`;
  }
  return token;
}

function styleMap(style = {}) {
  return Object.entries(style)
    .filter(([, value]) => value !== undefined && value !== null && value !== '')
    .map(([key, value]) => `${key}: ${value}`)
    .join('; ');
}

export function renderSkeletonTemplate(context) {
  const {
    size,
    width,
    height,
    count,
    animation,
    variant,
    type,
    rootClass,
  } = context;

  const widths = normalizeList(width, ['100%']);
  const heights = normalizeList(height);
  const rootClasses = ['sf-skeleton', 'flex'];
  if (type !== 'icon') {
    rootClasses.push('flex-1');
  }
  if (animation) {
    rootClasses.push(`sf-skeleton--animation-${animation}`);
  }
  if (rootClass) {
    rootClasses.push(...String(rootClass).split(/\s+/).filter(Boolean));
  }

  const rootStyle =
    type !== 'icon' && widths.length
      ? styleMap({
          width: resolveSize(widths[0]),
        })
      : '';

  const itemsCount = Number.isFinite(Number(count)) && Number(count) > 0 ? Number(count) : 1;

  return html`
    <div class=${rootClasses.join(' ')} style=${rootStyle}>
      ${Array.from({ length: itemsCount }, (_, index) => {
        const itemClasses = ['sf-skeleton-text', `sf-skeleton-text--size-${size}`];
        if (variant && variant !== 'text') {
          itemClasses.push(`sf-skeleton-${variant}`);
        }
        if (type) {
          itemClasses.push(`sf-skeleton-${type}`);
        }

        const resolvedWidth = widths[index % widths.length] || '';
        const resolvedHeight = heights[index % heights.length] || '';
        const itemStyle =
          type !== 'icon'
            ? styleMap({
                width: resolveSize(resolvedWidth || '100%'),
                height: resolvedHeight ? resolveSize(resolvedHeight) : '',
              })
            : '';

        return html`
          <div
            class=${itemClasses.join(' ')}
            style=${itemStyle}
            data-sf-skeleton-item=${String(index)}
          ></div>
        `;
      })}
    </div>
  `;
}
