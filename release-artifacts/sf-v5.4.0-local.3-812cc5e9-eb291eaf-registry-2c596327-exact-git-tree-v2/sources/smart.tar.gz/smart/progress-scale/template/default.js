import { html, nothing } from 'lit';

function normalizeProgressValue(value) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    return 0;
  }

  return Math.max(0, Math.min(100, parsed));
}

function normalizeScaleStep(value) {
  const normalized = normalizeProgressValue(value);
  return Math.ceil(normalized / 10) * 10;
}

export function renderProgressScaleTemplate(context) {
  const size = context.size || '1';
  const value = normalizeProgressValue(context.value);
  const step = normalizeScaleStep(value);
  const rootClasses = [
    'sf-progress-scale',
    `sf-progress-scale--size-${size}`,
    'flex',
    'flex-col',
  ];

  if (step > 0) {
    rootClasses.push(`sf-progress-scale--${step}`);
  }

  return html`
    <div class=${rootClasses.join(' ')} data-value=${String(value)}>
      <div class="sf-progress-scale-container grid grid-col-10 overflow-hidden">
        ${Array.from({ length: 10 }, () => html`<div class="sf-progress-scale-block"></div>`)}
      </div>
      ${context.showText
        ? html`<div class="sf-scale-text">${value}%</div>`
        : nothing}
    </div>
  `;
}
