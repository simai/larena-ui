import { html } from "lit";

function getIconData(context) {
  const { icon, size, filled, rounded, shape, weightClass, loaded, rootClass } =
    context;

  const className = [
    "sf-icon",
    size ? `sf-icon--size-${size}` : "",
    loaded ? "sf-icon-loaded" : "",
    weightClass ? `sf-icon-${weightClass}` : "",
    rounded ? "sf-icon-rounded" : "",
    shape ? "sf-icon-shape" : "",
    filled ? "sf-icon-filled" : "",
    rootClass,
  ]
    .filter(Boolean)
    .join(" ");

  return { icon, className };
}

export function renderIconTemplate(context) {
  const { icon, className } = getIconData(context);

  return html`<i class="${className}" style=${context.rootStyle || ""}
    >${icon}</i
  >`;
}

renderIconTemplate.getIconData = getIconData;
