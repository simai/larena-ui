import {html, nothing} from 'lit';


export function renderButtonTemplate(context) {
    const {
        size,
        type,
        scheme,
        text,
        icon,
        iconLeft,
        iconRight,
        iconPosition,
        tightness,
        radius,
        rootClass,
        textPosition,
        loading,
        disabled,
        nativeType,
        ariaLabel,
        segment,
    } = context;

    const normalizedIconPosition = String(iconPosition || 'start').toLowerCase();
    const isIconEnd = ['right', 'end'].includes(normalizedIconPosition);
    const leftIconName = iconLeft || (icon && !isIconEnd ? icon : '');
    const rightIconName = iconRight || (icon && isIconEnd ? icon : '');
    const component = context.component;
    const leftIconContent =
        component?.hasSlotContent?.('icon-left')
            ? component.getSlotContent('icon-left')
            : component.createIcon(leftIconName);
    const rightIconContent =
        component?.hasSlotContent?.('icon-right')
            ? component.getSlotContent('icon-right')
            : component.createIcon(rightIconName);
    const textContent =
        component?.hasSlotContent?.('text')
            ? component.getSlotContent('text')
            : text;
    const fullText = !leftIconContent && !rightIconContent;
    const rootClasses = [
        'sf-button',
        `sf-button--size-${size}`,
        `sf-button--${type}`,
        `sf-button--${scheme}`,
        'flex',
        'items-cross-center',
        segment ? `segment-${segment}` : '',
        tightness ? `tightness-${tightness}` : '',
        radius ? `radius-${radius}` : '',
        rootClass,
        loading ? 'loading sf-button-state-loading' : '',
    ].filter(Boolean);

    return html`
        <button
                type=${nativeType}
                class=${rootClasses.join(' ')}
                ?disabled=${disabled}
                aria-label=${ariaLabel || nothing}
                aria-busy=${loading ? 'true' : nothing}
        >
            ${leftIconContent}
            ${textContent ? html`<span
                    class="sf-button-text-container text-${textPosition} pointer-event-none${fullText ? ' flex-1' : ''}">
        ${textContent}
      </span>` : ''}
            ${rightIconContent}
        </button>
    `;
}
