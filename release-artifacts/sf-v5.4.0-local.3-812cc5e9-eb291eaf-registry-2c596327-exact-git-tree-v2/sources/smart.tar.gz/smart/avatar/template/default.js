import { avatarButton } from "./shared";

export function renderDefaultTemplate(context) {
  return avatarButton(context);
}
