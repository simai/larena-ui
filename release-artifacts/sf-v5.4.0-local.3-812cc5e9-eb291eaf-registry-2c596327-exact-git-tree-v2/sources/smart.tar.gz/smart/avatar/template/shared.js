import {html, nothing} from "lit";

function getCompanyBadge(context) {
    return html`<span
            class="sf-avatar-badge sf-avatar-badge--size-${context.size} sf-avatar-badge--company overflow-hidden flex absolute bottom-0 inline-end-0"
    >
    <svg viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M56 0H0V55.9998H56V0Z" fill="#E81123"></path>
      <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M8.12891 28.0004L23.1261 12.9463L27.9999 17.8386L17.8754 28.0016L27.998 38.1627L23.1254 43.0538L8.12891 28.0004Z"
              fill="#F7F7F7"
      ></path>
      <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M47.8706 28.0004L32.8735 12.9463L27.9996 17.8386L38.1241 28.0016L28.0015 38.1627L32.8741 43.0538L47.8706 28.0004Z"
              fill="#F7F7F7"
      ></path>
    </svg>
  </span>`;
}

function getVerifiedBadge(context) {
    return html`
        <span
                class="sf-avatar-badge sf-avatar-badge--size-${context.size} sf-avatar-badge--verified overflow-hidden flex absolute bottom-0 inline-end-0"
        >
      <svg viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g clip-path="url(#sf-avatar-verified-badge)">
          <path
                  d="M15.4447 3.54197C15.6347 4.00136 15.9993 4.36651 16.4584 4.55716L18.0683 5.22398C18.5277 5.41428 18.8927 5.7793 19.083 6.23872C19.2733 6.69815 19.2733 7.21436 19.083 7.67379L18.4167 9.28249C18.2263 9.74212 18.226 10.2589 18.4173 10.7183L19.0824 12.3265C19.1768 12.554 19.2254 12.7979 19.2254 13.0443C19.2254 13.2906 19.1769 13.5345 19.0827 13.7621C18.9884 13.9897 18.8502 14.1965 18.676 14.3706C18.5018 14.5448 18.295 14.6829 18.0674 14.7771L16.4587 15.4434C15.9993 15.6334 15.6341 15.998 15.4435 16.4571L14.7767 18.067C14.5864 18.5264 14.2213 18.8914 13.7619 19.0817C13.3025 19.272 12.7863 19.272 12.3269 19.0817L10.7181 18.4153C10.2587 18.2255 9.74268 18.2259 9.28353 18.4164L7.67367 19.0823C7.2145 19.2722 6.69874 19.272 6.23969 19.0818C5.78063 18.8917 5.41582 18.5271 5.22539 18.0682L4.55837 16.4578C4.36841 15.9985 4.00381 15.6333 3.5447 15.4427L1.93484 14.7758C1.47561 14.5856 1.11071 14.2208 0.920338 13.7617C0.729967 13.3025 0.729708 12.7865 0.91962 12.3272L1.58597 10.7185C1.7758 10.259 1.77541 9.74301 1.58489 9.28386L0.919499 7.67284C0.82516 7.44529 0.776583 7.20139 0.776543 6.95506C0.776504 6.70873 0.825003 6.4648 0.919269 6.23723C1.01354 6.00965 1.15172 5.80287 1.32593 5.62872C1.50014 5.45457 1.70696 5.31645 1.93457 5.22225L3.54327 4.55591C4.00226 4.36612 4.3672 4.00197 4.55798 3.5434L5.22481 1.93354C5.41511 1.47411 5.78012 1.10909 6.23955 0.918793C6.69898 0.728492 7.21519 0.728492 7.67461 0.918793L9.28332 1.58514C9.74276 1.77497 10.2588 1.77459 10.7179 1.58406L12.3285 0.919827C12.7878 0.729632 13.3039 0.729671 13.7633 0.919935C14.2226 1.1102 14.5876 1.47511 14.7779 1.93442L15.4449 3.54475L15.4447 3.54197Z"
                  fill="#005BBE"
          ></path>
          <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  d="M13.9166 7.37864C14.0502 7.16879 14.0949 6.91446 14.041 6.6716C13.9871 6.42874 13.8389 6.21724 13.6291 6.08364C13.4192 5.95004 13.1649 5.90527 12.922 5.95919C12.6792 6.0131 12.4677 6.16129 12.3341 6.37114L8.66283 12.1399L6.98283 10.0399C6.82751 9.84562 6.60138 9.72101 6.35418 9.69346C6.10699 9.66592 5.85897 9.7377 5.6647 9.89302C5.47043 10.0483 5.34582 10.2745 5.31827 10.5217C5.29073 10.7689 5.36251 11.0169 5.51783 11.2111L8.01783 14.3361C8.111 14.4528 8.23066 14.5454 8.36687 14.6065C8.50308 14.6675 8.65189 14.6951 8.80093 14.6871C8.94998 14.679 9.09494 14.6355 9.22376 14.5601C9.35258 14.4847 9.46154 14.3796 9.54158 14.2536L13.9166 7.37864V7.37864Z"
                  fill="white"
          ></path>
        </g>
        <defs>
          <clipPath id="sf-avatar-verified-badge">
            <rect width="20" height="20" fill="white"></rect>
          </clipPath>
        </defs>
      </svg>
    </span>
    `;
}

function joinStyles(...styles) {
    return styles.filter(Boolean).join("; ");
}

export function avatarClasses(context, options = {}) {
    const includeRootClass = options.includeRootClass !== false;
    const classes = [
        "sf-avatar",
        "transition",
        'flex-none',
        `sf-avatar--size-${context.size}`,
        "inline-flex",
    ];

    if (context.isImage) {
        classes.push("bg-cover");
    }

    if (context.isText) {
        classes.push(
            "sf-avatar--text",
            "items-cross-center",
            "content-main-center",
        );
    }

    if (!context.isImage && !context.isText) {
        classes.push(
            "sf-avatar--placeholder",
            "items-cross-center",
            "content-main-center",
        );
    }

    if (context.status !== "none") {
        classes.push("relative");
    }

    if (context.status === "online") {
        classes.push("sf-avatar--status-icon-online-indicator");
    }

    if (includeRootClass && context.rootClass) {
        classes.push(context.rootClass);
    }

    return classes.join(" ");
}

export function avatarStyle(context) {
    if (!context.isImage) {
        return '';
    }

    return `background-image: url(${context.imageUrl});`;
}

export function avatarContent(context) {
    if (context.isText) {
        return html`<span class="sf-avatar-text">${context.text}</span>`;
    }

    if (context.isImage) {
        return '';
    }

    return html`<i class="sf-icon">person</i>`;
}

export function onlineIndicator(context) {
    if (context.component?.hasSlotContent?.("online-indicator")) {
        return context.component.getSlotContent("online-indicator");
    }

    if (!["online", "offline"].includes(context.status)) {
        return nothing;
    }

    const sizeMap = {
        "1/4": "sf-online-indicator--size-1/4",
        "1/3": "sf-online-indicator--size-1/3",
        "1/2": "sf-online-indicator--size-1/2",
        1: "sf-online-indicator--size-1",
    };

    return html`
        <span
                class="sf-online-indicator sf-online-indicator--${context.status} ${sizeMap[
                        context.size
                        ] || ""} flex absolute bottom-0 inline-end-0"
        ></span>
    `;
}

export function statusBadge(context) {
    switch (context.status) {
        case "company":
            if (context.component?.hasSlotContent?.("company-badge")) {
                return context.component.getSlotContent("company-badge");
            }

            return getCompanyBadge(context);
        case "verified":
            if (context.component?.hasSlotContent?.("verified-badge")) {
                return context.component.getSlotContent("verified-badge");
            }

            return getVerifiedBadge(context);
        default:
            return onlineIndicator(context);
    }
}

export function avatarButton(context, options = {}) {
    return html`
        <button
                class="${avatarClasses(context, options)}"
                style=${joinStyles(
                        avatarStyle(context),
                        options.includeRootStyle === false ? "" : context.rootStyle,
                )}
                aria-label=${context.ariaLabel}
                ?disabled=${context.disabled}
                type="button"
        >
            ${avatarContent(context)} ${statusBadge(context)}
        </button>
    `;
}
