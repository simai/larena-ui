import {html, nothing} from 'lit';

function joinClasses(...tokens) {
    return tokens.flat().filter(Boolean).join(' ');
}

function renderIcon(icon, className = '') {
    if (!icon) return nothing;

    return html`
        <sf-icon filled icon=${icon} class=${className || nothing}></sf-icon>`;
}

function renderLabel(context) {
    if (context.label) {
        return html`<span>${context.label}</span>`;
    }

    if (context.content !== nothing) {
        return context.content;
    }

    return nothing;
}

function renderTreeItemData(item = {}) {
    return html`
        <sf-tree-item
                label=${item.label || nothing}
                href=${item.href || nothing}
                target=${item.target || nothing}
                rel=${item.rel || nothing}
                type=${item.type || nothing}
                value=${item.value || nothing}
                open-icon=${item.openIcon || nothing}
                closed-icon=${item.closedIcon || nothing}
                ?open=${Boolean(item.open)}
                ?selected=${Boolean(item.selected)}
                ?active=${Boolean(item.active)}
                ?disabled=${Boolean(item.disabled)}
                .itemsData=${item.children || []}
        ></sf-tree-item>
    `;
}

export function renderTreeItemTemplate(context) {
    const itemClasses = joinClasses(
        'sf-tree-item flex flex-col',
        context.type ? `sf-tree-item--${context.type}` : '',
        context.open ? 'open' : '',
        context.hasChildren ? 'has-children' : '',
        context.selected || context.active ? 'active' : '',
        context.disabled ? 'disabled' : '',
        context.rootClass,
        context.itemClass,
    );
    const containerClasses = joinClasses(
        'sf-tree-item-container flex items-cross-center relative',
        context.containerClass,
    );
    const nameClasses = joinClasses('sf-tree-item-name', context.nameClass);
    const toggleIcon = context.open ? context.openIcon : context.closedIcon;
    const chevronIcon = context.open
        ? context.chevronOpenIcon
        : context.chevronClosedIcon;
    const canToggle = !context.isFile && context.hasChildren;

    return html`
        <div
                class=${itemClasses}
                role="treeitem"
                aria-expanded=${canToggle ? String(context.open) : nothing}
                aria-selected=${context.selected ? 'true' : nothing}
                aria-disabled=${context.disabled ? 'true' : nothing}
                data-open-icon=${context.openIcon || nothing}
                data-closed-icon=${context.closedIcon || nothing}
                data-value=${context.value || nothing}
        >
            <div class=${containerClasses}>
                ${!context.icon ? nothing : context.isFile
                        ? html`<sf-icon filled icon="draft"></sf-icon>`
                        : html`
                            <button
                                    type="button"
                                    class="sf-icon-button sf-tree-toggle"
                                    ?disabled=${!canToggle || context.disabled}
                                    aria-expanded=${canToggle ? String(context.open) : 'false'}
                                    aria-label=${context.open ? context.closeLabel : context.openLabel}
                                    @click=${context.onToggle}
                            >
                                ${renderIcon(toggleIcon)}
                            </button>
                        `}
                ${canToggle ?
                        html`<span class="sf-tree-chevron absolute" aria-hidden="true">
          ${renderIcon(chevronIcon)}
        </span>` : nothing}

                ${context.href && !context.disabled
                        ? html`
                            <a
                                    class=${nameClasses}
                                    href=${context.href}
                                    target=${context.target || nothing}
                                    rel=${context.rel || nothing}
                                    @click=${context.onItemClick}
                            >
                                ${renderLabel(context)}
                            </a>
                        `
                        : html`
                            <span class=${nameClasses} @click=${context.onItemClick}>
                ${renderLabel(context)}
              </span>
                        `}
            </div>

            ${context.open && canToggle
                    ? html`
                        ${(context.children || []).map((item) => renderTreeItemData(item))}
                    `
                    : nothing}
        </div>
    `;
}
