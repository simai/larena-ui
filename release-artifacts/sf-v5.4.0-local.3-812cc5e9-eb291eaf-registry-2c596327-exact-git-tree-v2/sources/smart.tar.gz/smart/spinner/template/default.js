import { html, nothing } from 'lit';

function joinClasses(...tokens) {
  return tokens.flat().filter(Boolean).join(' ');
}

function valueOrNothing(value) {
  return value === '' || value === null || value === undefined ? nothing : String(value);
}

export function renderSpinnerTemplate(context) {
  const rootClasses = joinClasses(
    'sf-loader-container',
    `sf-loader--size-${context.size}`,
    context.rootClass,
  );

  return html`
    <div
      class=${rootClasses}
      data-variant=${valueOrNothing(context.variant)}
      data-width=${valueOrNothing(context.width)}
      data-height=${valueOrNothing(context.height)}
      data-label=${valueOrNothing(context.label)}
      data-dots=${valueOrNothing(context.dots)}
      data-filled=${valueOrNothing(context.filled)}
      data-stroke-width=${valueOrNothing(context.strokeWidth)}
      data-dot-radius=${valueOrNothing(context.dotRadius)}
      data-infinite=${String(!!context.infinite)}
      data-direction=${valueOrNothing(context.direction)}
    ></div>
  `;
}
