﻿import { html } from "lit";

function joinClasses(...tokens) {
  return tokens.flat().filter(Boolean).join(" ");
}

function renderPageItem(item, context) {
  const targetPage = item.type === "ellipsis" ? item.target : item.value;
  const pageLabel =
    item.type === "ellipsis"
      ? `Перейти к странице ${item.target}`
      : `Страница ${item.value}`;

  if (item.type === "ellipsis") {
    return html`
      <button
        type="button"
        class="sf-page-number sf-page-number--square transition"
        data-page=${String(item.target || "")}
        aria-label=${pageLabel}
        @click=${() => context.component.goToPage(targetPage)}
      >
        ...
      </button>
    `;
  }

  return html`
    <button
      type="button"
      class=${joinClasses(
        "sf-page-number",
        "sf-page-number--square",
        "transition",
        item.selected ? "selected" : "",
      )}
      data-page=${String(item.value)}
      aria-current=${item.selected ? "page" : "false"}
      aria-label=${pageLabel}
      @click=${() => context.component.goToPage(targetPage)}
    >
      ${item.value}
    </button>
  `;
}

export function renderPaginationTemplate(context) {
  const { component } = context;
  const rootClasses = joinClasses(
    "sf-pagination",
    "flex",
    "flex-col",
    context.rootClass,
  );
  const topClasses = joinClasses(
    "sf-pagination-top",
    "flex",
    "content-main-center",
    context.topClass,
  );
  const mainClasses = joinClasses(
    "sf-pagination-main",
    "flex",
    "items-cross-center",
    "content-main-between",
    context.mainClass,
  );
  const bottomClasses = joinClasses(
    "sf-pagination-bottom",
    "flex",
    "items-cross-center",
    context.bottomClass,
  );

  return html`
    <div class=${rootClasses}>
      ${context.top
        ? html`
            <div class=${topClasses}>
              <sf-button
                size="1"
                type="outline"
                disabled=${!context.hasNext}
                scheme="primary"
                @click=${(e) => component.showMore(e.target)}
                text="${context.showMoreText}"
              ></sf-button>
            </div>
          `
        : ""}
      ${context.middle
        ? html`
            <div class=${mainClasses}>
              <div class="sf-pagination-left flex items-cross-center">
                <div class="sf-pagination-marked flex">
                  <div class="sf-pagination-marked-text">Отмечено:</div>
                  <div class="sf-pagination-marked-text">0/10</div>
                </div>
                <div class="sf-pagination-total flex items-cross-center">
                  <div class="sf-pagination-total-text">Всего:</div>
                  <sf-button
                    size="1"
                    type="link"
                    scheme="primary"
                    text="Показать количество"
                  ></sf-button>
                </div>
              </div>

              <div class="sf-pagination-container flex items-cross-center">
                <span class="sf-pagination-prev">Страницы:</span>
                <sf-icon-button
                  size="1"
                  type="link"
                  scheme="on-surface"
                  icon="keyboard_arrow_left"
                  disabled="${!context.hasPrev}"
                  aria-label="Предыдущая страница"
                  text="Показать количество"
                  @click=${() => component.goToPage(context.current - 1)}
                ></sf-icon-button>

                ${context.pageItems.map((item) =>
                  renderPageItem(item, context),
                )}
                <sf-icon-button
                  size="1"
                  type="link"
                  scheme="on-surface"
                  icon="keyboard_arrow_right"
                  disabled="${!context.hasNext}"
                  aria-label="Следующая страница"
                  text="Показать количество"
                  @click=${() => component.goToPage(context.current + 1)}
                ></sf-icon-button>
                <sf-button
                  size="1"
                  type="link"
                  scheme="primary"
                  disabled=${!context.hasNext}
                  text="Последняя"
                  @click=${() => component.lastPage()}
                ></sf-button>
              </div>

              ${context.showPageSize
                ? html`
                    <div class="sf-pagination-count flex items-cross-center">
                      <span>${context.pageSizeLabel}</span>
                      <sf-dropdown
                        size="1"
                        type="outlined"
                        search="false"
                        mode="select"
                        portal="true"
                        value=${String(context.pageSize)}
                        @change=${(event) =>
                          component.setPageSize(Number(event.detail.value))}
                      >
                        ${(context.pageSizes || []).map(
                          (size) => html`
                            <sf-list-item
                              type="text"
                              size="1"
                              text=${String(size)}
                              value=${String(size)}
                              ?selected=${Number(size) ===
                              Number(context.pageSize)}
                            ></sf-list-item>
                          `,
                        )}
                      </sf-dropdown>
                    </div>
                  `
                : ""}
            </div>
          `
        : ""}
      ${context.bottom && context.showActions && context.actions?.length
        ? html`
            <div class=${bottomClasses}>
              ${context.showActions && context.actions?.length
                ? html`
                    <sf-dropdown
                      size="1"
                      type="outlined"
                      search="false"
                      mode="select"
                      value=${context.action}
                      @change=${(event) =>
                        component.setAction(event.detail.value)}
                    >
                      ${context.actions.map(
                        (action) => html`
                          <sf-list-item
                            type="text"
                            size="1"
                            text=${action.text}
                            value=${action.value}
                            ?selected=${action.value === context.action}
                            ?disabled=${Boolean(action.disabled)}
                          ></sf-list-item>
                        `,
                      )}
                    </sf-dropdown>
                    <sf-button
                      size="1"
                      type="default"
                      scheme="primary"
                      text=${context.actionApplyText}
                      ?disabled=${!context.action}
                      @click=${() => component.applyAction()}
                    ></sf-button>
                    ${context.showActionForAll
                      ? html`
                          <sf-checkbox
                            label=${context.actionForAllLabel}
                            ?checked=${Boolean(context.actionForAll)}
                            @click=${() =>
                              component.setActionForAll(!context.actionForAll)}
                          ></sf-checkbox>
                        `
                      : ""}
                  `
                : ""}
            </div>
          `
        : ""}
    </div>
  `;
}
