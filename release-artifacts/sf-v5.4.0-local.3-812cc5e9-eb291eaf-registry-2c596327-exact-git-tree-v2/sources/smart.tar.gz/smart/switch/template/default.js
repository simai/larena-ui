import { html } from 'lit';

export function renderSwitchTemplate(context) {
  const { size, label, description, help, checked, disabled, name, value } = context;

  const rootClasses = ['sf-switch', `sf-switch--size-${size}`, 'flex'];

  const labelContent =
    context.component?.hasSlotContent?.('label')
      ? context.component.getSlotContent('label')
      : label
        ? html`<span class="sf-switch-text">${label}</span>`
        : '';

  const descriptionContent =
    context.component?.hasSlotContent?.('description')
      ? context.component.getSlotContent('description')
      : description
        ? html`<span class="sf-switch-description">${description}</span>`
        : '';

  const helpContent =
    context.component?.hasSlotContent?.('help')
      ? context.component.getSlotContent('help')
      : help
        ? html`<i class="sf-icon" aria-hidden="true">${help}</i>`
        : '';

  const showContainer = !!(labelContent || descriptionContent || helpContent);

  return html`
    <label class=${rootClasses.join(' ')}>
      <span class="sf-switch-toggler transition flex items-cross-center content-main-start">
        <input
          type="checkbox"
          name=${name || ''}
          .value=${value || ''}
          ?checked=${checked}
          ?disabled=${disabled}
        />
        <span class="sf-switch-inner transition" aria-hidden="true"></span>
      </span>

      ${showContainer
        ? html`
            <span class="sf-switch-container-wrap flex flex-col">
              ${labelContent || helpContent
                ? html`
                    <span class="sf-switch-top flex">
                      ${labelContent
                        ? html`
                            <span class="sf-switch-container flex items-cross-center content-main-center">
                              ${labelContent}
                            </span>
                          `
                        : ''}
                      ${helpContent}
                    </span>
                  `
                : ''}
              ${descriptionContent}
            </span>
          `
        : ''}
    </label>
  `;
}
